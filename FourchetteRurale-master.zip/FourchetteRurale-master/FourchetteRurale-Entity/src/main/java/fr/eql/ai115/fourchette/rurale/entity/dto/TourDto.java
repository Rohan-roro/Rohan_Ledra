package fr.eql.ai115.fourchette.rurale.entity.dto;

import java.io.Serializable;
import java.time.LocalDate;

public class TourDto implements Serializable {

    private Long idTour;
    private Long idDeliveryMan;
    private LocalDate dateCreationTour;
    private LocalDate dateExecutionTour;
    private LocalDate dateStartTour;
    private LocalDate dateEndTour;
    private String itinerary;

    public Long getIdTour() {
        return idTour;
    }

    public Long getIdDeliveryMan() {
        return idDeliveryMan;
    }

    public LocalDate getDateCreationTour() {
        return dateCreationTour;
    }

    public LocalDate getDateExecutionTour() {
        return dateExecutionTour;
    }

    public LocalDate getDateStartTour() {
        return dateStartTour;
    }

    public LocalDate getDateEndTour() {
        return dateEndTour;
    }

    public String getItinerary() {
        return itinerary;
    }

    public void setIdTour(Long idTour) {
        this.idTour = idTour;
    }

    public void setIdDeliveryMan(Long idDeliveryMan) {
        this.idDeliveryMan = idDeliveryMan;
    }

    public void setDateCreationTour(LocalDate dateCreationTour) {
        this.dateCreationTour = dateCreationTour;
    }

    public void setDateExecutionTour(LocalDate dateExecutionTour) {
        this.dateExecutionTour = dateExecutionTour;
    }

    public void setDateStartTour(LocalDate dateStartTour) {
        this.dateStartTour = dateStartTour;
    }

    public void setDateEndTour(LocalDate dateEndTour) {
        this.dateEndTour = dateEndTour;
    }

    public void setItinerary(String itinerary) {
        this.itinerary = itinerary;
    }
}
