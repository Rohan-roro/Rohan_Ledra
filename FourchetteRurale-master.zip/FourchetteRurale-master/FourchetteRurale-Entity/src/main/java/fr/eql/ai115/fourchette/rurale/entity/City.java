package fr.eql.ai115.fourchette.rurale.entity;

import java.io.Serializable;

public class City implements Serializable {
    private Long idCity;
    private String cityName;
    private Long postalCode;

    public City(Long idCity, String cityName, Long postalCode) {
        this.idCity = idCity;
        this.cityName = cityName;
        this.postalCode = postalCode;
    }

    public Long getIdCity() {
        return idCity;
    }

    public void setIdCity(Long idCity) {
        this.idCity = idCity;
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public Long getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(Long postalCode) {
        this.postalCode = postalCode;
    }
}
