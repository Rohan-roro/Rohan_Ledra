package fr.eql.ai115.fourchette.rurale.entity.dto;

import java.io.Serializable;
import java.time.LocalDate;

public class MemberMenuDto implements Serializable {

        private Long idMemberMenu;
        private Long idMember;
        private Long dayToDeliver;
        private LocalDate choiceDate;

        public Long getIdMemberMenu() {
            return idMemberMenu;
        }

        public void setIdMemberMenu(Long idMemberMenu) {
            this.idMemberMenu = idMemberMenu;
        }

        public Long getIdMember() {
            return idMember;
        }

        public void setIdMember(Long idMember) {
            this.idMember = idMember;
        }

        public Long getDayToDeliver() {
            return dayToDeliver;
        }

        public void setDayToDeliver(Long dayToDeliver) {
            this.dayToDeliver = dayToDeliver;
        }

        public LocalDate getChoiceDate() {
            return choiceDate;
        }

        public void setChoiceDate(LocalDate choiceDate) {
            this.choiceDate = choiceDate;
        }
}
