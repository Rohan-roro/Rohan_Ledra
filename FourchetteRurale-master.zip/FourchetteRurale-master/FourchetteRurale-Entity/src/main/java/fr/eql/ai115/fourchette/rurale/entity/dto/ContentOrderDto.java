package fr.eql.ai115.fourchette.rurale.entity.dto;

import java.io.Serializable;

public class ContentOrderDto implements Serializable {
    private Long idWeeklyOffer;
    private Long idOrder;
    private Long idRecipe;

    public Long getIdWeeklyOffer() {
        return idWeeklyOffer;
    }

    public void setIdWeeklyOffer(Long idWeeklyOffer) {
        this.idWeeklyOffer = idWeeklyOffer;
    }

    public Long getIdOrder() {
        return idOrder;
    }

    public void setIdOrder(Long idOrder) {
        this.idOrder = idOrder;
    }

    public Long getIdRecipe() {
        return idRecipe;
    }

    public void setIdRecipe(Long idRecipe) {
        this.idRecipe = idRecipe;
    }
}
