package fr.eql.ai115.fourchette.rurale.entity;

import java.io.Serializable;
import java.time.LocalDate;

public class WeeklyOfferCreate implements Serializable {

    private Long id_weekly_offer;
    private LocalDate creation_date;
    private LocalDate start_date;
    private LocalDate end_date;

    public WeeklyOfferCreate(Long id_weekly_offer, LocalDate creation_date, LocalDate start_date, LocalDate end_date) {
        this.id_weekly_offer = id_weekly_offer;
        this.creation_date = creation_date;
        this.start_date = start_date;
        this.end_date = end_date;
    }

    public Long getId_weekly_offer() {
        return id_weekly_offer;
    }

    public void setId_weekly_offer(Long id_weekly_offer) {
        this.id_weekly_offer = id_weekly_offer;
    }

    public LocalDate getCreation_date() {
        return creation_date;
    }

    public void setCreation_date(LocalDate creation_date) {
        this.creation_date = creation_date;
    }

    public LocalDate getStart_date() {
        return start_date;
    }

    public void setStart_date(LocalDate start_date) {
        this.start_date = start_date;
    }

    public LocalDate getEnd_date() {
        return end_date;
    }

    public void setEnd_date(LocalDate end_date) {
        this.end_date = end_date;
    }
}
