package fr.eql.ai115.fourchette.rurale.entity;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.List;

public class WeeklyOffer implements Serializable {

    private Long id_weekly_offer;
    private LocalDate creation_date;
    private LocalDate start_date;
    private LocalDate end_date;
    private List<Long> id_type_meal;
    private List<String> name_recipe;
    private List<Long> id_recipe;


    public WeeklyOffer(Long id_weekly_offer, LocalDate creation_date, LocalDate start_date, LocalDate end_date, List<Long> id_type_meal, List<String> name_recipe, List<Long> id_recipe) {
        this.id_weekly_offer = id_weekly_offer;
        this.creation_date = creation_date;
        this.start_date = start_date;
        this.end_date = end_date;
        this.id_type_meal = id_type_meal;
        this.name_recipe = name_recipe;
        this.id_recipe = id_recipe;
    }

    /// Getters ///

    public Long getId_weekly_offer() {
        return id_weekly_offer;
    }

    public LocalDate getCreation_date() {
        return creation_date;
    }

    public LocalDate getStart_date() {
        return start_date;
    }

    public LocalDate getEnd_date() {
        return end_date;
    }

    public List<Long> getId_type_meal() {
        return id_type_meal;
    }

    public List<String> getName_recipe() {
        return name_recipe;
    }

    public List<Long> getId_recipe() {
        return id_recipe;
    }
/// Setters ///


    public void setId_weekly_offer(Long id_weekly_offer) {
        this.id_weekly_offer = id_weekly_offer;
    }

    public void setCreation_date(LocalDate creation_date) {
        this.creation_date = creation_date;
    }

    public void setStart_date(LocalDate start_date) {
        this.start_date = start_date;
    }

    public void setEnd_date(LocalDate end_date) {
        this.end_date = end_date;
    }

    public void setId_type_meal(List<Long> id_type_meal) {
        this.id_type_meal = id_type_meal;
    }

    public void setName_recipe(List<String> name_recipe) {
        this.name_recipe = name_recipe;
    }

    public void setId_recipe(List<Long> id_recipe) {
        this.id_recipe = id_recipe;
    }
}

