package fr.eql.ai115.fourchette.rurale.entity;

import java.io.Serializable;
import java.time.LocalTime;

public class Slot implements Serializable {

    private Long idSlot;
    private LocalTime startHour;
    private LocalTime endHour;

    public Slot(Long idSlot, LocalTime startHour, LocalTime endHour) {
        this.idSlot = idSlot;
        this.startHour = startHour;
        this.endHour = endHour;
    }

    public Long getIdSlot() {
        return idSlot;
    }

    public void setIdSlot(Long idSlot) {
        this.idSlot = idSlot;
    }

    public LocalTime getStartHour() {
        return startHour;
    }

    public void setStartHour(LocalTime startHour) {
        this.startHour = startHour;
    }

    public LocalTime getEndHour() {
        return endHour;
    }

    public void setEndHour(LocalTime endHour) {
        this.endHour = endHour;
    }
}
