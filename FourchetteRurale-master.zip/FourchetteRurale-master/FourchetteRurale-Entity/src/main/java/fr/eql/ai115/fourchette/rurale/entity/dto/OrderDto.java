package fr.eql.ai115.fourchette.rurale.entity.dto;

import java.io.Serializable;
import java.time.LocalDate;

public class OrderDto implements Serializable {

    private Long idOrder;
    private Long idSlot;
    private Long idMember;
    private Long idNote;
    private Long idBug;
    private Long idTour;
    private LocalDate shippingDate;
    private String comment;
    private LocalDate dateExecuteShipping;
    private int deliveryOrder;

    public Long getIdOrder() {
        return idOrder;
    }

    public Long getIdSlot() {
        return idSlot;
    }

    public Long getIdMember() {
        return idMember;
    }

    public Long getIdNote() {
        return idNote;
    }

    public Long getIdBug() {
        return idBug;
    }

    public Long getIdTour() {
        return idTour;
    }

    public LocalDate getShippingDate() {
        return shippingDate;
    }

    public String getComment() {
        return comment;
    }

    public LocalDate getDateExecuteShipping() {
        return dateExecuteShipping;
    }

    public int getDeliveryOrder() {
        return deliveryOrder;
    }

    public void setIdOrder(Long idOrder) {
        this.idOrder = idOrder;
    }

    public void setIdSlot(Long idSlot) {
        this.idSlot = idSlot;
    }

    public void setIdMember(Long idMember) {
        this.idMember = idMember;
    }

    public void setIdNote(Long idNote) {
        this.idNote = idNote;
    }

    public void setIdBug(Long idBug) {
        this.idBug = idBug;
    }

    public void setIdTour(Long idTour) {
        this.idTour = idTour;
    }

    public void setShippingDate(LocalDate shippingDate) {
        this.shippingDate = shippingDate;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public void setDateExecuteShipping(LocalDate dateExecuteShipping) {
        this.dateExecuteShipping = dateExecuteShipping;
    }

    public void setDeliveryOrder(int deliveryOrder) {
        this.deliveryOrder = deliveryOrder;
    }
}
