package fr.eql.ai115.fourchette.rurale.entity;

import java.io.Serializable;
import java.time.LocalDate;

public class Tour implements Serializable {

    private Long idTour;
    private Long idDeliveryMan;
    private LocalDate dateCreationTour;
    private LocalDate dateExecutionTour;
    private LocalDate dateStartTour;
    private LocalDate dateEndTour;
    private String itinerary;

    public Tour(Long idTour, Long idDeliveryMan, LocalDate dateCreationTour, LocalDate dateExecutionTour, LocalDate dateStartTour, LocalDate dateEndTour, String itinerary) {
        this.idTour = idTour;
        this.idDeliveryMan = idDeliveryMan;
        this.dateCreationTour = dateCreationTour;
        this.dateExecutionTour = dateExecutionTour;
        this.dateStartTour = dateStartTour;
        this.dateEndTour = dateEndTour;
        this.itinerary = itinerary;
    }

    public Long getIdTour() {
        return idTour;
    }

    public Long getIdDeliveryMan() {
        return idDeliveryMan;
    }

    public LocalDate getDateCreationTour() {
        return dateCreationTour;
    }

    public LocalDate getDateExecutionTour() {
        return dateExecutionTour;
    }

    public LocalDate getDateStartTour() {
        return dateStartTour;
    }

    public LocalDate getDateEndTour() {
        return dateEndTour;
    }

    public String getItinerary() {
        return itinerary;
    }

    public void setIdTour(Long idTour) {
        this.idTour = idTour;
    }

    public void setIdDeliveryMan(Long idDeliveryMan) {
        this.idDeliveryMan = idDeliveryMan;
    }

    public void setDateCreationTour(LocalDate dateCreationTour) {
        this.dateCreationTour = dateCreationTour;
    }

    public void setDateExecutionTour(LocalDate dateExecutionTour) {
        this.dateExecutionTour = dateExecutionTour;
    }

    public void setDateStartTour(LocalDate dateStartTour) {
        this.dateStartTour = dateStartTour;
    }

    public void setDateEndTour(LocalDate dateEndTour) {
        this.dateEndTour = dateEndTour;
    }

    public void setItinerary(String itinerary) {
        this.itinerary = itinerary;
    }
}
