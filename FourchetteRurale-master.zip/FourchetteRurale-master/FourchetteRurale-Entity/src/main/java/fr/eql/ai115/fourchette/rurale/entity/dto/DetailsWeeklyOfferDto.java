package fr.eql.ai115.fourchette.rurale.entity.dto;

import java.io.Serializable;

public class DetailsWeeklyOfferDto implements Serializable {

    private Long idDetailsWeeklyOffer;
    private Long idWeeklyOffer;
    private Long idTypeMeal;
    private Long idRecipe;

    public Long getIdDetailsWeeklyOffer() {
        return idDetailsWeeklyOffer;
    }

    public void setIdDetailsWeeklyOffer(Long idDetailsWeeklyOffer) {
        this.idDetailsWeeklyOffer = idDetailsWeeklyOffer;
    }

    public Long getIdWeeklyOffer() {
        return idWeeklyOffer;
    }

    public void setIdWeeklyOffer(Long idWeeklyOffer) {
        this.idWeeklyOffer = idWeeklyOffer;
    }

    public Long getIdTypeMeal() {
        return idTypeMeal;
    }

    public void setIdTypeMeal(Long idTypeMeal) {
        this.idTypeMeal = idTypeMeal;
    }

    public Long getIdRecipe() {
        return idRecipe;
    }

    public void setIdRecipe(Long idRecipe) {
        this.idRecipe = idRecipe;
    }
}
