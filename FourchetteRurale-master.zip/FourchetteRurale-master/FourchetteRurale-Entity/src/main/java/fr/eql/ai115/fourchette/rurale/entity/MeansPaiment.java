package fr.eql.ai115.fourchette.rurale.entity;

import java.io.Serializable;

public class MeansPaiment implements Serializable {

    private Long idMeansPaiment;
    private String meansPaiment;

    public MeansPaiment(Long idMeansPaiment, String meansPaiment) {
        this.idMeansPaiment = idMeansPaiment;
        this.meansPaiment = meansPaiment;
    }

    public Long getIdMeansPaiment() {
        return idMeansPaiment;
    }

    public void setIdMeansPaiment(Long idMeansPaiment) {
        this.idMeansPaiment = idMeansPaiment;
    }

    public String getMeansPaiment() {
        return meansPaiment;
    }

    public void setMeansPaiment(String meansPaiment) {
        this.meansPaiment = meansPaiment;
    }
}
