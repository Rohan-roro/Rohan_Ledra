package fr.eql.ai115.fourchette.rurale.entity;

import java.io.Serializable;
import java.time.LocalDate;

public class MonthlyMembership implements Serializable {
    private Long id_paiement;
    private Long id_adherent;
    private Long id_moyen_paye;
    private LocalDate date_adhesion;
    private LocalDate date_paiement;

    public MonthlyMembership(Long id_paiement, Long id_adherent, Long id_moyen_paye, LocalDate date_adhesion, LocalDate date_paiement) {
        this.id_paiement = id_paiement;
        this.id_adherent = id_adherent;
        this.id_moyen_paye = id_moyen_paye;
        this.date_adhesion = date_adhesion;
        this.date_paiement = date_paiement;
    }

    public Long getId_paiement() {
        return id_paiement;
    }
    public Long getId_adherent() {
        return id_adherent;
    }
    public Long getId_moyen_paye() {
        return id_moyen_paye;
    }
    public LocalDate getDate_adhesion() {
        return date_adhesion;
    }
    public LocalDate getDate_paiement() {
        return date_paiement;
    }

    public void setId_paiement(Long id_paiement) {
        this.id_paiement = id_paiement;
    }

    public void setId_adherent(Long id_adherent) {
        this.id_adherent = id_adherent;
    }

    public void setId_moyen_paye(Long id_moyen_paye) {
        this.id_moyen_paye = id_moyen_paye;
    }

    public void setDate_adhesion(LocalDate date_adhesion) {
        this.date_adhesion = date_adhesion;
    }

    public void setDate_paiement(LocalDate date_paiement) {
        this.date_paiement = date_paiement;
    }
}
