package fr.eql.ai115.fourchette.rurale.entity;

import java.io.Serializable;

public class ChoiceMemberMenu implements Serializable {

    private Long idMenuChoice;
    private Long idMemberMenu;
    private Long idTypeMeal;
    private Long idDay;
    private Long quantity;

    public ChoiceMemberMenu(Long idMenuChoice, Long idMemberMenu, Long idTypeMeal, Long idDay, Long quantity) {
        this.idMenuChoice = idMenuChoice;
        this.idMemberMenu = idMemberMenu;
        this.idTypeMeal = idTypeMeal;
        this.idDay = idDay;
        this.quantity = quantity;
    }

    public Long getIdMenuChoice() {
        return idMenuChoice;
    }

    public void setIdMenuChoice(Long idMenuChoice) {
        this.idMenuChoice = idMenuChoice;
    }

    public Long getIdMemberMenu() {
        return idMemberMenu;
    }

    public void setIdMemberMenu(Long idMemberMenu) {
        this.idMemberMenu = idMemberMenu;
    }

    public Long getIdTypeMeal() {
        return idTypeMeal;
    }

    public void setIdTypeMeal(Long idTypeMeal) {
        this.idTypeMeal = idTypeMeal;
    }

    public Long getIdDay() {
        return idDay;
    }

    public void setIdDay(Long idDay) {
        this.idDay = idDay;
    }

    public Long getQuantity() {
        return quantity;
    }

    public void setQuantity(Long quantity) {
        this.quantity = quantity;
    }
}
