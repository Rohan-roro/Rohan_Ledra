package fr.eql.ai115.fourchette.rurale.entity;

import java.io.Serializable;

public class ContentOrder implements Serializable {
    private Long idWeeklyOffer;
    private Long idOrder;
    private Long idRecipe;

    public ContentOrder(Long idWeeklyOffer, Long idOrder, Long idRecipe) {
        this.idWeeklyOffer = idWeeklyOffer;
        this.idOrder = idOrder;
        this.idRecipe = idRecipe;
    }

    public Long getIdWeeklyOffer() {
        return idWeeklyOffer;
    }

    public void setIdWeeklyOffer(Long idWeeklyOffer) {
        this.idWeeklyOffer = idWeeklyOffer;
    }

    public Long getIdOrder() {
        return idOrder;
    }

    public void setIdOrder(Long idOrder) {
        this.idOrder = idOrder;
    }

    public Long getIdRecipe() {
        return idRecipe;
    }

    public void setIdRecipe(Long idRecipe) {
        this.idRecipe = idRecipe;
    }
}




