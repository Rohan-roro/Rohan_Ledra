package fr.eql.ai115.fourchette.rurale.entity.dto;

import java.io.Serializable;
import java.time.LocalDate;

public class MemberDto implements Serializable {
    private Long idMember;
    private Long city;
    private Long civility;
    private String firstname;
    private String lastname;
    private LocalDate birthdate;
    private String phoneNumber;
    private String emailAdress;
    private String password;
    private String shippingAddress;
    private String billingAddress;
    private LocalDate registrationDate;
    private LocalDate unsubscriptionDate;

    public Long getIdMember() {
        return idMember;
    }

    public Long getCity() {
        return city;
    }

    public Long getCivility() {
        return civility;
    }

    public String getFirstname() {
        return firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public LocalDate getBirthdate() {
        return birthdate;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getEmailAdress() {
        return emailAdress;
    }

    public String getPassword() {
        return password;
    }

    public String getShippingAddress() {
        return shippingAddress;
    }

    public String getBillingAddress() {
        return billingAddress;
    }

    public LocalDate getRegistrationDate() {
        return registrationDate;
    }

    public LocalDate getUnsubscriptionDate() {
        return unsubscriptionDate;
    }

    public void setIdMember(Long idMember) {
        this.idMember = idMember;
    }

    public void setCity(Long city) {
        this.city = city;
    }

    public void setCivility(Long civility) {
        this.civility = civility;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public void setBirthdate(LocalDate birthdate) {
        this.birthdate = birthdate;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public void setEmailAdress(String emailAdress) {
        this.emailAdress = emailAdress;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setShippingAddress(String shippingAddress) {
        this.shippingAddress = shippingAddress;
    }

    public void setBillingAddress(String billingAddress) {
        this.billingAddress = billingAddress;
    }

    public void setRegistrationDate(LocalDate registrationDate) {
        this.registrationDate = registrationDate;
    }

    public void setUnsubscriptionDate(LocalDate unsubscriptionDate) {
        this.unsubscriptionDate = unsubscriptionDate;
    }
}
