package fr.eql.ai115.fourchette.rurale.entity;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Date;

public class Member implements Serializable {
    private Long idMember;
    private final Long city;
    private final Long civility;
    private final String firstname;
    private final String lastname;
    private final LocalDate birthdate;
    private final String phoneNumber;
    private final String emailAdress;
    private final String password;
    private final String shippingAddress;
    private final String billingAddress;
    private final LocalDate registrationDate;
    private final LocalDate unsubscriptionDate;

    public Member(Long idMember, Long city, Long civility, String firstname, String lastname, LocalDate birthdate, String phoneNumber, String emailAdress, String password, String shippingAddress, String billingAddress, LocalDate registrationDate, LocalDate unsubscriptionDate) {
        this.idMember = idMember;
        this.city = city;
        this.civility = civility;
        this.firstname = firstname;
        this.lastname = lastname;
        this.birthdate = birthdate;
        this.phoneNumber = phoneNumber;
        this.emailAdress = emailAdress;
        this.password = password;
        this.shippingAddress = shippingAddress;
        this.billingAddress = billingAddress;
        this.registrationDate = registrationDate;
        this.unsubscriptionDate = unsubscriptionDate;
    }


    public Long getIdMember() {
        return idMember;
    }

    public Long getCity() {
        return city;
    }

    public Long getCivility() {
        return civility;
    }

    public String getFirstname() {
        return firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public LocalDate getBirthdate() {
        return birthdate;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getEmailAdress() {
        return emailAdress;
    }

    public String getPassword() {
        return password;
    }

    public String getShippingAddress() {
        return shippingAddress;
    }

    public String getBillingAddress() {
        return billingAddress;
    }

    public LocalDate getRegistrationDate() {
        return registrationDate;
    }

    public LocalDate getUnsubscriptionDate() {
        return unsubscriptionDate;
    }

    public void setIdMember(Long idMember) {
        this.idMember = idMember;
    }
}
