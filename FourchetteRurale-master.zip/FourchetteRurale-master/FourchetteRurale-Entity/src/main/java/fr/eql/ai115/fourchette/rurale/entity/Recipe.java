package fr.eql.ai115.fourchette.rurale.entity;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.List;

public class Recipe implements Serializable {

    private Long id_recipe;
    private Long id_type_meal;
    private String name;
    private String ingredients;
    private String photo;
    private String description;
    private LocalDate creation_date;
    private LocalDate deletion_date;


    public Recipe(Long id_recipe, Long id_type_meal, String name, String ingredients, String photo, String description, LocalDate creation_date, LocalDate deletion_date) {
        this.id_recipe = id_recipe;
        this.id_type_meal = id_type_meal;
        this.name = name;
        this.ingredients = ingredients;
        this.photo = photo;
        this.description = description;
        this.creation_date = creation_date;
        this.deletion_date = deletion_date;
    }

    /// Getters ///


    public Long getId_recipe() {
        return id_recipe;
    }

    public Long getId_type_meal() {
        return id_type_meal;
    }

    public String getName() {
        return name;
    }

    public String getIngredients() {
        return ingredients;
    }

    public String getPhoto() {
        return photo;
    }

    public String getDescription() {
        return description;
    }

    public LocalDate getCreation_date() {
        return creation_date;
    }

    public LocalDate getDeletion_date() {
        return deletion_date;
    }

    public void setId_recipe(Long id_recipe) {
        this.id_recipe = id_recipe;
    }

    public void setId_type_meal(Long id_type_meal) {
        this.id_type_meal = id_type_meal;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setIngredients(String ingredients) {
        this.ingredients = ingredients;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setCreation_date(LocalDate creation_date) {
        this.creation_date = creation_date;
    }

    public void setDeletion_date(LocalDate deletion_date) {
        this.deletion_date = deletion_date;
    }
}