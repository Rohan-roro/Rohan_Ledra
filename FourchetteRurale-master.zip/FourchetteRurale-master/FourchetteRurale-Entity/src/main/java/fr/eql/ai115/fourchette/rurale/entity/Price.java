package fr.eql.ai115.fourchette.rurale.entity;

import java.io.Serializable;

public class Price implements Serializable {

    private Long idTypeMeal;
    private Long priceTypeMeal;


    public Price(Long idTypeMeal, Long priceTypeMeal) {
        this.idTypeMeal = idTypeMeal;
        this.priceTypeMeal = priceTypeMeal;
    }

    public Long getIdTypeMeal() {
        return idTypeMeal;
    }

    public void setIdTypeMeal(Long idTypeMeal) {
        this.idTypeMeal = idTypeMeal;
    }

    public Long getPriceTypeMeal() {
        return priceTypeMeal;
    }

    public void setPriceTypeMeal(Long priceTypeMeal) {
        this.priceTypeMeal = priceTypeMeal;
    }
}
