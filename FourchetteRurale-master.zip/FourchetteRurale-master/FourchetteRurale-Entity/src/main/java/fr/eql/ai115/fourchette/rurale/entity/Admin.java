package fr.eql.ai115.fourchette.rurale.entity;

import java.io.Serializable;

public class Admin implements Serializable {
    private Long idAdmin;
    private String loginAdmin;
    private String passwordAdmin;

    public Admin(Long idAdmin, String loginAdmin, String passwordAdmin) {
        this.idAdmin = idAdmin;
        this.loginAdmin = loginAdmin;
        this.passwordAdmin = passwordAdmin;
    }

    public Long getIdAdmin() {
        return idAdmin;
    }

    public void setIdAdmin(Long idAdmin) {
        this.idAdmin = idAdmin;
    }

    public String getLoginAdmin() {
        return loginAdmin;
    }

    public void setLoginAdmin(String loginAdmin) {
        this.loginAdmin = loginAdmin;
    }

    public String getPasswordAdmin() {
        return passwordAdmin;
    }

    public void setPasswordAdmin(String passwordAdmin) {
        this.passwordAdmin = passwordAdmin;
    }
}
