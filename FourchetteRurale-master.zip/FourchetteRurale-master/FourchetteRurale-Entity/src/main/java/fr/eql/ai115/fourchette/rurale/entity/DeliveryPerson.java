package fr.eql.ai115.fourchette.rurale.entity;

import java.io.Serializable;

public class DeliveryPerson implements Serializable {
    private Long id_delivery_person;
    private Long id_civility;
    private String firstname;
    private String lastname;
    private String phone;
    private String email;
    private String password;

    public DeliveryPerson(Long id_delivery_person, Long id_civility, String firstname, String lastname, String phone, String email, String password) {
        this.id_delivery_person = id_delivery_person;
        this.id_civility = id_civility;
        this.firstname = firstname;
        this.lastname = lastname;
        this.phone = phone;
        this.email = email;
        this.password = password;
    }

    public Long getId_delivery_person() {
        return id_delivery_person;
    }

    public Long getId_civility() {
        return id_civility;
    }

    public String getFirstname() {
        return firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public String getPhone() {
        return phone;
    }

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

    public void setId_delivery_person(Long id_delivery_person) {
        this.id_delivery_person = id_delivery_person;
    }

    public void setId_civility(Long id_civility) {
        this.id_civility = id_civility;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
