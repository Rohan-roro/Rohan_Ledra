document.addEventListener('DOMContentLoaded', function() {

    const backUrl = window.location.origin + "/api/rest";
    const registrationForm = document.getElementById('registrationForm');
    const loginInput = document.getElementById('loginAdmin');
    const passwordInput = document.getElementById('passwordAdmin');

    registrationForm.addEventListener('submit', function(event) {
        event.preventDefault(); // Prevent the form from submitting normally

        // Gather data from the form fields
        let login = loginInput.value;
        let password = passwordInput.value;

        // Create a JSON object
        let adminData = {
            "loginAdmin": login,
            "passwordAdmin": password
        };

        // Send a POST request to the server
      fetch(backUrl + '/registration/admin', {
          method: 'POST',
          headers: {
              'Content-Type': 'application/json'
          },
          body: JSON.stringify(adminData)
      })
      .then(response => {
          if (!response.ok) {
              throw new Error(`HTTP error! status: ${response.status}`);
          }
          // Check if the response is empty
          if (response.headers.get('content-length') === '0' || !response.headers.get('content-type').includes('application/json')) {
              console.log('Empty response from server');
              return {}; // Return an empty object instead of throwing an error
          }
          return response.json();
      })
      .then(data => {
          console.log('Admin created successfully:', data);
          alert('Admin créer avec succès');
          // Refresh the page
          window.location.reload();
      })
      .catch(error => {
          console.error('Error:', error);
      });
    });
});