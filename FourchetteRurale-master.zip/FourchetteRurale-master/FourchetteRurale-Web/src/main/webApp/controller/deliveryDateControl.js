document.addEventListener('DOMContentLoaded', function() {
    // Get the current date
    var currentDate = new Date();

    // Find the day of the week corresponding to the current date
    var currentDayOfWeek = currentDate.getDay();

    // Add the number of days needed to reach the next Monday
    var daysToAddMonday = 8 - currentDayOfWeek; // 8 correspond au lundi
    if (currentDayOfWeek === 0) { // Si c'est dimanche
        daysToAddMonday = 1; // Prochain lundi
    }

    var nextMonday = new Date(currentDate);
    nextMonday.setDate(currentDate.getDate() + daysToAddMonday);

    // Add the number of days needed to reach the next Friday
    var daysToAddFriday = (currentDayOfWeek >= 5) ? (currentDayOfWeek === 5 ? 0 : 12 - currentDayOfWeek) : (5 - currentDayOfWeek); // 12 corresponds to Friday

    var nextFriday = new Date(currentDate);
    nextFriday.setDate(nextMonday.getDate() + 4);

    // Format the dates in "YYYY-MM-DD" format
    var nextMondayFormatted = formatDate(nextMonday);
    var nextFridayFormatted = formatDate(nextFriday);

    // Retrieve the input element of type date
    var startDate = document.getElementById('startDate');

    // Set the minimum and maximum dates allowed for the date picker
    startDate.setAttribute('min', nextMondayFormatted);
    startDate.setAttribute('max', nextFridayFormatted);
});

// Function to format the date in "YYYY-MM-DD" format
function formatDate(date) {
    var year = date.getFullYear();
    var month = ('0' + (date.getMonth() + 1)).slice(-2);
    var day = ('0' + date.getDate()).slice(-2);
    return year + '-' + month + '-' + day;
}