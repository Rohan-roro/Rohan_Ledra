const backUrl = window.location.origin + "/api/rest/registration";

document.getElementById('registrationForm').addEventListener('submit', function(event) {
    event.preventDefault();

    let civility = document.getElementById('civility').value;
    let lastname = document.getElementById('lastname').value;
    let firstname = document.getElementById('firstname').value;
    let phone = document.getElementById('phone').value;
    let email = document.getElementById('email').value;
    let password = document.getElementById('password').value;

    let deliveryPerson = {
        id_civility: civility, // Assurez-vous que la valeur de civilité correspond à l'ID attendu
        lastname: lastname,
        firstname: firstname,
        phone: phone,
        email: email,
        password: password,
    };

    console.log(deliveryPerson);

    fetch(backUrl + "/deliveryPerson", {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(deliveryPerson)
    }).then(response => {
              if (!response.ok) {
                  throw new Error(`HTTP error! status: ${response.status}`);
              }
              return response.text();
          })
          .then(text => text.length ? JSON.parse(text) : {})
          .then(data => {
              console.log(data);

              // Display the success message
              alert('Livreur créé');

              // Refresh the page
              location.reload();
          })
          .catch((error) => {
              console.error('Error:', error);

              // Display the error message
              alert("Erreur lors de la création du livreur: " + error.message);
          });
      });