console.log("SelectedactualWeeklyOfferRecipe.js chargé");

const backUrl = window.location.origin + "/api/rest/recipe/weeklyOffer";
const currentOfferUrl = window.location.origin + "/api/rest/weeklyOfferCreate/current";

function displayAllRecipes() {
    // Obtenir une référence au conteneur de recettes
    const container = document.querySelector('.conteneur-recettes');

    // Fonction pour compter les occurrences de chaque recette
    function compterOccurrences(liste, valeur) {
        return liste.filter((v) => v === valeur).length;
    }

    // Effectuer une requête GET pour obtenir l'ID de l'offre hebdomadaire actuelle
    fetch(currentOfferUrl)
        .then(response => response.json())
        .then(currentOfferId => {
            // Récupérer les données de l'offre
            fetch(backUrl + "/" + currentOfferId) // Utiliser currentOfferId dans la requête fetch
                .then(response => response.json())
                .then(recipes => {
                    console.log("check si listeRecettes en remplie :", listeRecettesStorage);
                    // Créer une variable avec toutes les recettes chargées dans le stockage local
                    let filteredRecipes = recipes.filter(recipe => listeRecettesStorage.includes(recipe.id_recipe));
                    console.log("liste de toutes les recettes :", recipes);
                    console.log("liste filteredRecipes :", filteredRecipes);
                    // Pour chaque recette, créer un élément HTML et l'ajouter au conteneur
                    filteredRecipes.forEach(recipe => {
                        const occurrences = compterOccurrences(listeRecettesStorage, recipe.id_recipe);
                        for (let x = 0; x < occurrences; x++) {
                            console.log('Processing recipe:', recipe); // Journaliser l'objet recette complet dans la console

                            const recipeElement = document.createElement('div');
                            recipeElement.classList.add('recette');

                            const title = document.createElement('h3');
                            title.textContent = recipe.name; // Ajouter le nom de la recette dans le titre
                            recipeElement.appendChild(title);

                            const image = document.createElement('img');
                            image.alt = recipe.name;
                            image.src = recipe.photo;
                            image.addEventListener('click', function() {
                                ajouterRecette(this, recipe);
                            });
                            recipeElement.appendChild(image);

                            const description = document.createElement('p');
                            description.textContent = recipe.description;
                            recipeElement.appendChild(description);

                            container.appendChild(recipeElement);
                        }
                    });
                })
                .catch(error => console.error('Error:', error)); // Déplacer le catch ici pour gérer les erreurs de récupération des données
        });


}



    //BOUTON SUPPRIMER SELECTION
    document.addEventListener("DOMContentLoaded", function() {
        // Sélection du bouton deleteSelection
        var deleteBtn = document.getElementById("deleteSelection");

        // Ajout d'un écouteur d'événements sur le clic du bouton
        deleteBtn.addEventListener("click", function() {
            // Recharger la page
            location.reload();
        });
    });

    window.onload = displayAllRecipes;