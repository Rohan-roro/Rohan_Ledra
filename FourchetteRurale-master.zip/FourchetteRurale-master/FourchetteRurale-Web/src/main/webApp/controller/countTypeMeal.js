console.log("countTypeMeal.js");

const backUrlCount = window.location.origin + "/api/rest/memberMenu";


let memberMenu = JSON.parse(localStorage.getItem('memberMenu'));


//Recuperer le nombre de petits dejeuners restants
async function updateBreakfastCount() {
    // Récupérer la liste des types de repas du localStorage
    let listeTypeMeal = JSON.parse(localStorage.getItem('listeTypeMeal'));
    let listeRecettes = JSON.parse(localStorage.getItem('listeRecettes'));

    // Si listeTypeMeal est null, initialiser listeTypeMeal à un tableau vide et continuer
    if (listeTypeMeal === null) {
        listeTypeMeal = [];
    }

        if (listeRecettes === null) {
            listeRecettes = [];
        }

    // Compter le nombre de petits déjeuners dans la liste
    let breakfastCount = 0;
    for (let i = 0; i < listeTypeMeal.length; i++) {
        if (listeTypeMeal[i] === 1) {
            breakfastCount++;
        }
    }

    // Récupérer le nombre de petits déjeuners restants de l'API
    let idMemberMenu = memberMenu.idMemberMenu;
    return await fetch(backUrlCount + "/getNumberTypeMeal/"+ 1 + "/" + idMemberMenu)
        .then(response => response.json())
        .then(data1 => {
            // Soustraire le nombre de petits déjeuners sélectionnés du nombre total de petits déjeuners
            let remainingBreakfasts = data1 - breakfastCount;

            const quantityInput = document.getElementById('quantityInput');

               while (remainingBreakfasts < 0 && breakfastCount > 0) {
                   // Trouver l'index du dernier petit déjeuner dans la liste
                   let index = listeTypeMeal.lastIndexOf(1);

                   // Si un petit déjeuner a été trouvé dans la liste, le supprimer
                   if (index !== -1) {
                       listeTypeMeal.splice(index, 1);
                       listeRecettes.splice(index, 1);

                       // Mettre à jour le nombre de petits déjeuners restants et le nombre de petits déjeuners sélectionnés
                       breakfastCount--;
                       remainingBreakfasts++;
                   }

                   localStorage.setItem('listeTypeMeal', JSON.stringify(listeTypeMeal));
                   localStorage.setItem('listeRecettes', JSON.stringify(listeRecettes));
               }

                 // Si le nombre de petits déjeuners restants est inférieur à 0, le fixer à 0
                if (remainingBreakfasts < 0) {
                    remainingBreakfasts = 0;
                }


            // Sélectionner l'élément HTML où afficher le nombre de petits déjeuners restants
            let element = document.getElementById('petitsDejeunersRestants');

            // Afficher le nombre de petits déjeuners restants dans l'élément sélectionné
            element.innerHTML = "<b>" + remainingBreakfasts + "</b> Petits déjeuners";

            // Retourner le nombre de petits déjeuners restants
            return remainingBreakfasts;
        })
        .catch(error => console.error('Erreur:', error));
}

// Appeler la fonction updateBreakfastCount chaque fois que la page est chargée ou que la liste des types de repas est mise à jour
window.addEventListener('storage', function(e) {
    if (e.key === 'listeTypeMeal') {
        updateBreakfastCount();
        // Ajoutez ici les autres fonctions de mise à jour pour les autres types de repas
    }
});


//Recuperer le nombre de collation restants
async function updateSnackCount() {
    let listeTypeMeal = JSON.parse(localStorage.getItem('listeTypeMeal'));
    let listeRecettes = JSON.parse(localStorage.getItem('listeRecettes'));


    if (listeTypeMeal === null) {
        listeTypeMeal = [];
    }

    let snackCount = 0;
    for (let i = 0; i < listeTypeMeal.length; i++) {
        if (listeTypeMeal[i] === 2) {
            snackCount++;
        }
    }

    let idMemberMenu = memberMenu.idMemberMenu;
    return await fetch(backUrlCount + "/getNumberTypeMeal/"+ 2 + "/" + idMemberMenu)
        .then(response => response.json())
        .then(data2 => {
            let remainingSnacks = data2 - snackCount;

            while (remainingSnacks < 0 && snackCount > 0) {
                let index = listeTypeMeal.lastIndexOf(2);

                if (index !== -1) {
                    listeTypeMeal.splice(index, 1);
                    listeRecettes.splice(index, 1);

                      snackCount--;
                      remainingSnacks++;
                }

                localStorage.setItem('listeTypeMeal', JSON.stringify(listeTypeMeal));
                localStorage.setItem('listeRecettes', JSON.stringify(listeRecettes));
            }

            if (remainingSnacks < 0) {
                    remainingSnacks = 0;
            }

            let element = document.getElementById('collationsRestants');
            element.innerHTML = "<b>" + remainingSnacks + "</b> Collations";

            return remainingSnacks;
        })
        .catch(error => console.error('Erreur:', error));
}

window.addEventListener('storage', function(e) {
    if (e.key === 'listeTypeMeal') {
        updateSnackCount();
    }
});

// For main courses
async function updateMainCourseCount() {
    let listeTypeMeal = JSON.parse(localStorage.getItem('listeTypeMeal'));
    let listeRecettes = JSON.parse(localStorage.getItem('listeRecettes'));

    if (listeTypeMeal === null) {
        listeTypeMeal = [];
    }

        if (listeRecettes === null) {
            listeRecettes = [];
        }

    let mainCourseCount = 0;
    for (let i = 0; i < listeTypeMeal.length; i++) {
        if (listeTypeMeal[i] === 3) {
            mainCourseCount++;
        }
    }
    let idMemberMenu = memberMenu.idMemberMenu;
    return await fetch(backUrlCount + "/getNumberTypeMeal/"+ 3 + "/" + idMemberMenu)
        .then(response => response.json())
        .then(data3 => {
            let remainingMainCourses = data3 - mainCourseCount;

            while (remainingMainCourses < 0 && mainCourseCount > 0) {
                let index = listeTypeMeal.lastIndexOf(3);

                if (index !== -1) {
                    listeTypeMeal.splice(index, 1);
                    listeRecettes.splice(index, 1);

                        mainCourseCount--;
                       remainingMainCourses++;
                }
                localStorage.setItem('listeTypeMeal', JSON.stringify(listeTypeMeal));
                   localStorage.setItem('listeRecettes', JSON.stringify(listeRecettes));

            }

            if (remainingMainCourses < 0) {
                remainingMainCourses = 0;
            }

            let element = document.getElementById('platsPrincipauxRestants');
            element.innerHTML = "<b>" + remainingMainCourses + "</b> Plats principaux";
            return remainingMainCourses;
        })
        .catch(error => console.error('Erreur:', error));
}

// For starters
async function updateStarterCount() {
    let listeTypeMeal = JSON.parse(localStorage.getItem('listeTypeMeal'));
        let listeRecettes = JSON.parse(localStorage.getItem('listeRecettes'));

    if (listeTypeMeal === null) {
        listeTypeMeal = [];
    }

    if (listeRecettes === null) {
        listeRecettes = [];
     }

    let starterCount = 0;
    for (let i = 0; i < listeTypeMeal.length; i++) {
        if (listeTypeMeal[i] === 4) {
            starterCount++;
        }
    }

    let idMemberMenu = memberMenu.idMemberMenu;
    return await fetch(backUrlCount + "/getNumberTypeMeal/"+ 4 + "/" + idMemberMenu)
        .then(response => response.json())
        .then(data4 => {
            let remainingStarters = data4 - starterCount;


            while (remainingStarters < 0 && starterCount > 0) {
                let index = listeTypeMeal.indexOf(4);

                if (index !== -1) {
                    listeTypeMeal.splice(index, 1);
                    listeRecettes.splice(index, 1);

                    starterCount--;
                    remainingStarters++;
                }
                localStorage.setItem('listeTypeMeal', JSON.stringify(listeTypeMeal));
                localStorage.setItem('listeRecettes', JSON.stringify(listeRecettes));

            }

            if (remainingStarters < 0) {
                 remainingStarters = 0;
            }

            let element = document.getElementById('entreesRestants');
            element.innerHTML = "<b>" + remainingStarters + "</b> Entrées";
            return remainingStarters;
        })
        .catch(error => console.error('Erreur:', error));
}

// For desserts
async function updateDessertCount() {
    let listeTypeMeal = JSON.parse(localStorage.getItem('listeTypeMeal'));
        let listeRecettes = JSON.parse(localStorage.getItem('listeRecettes'));

    if (listeTypeMeal === null) {
        listeTypeMeal = [];
    }

    if (listeRecettes === null) {
                listeRecettes = [];
            }

    let dessertCount = 0;
    for (let i = 0; i < listeTypeMeal.length; i++) {
        if (listeTypeMeal[i] === 5) {
            dessertCount++;
        }
    }

    let idMemberMenu = memberMenu.idMemberMenu;
    return await fetch(backUrlCount + "/getNumberTypeMeal/"+ 5 + "/" + idMemberMenu)
        .then(response => response.json())
        .then(data5 => {
            let remainingDesserts = data5 - dessertCount;

            while (remainingDesserts < 0 && dessertCount > 0) {
                let index = listeTypeMeal.indexOf(5);
                if (index !== -1) {
                    listeTypeMeal.splice(index, 1);
                    listeRecettes.splice(index, 1);

                    dessertCount--;
                    remainingDesserts++;
                }
                localStorage.setItem('listeTypeMeal', JSON.stringify(listeTypeMeal));
                localStorage.setItem('listeRecettes', JSON.stringify(listeRecettes));
            }

            if (remainingDesserts < 0) {
                  remainingDesserts = 0;
            }

            let element = document.getElementById('dessertsRestants');
            element.innerHTML = "<b>" + remainingDesserts + "</b> Desserts";
            return remainingDesserts;
        })
        .catch(error => console.error('Erreur:', error));
}

window.addEventListener('storage', function(e) {
    if (e.key === 'listeTypeMeal') {
        updateMainCourseCount();
        updateStarterCount();
        updateDessertCount();
    }
});

document.addEventListener('DOMContentLoaded', (event) => {
    updateBreakfastCount();
    updateSnackCount();
    updateMainCourseCount();
    updateStarterCount();
    updateDessertCount();
});




