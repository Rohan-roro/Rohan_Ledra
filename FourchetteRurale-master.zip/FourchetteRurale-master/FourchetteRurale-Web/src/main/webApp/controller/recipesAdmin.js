// Fonction pour ajouter l'ID de la recette à une liste lorsque l'image est cliquée
console.log("recipes.js chargé");

// Ajouter les élements sélectionnés à une liste + border vert au tour pour les identifier
function ajouterRecette(element, recipe) {
    // Récupérer la liste de recettes existante depuis le stockage local
    var listeRecettesJSON = localStorage.getItem('listeRecettes');
    var listeTypeMealJSON = localStorage.getItem('listeTypeMeal');
    var listeRecettes = [];
    var listeTypeMeal = [];

    if (listeRecettesJSON) {
        // Convertir la chaîne JSON en tableau JavaScript
        listeRecettes = JSON.parse(listeRecettesJSON);
    }

     if (listeTypeMealJSON) {
            // Convertir la chaîne JSON en tableau JavaScript
            listeTypeMeal = JSON.parse(listeTypeMealJSON);
        }

    // Récupérer l'ID de la recette à partir de l'élément cliqué
    var idRecette = recipe.id_recipe;
    var idTypeMeal = recipe.id_type_meal;
    console.log(recipe.name);
    // Vérifier si l'ID de la recette est déjà dans la liste
    var index = listeRecettes.indexOf(idRecette);

    if (index !== -1) {
        // Si l'ID de la recette est déjà dans la liste, la supprimer
        listeRecettes.splice(index, 1);
        listeTypeMeal.splice(index, 1);
        element.style.border = '2px solid red';
        console.log("L'élément avec l'ID", idRecette, "a été enlevé du tableau.");
    } else {
        // Sinon, ajouter l'ID de la recette à la liste
        listeRecettes.push(idRecette);
        listeTypeMeal.push(idTypeMeal);
        // Appliquer une bordure verte à l'image
        element.style.border = '2px solid green';
        console.log("élément ajouté");
    }

    console.log("Liste des recettes sélectionnées :", listeRecettes);
    console.log("Liste des type de repas sélectionnées :", listeTypeMeal);

    // Convertir le tableau en chaîne JSON et l'enregistrer dans le stockage local
    var listeRecettesJSON = JSON.stringify(listeRecettes);
    var listeTypeMeal = JSON.stringify(listeTypeMeal);
    localStorage.setItem('listeRecettes', listeRecettesJSON);
    localStorage.setItem('listeTypeMeal', listeTypeMeal);
    console.log("listeRecettesJSON :", listeRecettesJSON);
    console.log("listeTypeMeal :", listeTypeMeal);
}
