const backUrl = window.location.origin + "/api/rest/member/authenticate";

(() => addActionToConnectionButton())();

function addActionToConnectionButton() {
    const connectionButton = document.getElementById("connectionButton");
    connectionButton.addEventListener("click", function(event) {
        authenticateMember(event);
        authenticateAdmin(event);
        authenticateDeliveryPerson(event);
    });
}

function authenticateMember(event) {
    event.preventDefault();
    const login = document.getElementById('loginInput').value;
    const password = document.getElementById('passwordInput').value;
    const requestOptions = {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ emailAdress: login, password: password})
    };
    fetch(backUrl, requestOptions)
        .then(response => response.text())
        .then(text => {
            if (text !== "") {
                const json = JSON.parse(text);
                console.log(json)
                const member = {
                    idMember: json.idMember,
                    civility: json.civility,
                    city: json.city,
                    firstname: json.firstname,
                    lastname: json.lastname,
                    emailAdress: json.emailAdress,
                    birthdate: json.birthdate,
                    phoneNumber: json.phoneNumber,
                    password: json.password,
                    shippingAddress: json.shippingAddress,
                    billingAddress: json.billingAddress,
                    registrationDate: json.registrationDate,
                }
                localStorage.setItem("member", JSON.stringify(member));
                localStorage.setItem("navigationHtml", "./MemberPages/landingPage.html");

                // Fetch monthly membership data
                const monthlyMembershipUrl = window.location.origin + "/api/rest/member/monthlymembership/" + member.idMember;
                fetch(monthlyMembershipUrl)
                    .then(response => response.json())
                    .then(monthlyMembership => {
                        localStorage.setItem("monthlyMembership", JSON.stringify(monthlyMembership));
                    })
                    .catch(error => {
                        console.error('Error:', error);
                    });

                    const lastOrderUrl = window.location.origin + "/api/rest/order/lastorder/" + member.idMember;
                    fetch(lastOrderUrl)
                        .then(response => response.json())
                        .then(lastOrder => {
                            localStorage.setItem("lastOrder", JSON.stringify(lastOrder));

                        })
                        .catch(error => {
                            console.error('Error:', error);
                        });

                        const MemberMenuUrl = window.location.origin + "/api/rest/memberMenu/get/" + member.idMember;
                        fetch(MemberMenuUrl)
                            .then(response => response.json())
                            .then(memberMenu => {
                                localStorage.setItem("memberMenu", JSON.stringify(memberMenu));
                                window.location.href = '/MemberPages/landingPage.html';
                            })
                            .catch(error => {
                                console.error('Error:', error);
                            });

            } else {
                incorrectLoginDisplay();
            }
        })
        .catch(error => {
            console.error('Error:', error);
        });

}

const backUrladmin = window.location.origin + "/api/rest/admin/authenticate";


function authenticateAdmin(event) {
    event.preventDefault();
    const login = document.getElementById('loginInput').value;
    const password = document.getElementById('passwordInput').value;
    const requestOptions = {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ loginAdmin: login, passwordAdmin: password})
    };
    fetch(backUrladmin, requestOptions)
        .then(response => response.text())
        .then(text => {
            if (text !== "") {
                const json = JSON.parse(text);
                console.log(json)
                const admin = {
                    idAdmin: json.idAdmin,
                    loginAdmin: json.loginAdmin,
                    passwordAdmin: json.passwordAdmin,
                }
                localStorage.setItem("admin", JSON.stringify(admin));
                localStorage.setItem("navigationHtml", "./AdminPages/actualOffer.html");
                window.location.href = '/AdminPages/actualOffer.html';
            } else {
                incorrectLoginDisplay();
            }
        })
        .catch(error => {
            console.error('Error:', error);
        });
}

const backUrlDeliveryPerson = window.location.origin + "/api/rest/deliveryPerson/authenticate";

function authenticateDeliveryPerson(event) {
    event.preventDefault();
    const email = document.getElementById('loginInput').value;
    const password = document.getElementById('passwordInput').value;
    const requestOptions = {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: email, password: password})
    };
    fetch(backUrlDeliveryPerson, requestOptions)
        .then(response => response.text())
        .then(text => {
            if (text !== "") {
                const json = JSON.parse(text);
                console.log(json)
                const deliveryPerson = {
                    id_delivery_person: json.id_delivery_person,
                    email: json.email,
                    firstname: json.firstname,
                    lastname: json.lastname,
                    id_civility: json.id_civility,
                    phone: json.phone,
                    password: json.password,
                }
                localStorage.setItem("deliveryPerson", JSON.stringify(deliveryPerson));
                localStorage.setItem("navigationHtml", "./DeliveryPersonPages/landingPage.html");
                window.location.href = '/DeliveryPages/deliveryPage.html';
            } else {
                incorrectLoginDisplay();
            }
        })
        .catch(error => {
            console.error('Error:', error);
        });
}

