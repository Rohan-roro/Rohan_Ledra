// Sélectionnez toutes les listes déroulantes
var selectElements = document.querySelectorAll('select');

// Parcourez chaque liste déroulante
selectElements.forEach(function(selectElement) {
    // Ajoutez un écouteur d'événements 'change' à chaque liste déroulante
    selectElement.addEventListener('change', function() {
        // Mettez à jour le résumé des sélections
        updateSummary();
    });
});

function updateSummary() {
    // Sélectionnez les éléments du résumé
    var petitDejeunerSummary = document.querySelector('#summary li:nth-child(1) em');
    var collationSummary = document.querySelector('#summary li:nth-child(2) em');
    var repasPrincipalSummary = document.querySelector('#summary li:nth-child(3) em');
    var entreeSummary = document.querySelector('#summary li:nth-child(4) em');
    var dessertSummary = document.querySelector('#summary li:nth-child(5) em');

    // Mettez à jour les valeurs du résumé
    petitDejeunerSummary.textContent = parseInt(document.querySelector('#nb_petit_dejeuner_lundi').value) + parseInt(document.querySelector('#nb_petit_dejeuner_mardi').value) + parseInt(document.querySelector('#nb_petit_dejeuner_mercredi').value) + parseInt(document.querySelector('#nb_petit_dejeuner_jeudi').value) + parseInt(document.querySelector('#nb_petit_dejeuner_vendredi').value) + parseInt(document.querySelector('#nb_petit_dejeuner_samedi').value) + parseInt(document.querySelector('#nb_petit_dejeuner_dimanche').value);    collationSummary.textContent = document.querySelector('#nb_collation_lundi').value;
    collationSummary.textContent = parseInt(document.querySelector('#nb_collation_lundi').value) + parseInt(document.querySelector('#nb_collation_mardi').value) + parseInt(document.querySelector('#nb_collation_mercredi').value) + parseInt(document.querySelector('#nb_collation_jeudi').value) + parseInt(document.querySelector('#nb_collation_vendredi').value) + parseInt(document.querySelector('#nb_collation_samedi').value) + parseInt(document.querySelector('#nb_collation_dimanche').value);
    repasPrincipalSummary.textContent = parseInt(document.querySelector('#nb_repas_lundi').value) + parseInt(document.querySelector('#nb_repas_mardi').value) + parseInt(document.querySelector('#nb_repas_mercredi').value) + parseInt(document.querySelector('#nb_repas_jeudi').value) + parseInt(document.querySelector('#nb_repas_vendredi').value) + parseInt(document.querySelector('#nb_repas_samedi').value) + parseInt(document.querySelector('#nb_repas_dimanche').value);
    entreeSummary.textContent = parseInt(document.querySelector('#nb_entree_lundi').value) + parseInt(document.querySelector('#nb_entree_mardi').value) + parseInt(document.querySelector('#nb_entree_mercredi').value) + parseInt(document.querySelector('#nb_entree_jeudi').value) + parseInt(document.querySelector('#nb_entree_vendredi').value) + parseInt(document.querySelector('#nb_entree_samedi').value) + parseInt(document.querySelector('#nb_entree_dimanche').value);
    dessertSummary.textContent = parseInt(document.querySelector('#nb_dessert_lundi').value) + parseInt(document.querySelector('#nb_dessert_mardi').value) + parseInt(document.querySelector('#nb_dessert_mercredi').value) + parseInt(document.querySelector('#nb_dessert_jeudi').value) + parseInt(document.querySelector('#nb_dessert_vendredi').value) + parseInt(document.querySelector('#nb_dessert_samedi').value) + parseInt(document.querySelector('#nb_dessert_dimanche').value);
}