console.log('meansPaiment.js loaded');

const backUrlMeansPaiment = window.location.origin + "/api/rest/meansPaiment";

// Récupérer l'élément select dans lequel vous voulez ajouter les options
let selectElement = document.getElementById('selectPayment');

// Faire une requête fetch à votre API pour obtenir les moyens de paiement
fetch(backUrlMeansPaiment +'/all')
    .then(response => response.json())
    .then(data => {
        // Pour chaque moyen de paiement, créer une nouvelle option et l'ajouter au select
        data.forEach(meansPaiment => {
            let option = document.createElement('option');
            option.value = meansPaiment.idMeansPaiment;
            option.text = meansPaiment.meansPaiment;
            selectElement.add(option);
        });
    })
    .catch(error => console.error('Error:', error));