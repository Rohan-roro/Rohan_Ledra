// Select the "Create Offer" button
console.log('WeeklyOfferCreateController.js');

const backUrl3 = window.location.origin + "/api/rest/weeklyOfferCreate";
const createOfferButton = document.getElementById('createOffer');

// Add an event handler to the button
createOfferButton.addEventListener('click', function() {
    // Retrieve the start and end dates of the offer
    const startDate = document.getElementById('startDate').value;
    const endDate = document.getElementById('endDate').value;

    // Create the offer object
    const offer = {
        start_date: startDate,
        end_date: endDate
    };

    // Send a POST request to your API
    fetch(backUrl3 +'/create', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(offer)
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return response.text();
    })
    .then(text => text.length ? JSON.parse(text) : {})
    .then(data => {
        console.log('Offre créée avec succès:', data);

        // Display the success message
        alert('Offre hebdomadaire créée avec succès');

        localStorage.removeItem('listeTypeMeal');
            localStorage.removeItem('listeRecettes');
        location.reload();
    })
    .catch(error => {
        console.error('Erreur:', error);
        alert("Erreur lors de la création de l'offre: ");
    });
});