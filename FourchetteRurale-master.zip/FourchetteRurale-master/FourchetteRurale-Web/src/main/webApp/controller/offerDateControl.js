console.log("offerDateControl.js chargé");
document.addEventListener('DOMContentLoaded', function() {
    // Obtenir la date actuelle
    var currentDate = new Date();

    // Trouver le jour de la semaine correspondant à la date actuelle
    var currentDayOfWeek = currentDate.getDay();

    // Ajouter les jours nécessaires pour atteindre le prochain lundi
    var daysToAddMonday = 15 - currentDayOfWeek; // 8 correspond au lundi
    if (currentDayOfWeek === 0) { // Si c'est dimanche
        daysToAddMonday = 8; // Prochain lundi
    }


    var nextMonday = new Date(currentDate);
    nextMonday.setDate(currentDate.getDate() + daysToAddMonday);

    // Formater la date au format "AAAA-MM-JJ" pour le lundi de la semaine suivante
    var nextMondayFormatted = formatDate(nextMonday);

    // Définir la date minimale autorisée pour le startDate (lundi)
    var startDate = document.getElementById('startDate');
    startDate.setAttribute('min', nextMondayFormatted);
    startDate.setAttribute('max', nextMondayFormatted); // Limiter au lundi seulement

    // Ajouter 6 jours à la date de début pour obtenir le dimanche de la même semaine
    var nextSunday = new Date(nextMonday);
    nextSunday.setDate(nextMonday.getDate() + 6);

    // Formater la date au format "AAAA-MM-JJ" pour le dimanche de la même semaine
    var nextSundayFormatted = formatDate(nextSunday);

    // Définir la date maximale autorisée pour le endDate (dimanche)
    var endDate = document.getElementById('endDate');
    endDate.setAttribute('min', nextSundayFormatted);
    endDate.setAttribute('max', nextSundayFormatted); // Limiter au dimanche seulement
});

// Fonction pour formater la date au format "AAAA-MM-JJ"
function formatDate(date) {
    var year = date.getFullYear();
    var month = ('0' + (date.getMonth() + 1)).slice(-2);
    var day = ('0' + date.getDate()).slice(-2);
    return year + '-' + month + '-' + day;
}
