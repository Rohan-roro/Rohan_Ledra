console.log("recipes.js chargé");

    // Récupérer les éléments du DOM POUR AJOUTER QUANTITE PAR RECETTE
    const decrementButton = document.getElementById('decrementButton');
    const incrementButton = document.getElementById('incrementButton');
    const quantityInput = document.getElementById('quantityInput');

// Écouteur d'événement pour le bouton de décrémentation
document.addEventListener('click', function(event) {
    if (event.target.id === 'decrementButton') {
        const quantityInput = event.target.parentNode.querySelector('#quantityInput');
        let currentValue = parseInt(quantityInput.value);
        if (currentValue > 1) {
            quantityInput.value = currentValue - 1;
        }
    }
});

// Écouteur d'événement pour le bouton d'incrément
document.addEventListener('click', function(event) {
    if (event.target.id === 'incrementButton') {
        const quantityInput = event.target.parentNode.querySelector('#quantityInput');
        let currentValue = parseInt(quantityInput.value);
        quantityInput.value = currentValue + 1;
    }
});



async function ajouterRecette(element, recipe) {
// Récupérer le nombre de petits déjeuners restants
    let remainingBreakfasts = updateBreakfastCount();

    // Si le nombre de petits déjeuners restants est égal à 0
    if (remainingBreakfasts === 0) {
        // Afficher une alerte et arrêter l'exécution de la fonction
        alert("Impossible d'ajouter un petit déjeuner, il n'en reste plus.");
        return;
    }

    var listeRecettesJSON = localStorage.getItem('listeRecettes');
    var listeTypeMealJSON = localStorage.getItem('listeTypeMeal');
    var listeRecettes = listeRecettesJSON ? JSON.parse(listeRecettesJSON) : [];
    var listeTypeMeal = listeTypeMealJSON ? JSON.parse(listeTypeMealJSON) : [];

    var idRecette = recipe.id_recipe;
    var idTypeMeal = recipe.id_type_meal;

    const quantityInput = document.getElementById('quantityInput');

    // Récupérer la quantité actuelle depuis l'input
    var quantite = parseInt(quantityInput.value, 10);

    console.log("quantité : " + quantite);
    // Ajoutez la logique pour gérer les valeurs non numériques ou inattendues si nécessaire
    if (isNaN(quantite) || quantite <= 0) {
        console.error('Quantité invalide sélectionnée.');
        return; // Quitter la fonction si la quantité n'est pas valide
    }

    console.log(recipe.name);


// Vérifier si l'ID de la recette est déjà dans la liste
    var index = listeRecettes.indexOf(idRecette);



 // Ajouter l'ID de la recette et le type de repas le nombre de fois indiqué
    for (let i = 0; i < quantite; i++) {
        listeRecettes.push(idRecette);
        listeTypeMeal.push(idTypeMeal);
        console.log("boucle for pour ajouter id recette")
    }


    console.log(quantite > 0 ? "Élément(s) ajouté(s)." : "Aucun élément ajouté.");

    console.log("Liste des recettes sélectionnées :", listeRecettes);
    console.log("Liste des type de repas sélectionnées :", listeTypeMeal);

    localStorage.setItem('listeRecettes', JSON.stringify(listeRecettes));
    localStorage.setItem('listeTypeMeal', JSON.stringify(listeTypeMeal));
   await updateBreakfastCount();
}



