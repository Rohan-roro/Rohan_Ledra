const backUrl = window.location.origin + "/api/rest/recipe";

document.getElementById('recipeForm').addEventListener('submit', function(event) {
    event.preventDefault();

    let name = document.getElementById('name').value;
    let description = document.getElementById('description').value;
    let ingredients = document.getElementById('ingredients').value;
    let mealType = document.getElementById('mealType').value;

    let imageUpload = document.getElementById('imageUpload').files[0];

    let recipe = {
        id_recipe: null,
        id_type_meal: mealType, // Assurez-vous que cette valeur correspond à l'ID correct du type de repas
        name: name,
        ingredients: ingredients,
        photo: imageUpload ? imageUpload.name : null, // Utilisez le nom du fichier
        description: description,
        creation_date: new Date().toISOString().split('T')[0], // Utilise la date actuelle
        deletion_date: null
    };

    console.log(recipe); // Ajoutez cette ligne pour voir l'objet recipe dans la console

    // Envoi des données au serveur
    fetch(backUrl + "/create", {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(recipe)
    }).then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return response.text();
    }).then(text => text.length ? JSON.parse(text) : {})
          .then(data => {
              console.log(data);

              // Display the success message
              alert('Votre recette a bien été enregistrée');
              location.reload();
          })
          .catch((error) => {
              console.error('Error:', error);
              alert("Votre recette n'a bien pas été enregistrée");
          });
      });