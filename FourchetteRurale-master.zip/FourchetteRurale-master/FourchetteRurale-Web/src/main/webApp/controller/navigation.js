// VALIDER L'OFFRE (createOffer.hmtl)
    var validateButton = document.getElementById('validateButton');

    validateButton.addEventListener('click', function() {
        window.location.href = 'validateOffer.html';
    });


