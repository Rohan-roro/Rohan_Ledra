console.log("slotController.js");

const backUrlSlot = window.location.origin + "/api/rest/slot";


let select = document.getElementById("hour-delivery");

// Faire une requête GET à l'API pour obtenir tous les créneaux
fetch(backUrlSlot + "/all") // Remplacez par l'URL de votre API
    .then(response => response.json())
    .then(slots => {
        // Parcourir la liste des créneaux
        for(let i = 0; i < slots.length; i++) {
            // Créer une nouvelle option
            let option = document.createElement("option");
            option.value = slots[i].idSlot; // Utiliser l'ID du créneau comme valeur
            option.text = slots[i].startHour + ' - ' + slots[i].endHour; // Utiliser les heures de début et de fin comme texte

            // Ajouter l'option à la liste déroulante
            select.add(option);
        }
    })
    .catch(error => console.error('Erreur:', error));