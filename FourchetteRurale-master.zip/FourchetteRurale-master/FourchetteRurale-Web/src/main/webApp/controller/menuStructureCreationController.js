console.log('Hello from menuStructureCreationController.js');

const backUrl = window.location.origin + "/api/rest/choiceMemberMenu";
// Retrieve the stored object from local storage
let storedObject = localStorage.getItem('memberMenu');

// Parse the JSON string back into an object
let parsedObject = JSON.parse(storedObject);

// Access the idMemberMenu property
let idMemberMenu = parsedObject.idMemberMenu;

document.querySelector('.saveNewStructure').addEventListener('click', function(event) {
    event.preventDefault();

    // Envoi des données pour le lundi
    var nb_petit_dejeuner_lundi = document.querySelector('#nb_petit_dejeuner_lundi');
    var nb_collation_lundi = document.querySelector('#nb_collation_lundi');
    var nb_repas_lundi = document.querySelector('#nb_repas_lundi');
    var nb_entree_lundi = document.querySelector('#nb_entree_lundi');
    var nb_dessert_lundi = document.querySelector('#nb_dessert_lundi');

   //recuperation du membre connecté


    var data1 = {
        idMemberMenu: idMemberMenu, // Remplacez par l'ID du membre connecté
        idTypeMeal: 1, // Pour le petit déjeuner
        idDay: 1, // Pour le lundi
        quantity: nb_petit_dejeuner_lundi.value // La quantité sélectionnée dans la liste déroulante
    };

    var data2 = {
        idMemberMenu: idMemberMenu, // Remplacez par l'ID du membre connecté
        idTypeMeal: 2, // Pour la collation
        idDay: 1, // Pour le lundi
        quantity: nb_collation_lundi.value // La quantité sélectionnée dans la liste déroulante
    };

    var data3 = {
        idMemberMenu: idMemberMenu, // Remplacez par l'ID du membre connecté
        idTypeMeal: 3, // Pour le plat principal
        idDay: 1, // Pour le lundi
        quantity: nb_repas_lundi.value // La quantité sélectionnée dans la liste déroulante
    };

    var data4 = {
        idMemberMenu: idMemberMenu, // Remplacez par l'ID du membre connecté
        idTypeMeal: 4, // Pour l'entrée
        idDay: 1, // Pour le lundi
        quantity: nb_entree_lundi.value // La quantité sélectionnée dans la liste déroulante
    };

    var data5 = {
        idMemberMenu: idMemberMenu, // Remplacez par l'ID du membre connecté
        idTypeMeal: 5, // Pour le dessert
        idDay: 1, // Pour le lundi
        quantity: nb_dessert_lundi.value // La quantité sélectionnée dans la liste déroulante
    };


    // Envoi de la première ligne à la base de données si la valeur sélectionnée n'est pas 0
    if (nb_petit_dejeuner_lundi.value != 0) {
        fetch(backUrl + '/create', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data1),
        })
        .then(data => console.log('Success:', data))
        .catch((error) => console.error('Error:', error));
    }

    // Envoi de la deuxième ligne à la base de données si la valeur sélectionnée n'est pas 0
    if (nb_collation_lundi.value != 0) {
        fetch(backUrl + '/create', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data2),
        })
        .then(data => console.log('Success:', data))
        .catch((error) => console.error('Error:', error));
    }

    // Envoi de la troisième ligne à la base de données si la valeur sélectionnée n'est pas 0
    if (nb_repas_lundi.value != 0) {
        fetch(backUrl + '/create', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data3),
        })
        .then(data => console.log('Success:', data))
        .catch((error) => console.error('Error:', error));
    }

    // Envoi de la quatrième ligne à la base de données si la valeur sélectionnée n'est pas 0
    if (nb_entree_lundi.value != 0) {
        fetch(backUrl + '/create', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data4),
        })
        .then(data => console.log('Success:', data))
        .catch((error) => console.error('Error:', error));
    }

    // Envoi de la cinquième ligne à la base de données si la valeur sélectionnée n'est pas 0
    if (nb_dessert_lundi.value != 0) {
        fetch(backUrl + '/create', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data5),
        })
        .then(data => console.log('Success:', data))
        .catch((error) => console.error('Error:', error));
    }

    // Envoi des données pour le mardi
        var nb_petit_dejeuner_mardi = document.querySelector('#nb_petit_dejeuner_mardi');
        var nb_collation_mardi = document.querySelector('#nb_collation_mardi');
        var nb_repas_mardi = document.querySelector('#nb_repas_mardi');
        var nb_entree_mardi = document.querySelector('#nb_entree_mardi');
        var nb_dessert_mardi = document.querySelector('#nb_dessert_mardi');

        var data6 = {
            idMemberMenu: idMemberMenu, // Remplacez par l'ID du membre connecté
            idTypeMeal: 1, // Pour le petit déjeuner
            idDay: 2, // Pour le mardi
            quantity: nb_petit_dejeuner_mardi.value // La quantité sélectionnée dans la liste déroulante
        };

        var data7 = {
            idMemberMenu: idMemberMenu, // Remplacez par l'ID du membre connecté
            idTypeMeal: 2, // Pour la collation
            idDay: 2, // Pour le mardi
            quantity: nb_collation_mardi.value // La quantité sélectionnée dans la liste déroulante
        };

        var data8 = {
            idMemberMenu: idMemberMenu, // Remplacez par l'ID du membre connecté
            idTypeMeal: 3, // Pour le plat principal
            idDay: 2, // Pour le mardi
            quantity: nb_repas_mardi.value // La quantité sélectionnée dans la liste déroulante
        };

        var data9 = {
            idMemberMenu: idMemberMenu, // Remplacez par l'ID du membre connecté
            idTypeMeal: 4, // Pour l'entrée
            idDay: 2, // Pour le mardi
            quantity: nb_entree_mardi.value // La quantité sélectionnée dans la liste déroulante
        };

        var data10 = {
            idMemberMenu: idMemberMenu, // Remplacez par l'ID du membre connecté
            idTypeMeal: 5, // Pour le dessert
            idDay: 2, // Pour le mardi
            quantity: nb_dessert_mardi.value // La quantité sélectionnée dans la liste déroulante
        };

        // Envoi de la première ligne à la base de données si la valeur sélectionnée n'est pas 0
        if (nb_petit_dejeuner_mardi.value != 0) {
            fetch(backUrl + '/create', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data6),
            })
            .then(data => console.log('Success:', data))
            .catch((error) => console.error('Error:', error));
        }

        // Envoi de la deuxième ligne à la base de données si la valeur sélectionnée n'est pas 0

        if (nb_collation_mardi.value != 0) {
            fetch(backUrl + '/create', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data7),
            })
            .then(data => console.log('Success:', data))
            .catch((error) => console.error('Error:', error));
        }

        // Envoi de la troisième ligne à la base de données si la valeur sélectionnée n'est pas 0

        if (nb_repas_mardi.value != 0) {
            fetch(backUrl + '/create', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data8),
            })
            .then(data => console.log('Success:', data))
            .catch((error) => console.error('Error:', error));
        }

        // Envoi de la quatrième ligne à la base de données si la valeur sélectionnée n'est pas 0

        if (nb_entree_mardi.value != 0) {
            fetch(backUrl + '/create', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data9),
            })
            .then(data => console.log('Success:', data))
            .catch((error) => console.error('Error:', error));
        }

        // Envoi de la cinquième ligne à la base de données si la valeur sélectionnée n'est pas 0

        if (nb_dessert_mardi.value != 0) {
            fetch(backUrl + '/create', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data10),
            })
            .then(data => console.log('Success:', data))
            .catch((error) => console.error('Error:', error));
        }

        // Envoi des données pour le mercredi
        var nb_petit_dejeuner_mercredi = document.querySelector('#nb_petit_dejeuner_mercredi');
        var nb_collation_mercredi = document.querySelector('#nb_collation_mercredi');
        var nb_repas_mercredi = document.querySelector('#nb_repas_mercredi');
        var nb_entree_mercredi = document.querySelector('#nb_entree_mercredi');
        var nb_dessert_mercredi = document.querySelector('#nb_dessert_mercredi');

        var data11 = {
            idMemberMenu: idMemberMenu, // Remplacez par l'ID du membre connecté
            idTypeMeal: 1, // Pour le petit déjeuner
            idDay: 3, // Pour le mercredi
            quantity: nb_petit_dejeuner_mercredi.value // La quantité sélectionnée dans la liste déroulante
        };

        var data12 = {
            idMemberMenu: idMemberMenu, // Remplacez par l'ID du membre connecté
            idTypeMeal: 2, // Pour la collation
            idDay: 3, // Pour le mercredi
            quantity: nb_collation_mercredi.value // La quantité sélectionnée dans la liste déroulante
        };

        var data13 = {
            idMemberMenu: idMemberMenu, // Remplacez par l'ID du membre connecté
            idTypeMeal: 3, // Pour le plat principal
            idDay: 3, // Pour le mercredi
            quantity: nb_repas_mercredi.value // La quantité sélectionnée dans la liste déroulante
        };

        var data14 = {
            idMemberMenu: idMemberMenu, // Remplacez par l'ID du membre connecté
            idTypeMeal: 4, // Pour l'entrée
            idDay: 3, // Pour le mercredi
            quantity: nb_entree_mercredi.value // La quantité sélectionnée dans la liste déroulante
        };

        var data15 = {
            idMemberMenu: idMemberMenu, // Remplacez par l'ID du membre connecté
            idTypeMeal: 5, // Pour le dessert
            idDay: 3, // Pour le mercredi
            quantity: nb_dessert_mercredi.value // La quantité sélectionnée dans la liste déroulante
        };

        // Envoi de la première ligne à la base de données si la valeur sélectionnée n'est pas 0
        if (nb_petit_dejeuner_mercredi.value != 0) {
            fetch(backUrl + '/create', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data11),
            })
            .then(data => console.log('Success:', data))
            .catch((error) => console.error('Error:', error));
        }

        // Envoi de la deuxième ligne à la base de données si la valeur sélectionnée n'est pas 0
        if (nb_collation_mercredi.value != 0) {
            fetch(backUrl + '/create', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data12),
            })
            .then(data => console.log('Success:', data))
            .catch((error) => console.error('Error:', error));
        }

        // Envoi de la troisième ligne à la base de données si la valeur sélectionnée n'est pas 0
        if (nb_repas_mercredi.value != 0) {
            fetch(backUrl + '/create', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data13),
            })
            .then(data => console.log('Success:', data))
            .catch((error) => console.error('Error:', error));
        }

        // Envoi de la quatrième ligne à la base de données si la valeur sélectionnée n'est pas 0
        if (nb_entree_mercredi.value != 0) {
            fetch(backUrl + '/create', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data14),
            })
            .then(data => console.log('Success:', data))
            .catch((error) => console.error('Error:', error));
        }

        // Envoi de la cinquième ligne à la base de données si la valeur sélectionnée n'est pas 0
        if (nb_dessert_mercredi.value != 0) {
            fetch(backUrl + '/create', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data15),
            })
            .then(data => console.log('Success:', data))
            .catch((error) => console.error('Error:', error));
        }

        // Envoi des données pour le jeudi
        var nb_petit_dejeuner_jeudi = document.querySelector('#nb_petit_dejeuner_jeudi');
        var nb_collation_jeudi = document.querySelector('#nb_collation_jeudi');
        var nb_repas_jeudi = document.querySelector('#nb_repas_jeudi');
        var nb_entree_jeudi = document.querySelector('#nb_entree_jeudi');
        var nb_dessert_jeudi = document.querySelector('#nb_dessert_jeudi');

        var data16 = {
            idMemberMenu: idMemberMenu, // Remplacez par l'ID du membre connecté
            idTypeMeal: 1, // Pour le petit déjeuner
            idDay: 4, // Pour le jeudi
            quantity: nb_petit_dejeuner_jeudi.value // La quantité sélectionnée dans la liste déroulante
        };

        var data17 = {
            idMemberMenu: idMemberMenu, // Remplacez par l'ID du membre connecté
            idTypeMeal: 2, // Pour la collation
            idDay: 4, // Pour le jeudi
            quantity: nb_collation_jeudi.value // La quantité sélectionnée dans la liste déroulante
        };

        var data18 = {
            idMemberMenu: idMemberMenu, // Remplacez par l'ID du membre connecté
            idTypeMeal: 3, // Pour le plat principal
            idDay: 4, // Pour le jeudi
            quantity: nb_repas_jeudi.value // La quantité sélectionnée dans la liste déroulante
        };

        var data19 = {
            idMemberMenu: idMemberMenu, // Remplacez par l'ID du membre connecté
            idTypeMeal: 4, // Pour l'entrée
            idDay: 4, // Pour le jeudi
            quantity: nb_entree_jeudi.value // La quantité sélectionnée dans la liste déroulante
        };

        var data20 = {
            idMemberMenu: idMemberMenu, // Remplacez par l'ID du membre connecté
            idTypeMeal: 5, // Pour le dessert
            idDay: 4, // Pour le jeudi
            quantity: nb_dessert_jeudi.value // La quantité sélectionnée dans la liste déroulante
        };

        // Envoi de la première ligne à la base de données si la valeur sélectionnée n'est pas 0
        if (nb_petit_dejeuner_jeudi.value != 0) {
            fetch(backUrl + '/create', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data16),
            })
            .then(data => console.log('Success:', data))
            .catch((error) => console.error('Error:', error));
        }

        // Envoi de la deuxième ligne à la base de données si la valeur sélectionnée n'est pas 0

        if (nb_collation_jeudi.value != 0) {
            fetch(backUrl + '/create', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data17),
            })
            .then(data => console.log('Success:', data))
            .catch((error) => console.error('Error:', error));
        }

        // Envoi de la troisième ligne à la base de données si la valeur sélectionnée n'est pas 0

if (nb_repas_jeudi.value != 0) {
            fetch(backUrl + '/create', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data18),
            })
            .then(data => console.log('Success:', data))
            .catch((error) => console.error('Error:', error));
        }

        // Envoi de la quatrième ligne à la base de données si la valeur sélectionnée n'est pas 0

        if (nb_entree_jeudi.value != 0) {
            fetch(backUrl + '/create', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data19),
            })
            .then(data => console.log('Success:', data))
            .catch((error) => console.error('Error:', error));
        }

        // Envoi de la cinquième ligne à la base de données si la valeur sélectionnée n'est pas 0

        if (nb_dessert_jeudi.value != 0) {
            fetch(backUrl + '/create', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data20),
            })
            .then(data => console.log('Success:', data))
            .catch((error) => console.error('Error:', error));
        }

        // Envoi des données pour le vendredi
        var nb_petit_dejeuner_vendredi = document.querySelector('#nb_petit_dejeuner_vendredi');
        var nb_collation_vendredi = document.querySelector('#nb_collation_vendredi');
        var nb_repas_vendredi = document.querySelector('#nb_repas_vendredi');
        var nb_entree_vendredi = document.querySelector('#nb_entree_vendredi');
        var nb_dessert_vendredi = document.querySelector('#nb_dessert_vendredi');

        var data21 = {
            idMemberMenu: idMemberMenu, // Remplacez par l'ID du membre connecté
            idTypeMeal: 1, // Pour le petit déjeuner
            idDay: 5, // Pour le vendredi
            quantity: nb_petit_dejeuner_vendredi.value // La quantité sélectionnée dans la liste déroulante
        };

        var data22 = {
            idMemberMenu: idMemberMenu, // Remplacez par l'ID du membre connecté
            idTypeMeal: 2, // Pour la collation
            idDay: 5, // Pour le vendredi
            quantity: nb_collation_vendredi.value // La quantité sélectionnée dans la liste déroulante
        };

        var data23 = {
            idMemberMenu: idMemberMenu, // Remplacez par l'ID du membre connecté
            idTypeMeal: 3, // Pour le plat principal
            idDay: 5, // Pour le vendredi
            quantity: nb_repas_vendredi.value // La quantité sélectionnée dans la liste déroulante
        };

        var data24 = {
            idMemberMenu: idMemberMenu, // Remplacez par l'ID du membre connecté
            idTypeMeal: 4, // Pour l'entrée
            idDay: 5, // Pour le vendredi
            quantity: nb_entree_vendredi.value // La quantité sélectionnée dans la liste déroulante
        };

        var data25 = {
            idMemberMenu: idMemberMenu, // Remplacez par l'ID du membre connecté
            idTypeMeal: 5, // Pour le dessert
            idDay: 5, // Pour le vendredi
            quantity: nb_dessert_vendredi.value // La quantité sélectionnée dans la liste déroulante
        };

        // Envoi de la première ligne à la base de données si la valeur sélectionnée n'est pas 0
        if (nb_petit_dejeuner_vendredi.value != 0) {
            fetch(backUrl + '/create', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data21),
            })
            .then(data => console.log('Success:', data))
            .catch((error) => console.error('Error:', error));
        }

        // Envoi de la deuxième ligne à la base de données si la valeur sélectionnée n'est pas 0

        if (nb_collation_vendredi.value != 0) {
            fetch(backUrl + '/create', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data22),
            })
            .then(data => console.log('Success:', data))
            .catch((error) => console.error('Error:', error));
        }

        // Envoi de la troisième ligne à la base de données si la valeur sélectionnée n'est pas 0

        if (nb_repas_vendredi.value != 0) {
            fetch(backUrl + '/create', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data23),
            })
            .then(data => console.log('Success:', data))
            .catch((error) => console.error('Error:', error));
        }

        // Envoi de la quatrième ligne à la base de données si la valeur sélectionnée n'est pas 0

        if (nb_entree_vendredi.value != 0) {
            fetch(backUrl + '/create', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data24),
            })
            .then(data => console.log('Success:', data))
            .catch((error) => console.error('Error:', error));
        }

        // Envoi de la cinquième ligne à la base de données si la valeur sélectionnée n'est pas 0

        if (nb_dessert_vendredi.value != 0) {
            fetch(backUrl + '/create', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data25),
            })
            .then(data => console.log('Success:', data))
            .catch((error) => console.error('Error:', error));
        }

        // Envoi des données pour le samedi
        var nb_petit_dejeuner_samedi = document.querySelector('#nb_petit_dejeuner_samedi');
        var nb_collation_samedi = document.querySelector('#nb_collation_samedi');
        var nb_repas_samedi = document.querySelector('#nb_repas_samedi');
        var nb_entree_samedi = document.querySelector('#nb_entree_samedi');
        var nb_dessert_samedi = document.querySelector('#nb_dessert_samedi');

        var data26 = {
            idMemberMenu: idMemberMenu, // Remplacez par l'ID du membre connecté
            idTypeMeal: 1, // Pour le petit déjeuner
            idDay: 6, // Pour le samedi
            quantity: nb_petit_dejeuner_samedi.value // La quantité sélectionnée dans la liste déroulante
        };

        var data27 = {
            idMemberMenu: idMemberMenu, // Remplacez par l'ID du membre connecté
            idTypeMeal: 2, // Pour la collation
            idDay: 6, // Pour le samedi
            quantity: nb_collation_samedi.value // La quantité sélectionnée dans la liste déroulante
        };

        var data28 = {
            idMemberMenu: idMemberMenu, // Remplacez par l'ID du membre connecté
            idTypeMeal: 3, // Pour le plat principal
            idDay: 6, // Pour le samedi
            quantity: nb_repas_samedi.value // La quantité sélectionnée dans la liste déroulante
        };

        var data29 = {
            idMemberMenu: idMemberMenu, // Remplacez par l'ID du membre connecté
            idTypeMeal: 4, // Pour l'entrée
            idDay: 6, // Pour le samedi
            quantity: nb_entree_samedi.value // La quantité sélectionnée dans la liste déroulante
        };

        var data30 = {
            idMemberMenu: idMemberMenu, // Remplacez par l'ID du membre connecté
            idTypeMeal: 5, // Pour le dessert
            idDay: 6, // Pour le samedi
            quantity: nb_dessert_samedi.value // La quantité sélectionnée dans la liste déroulante
        };

        // Envoi de la première ligne à la base de données si la valeur sélectionnée n'est pas 0
        if (nb_petit_dejeuner_samedi.value != 0) {
            fetch(backUrl + '/create', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data26),
            })
            .then(data => console.log('Success:', data))
            .catch((error) => console.error('Error:', error));
        }

        // Envoi de la deuxième ligne à la base de données si la valeur sélectionnée n'est pas 0

        if (nb_collation_samedi.value != 0) {
            fetch(backUrl + '/create', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data27),
            })
            .then(data => console.log('Success:', data))
            .catch((error) => console.error('Error:', error));
        }

        // Envoi de la troisième ligne à la base de données si la valeur sélectionnée n'est pas 0

        if (nb_repas_samedi.value != 0) {
            fetch(backUrl + '/create', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data28),
            })
            .then(data => console.log('Success:', data))
            .catch((error) => console.error('Error:', error));
        }

        // Envoi de la quatrième ligne à la base de données si la valeur sélectionnée n'est pas 0

        if (nb_entree_samedi.value != 0) {
            fetch(backUrl + '/create', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data29),
            })
            .then(data => console.log('Success:', data))
            .catch((error) => console.error('Error:', error));
        }

        // Envoi de la cinquième ligne à la base de données si la valeur sélectionnée n'est pas 0

        if (nb_dessert_samedi.value != 0) {
            fetch(backUrl + '/create', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data30),
            })
            .then(data => console.log('Success:', data))
            .catch((error) => console.error('Error:', error));
        }

        // Envoi des données pour le dimanche
        var nb_petit_dejeuner_dimanche = document.querySelector('#nb_petit_dejeuner_dimanche');
        var nb_collation_dimanche = document.querySelector('#nb_collation_dimanche');
        var nb_repas_dimanche = document.querySelector('#nb_repas_dimanche');
        var nb_entree_dimanche = document.querySelector('#nb_entree_dimanche');
        var nb_dessert_dimanche = document.querySelector('#nb_dessert_dimanche');

        var data31 = {
            idMemberMenu: idMemberMenu, // Remplacez par l'ID du membre connecté
            idTypeMeal: 1, // Pour le petit déjeuner
            idDay: 7, // Pour le dimanche
            quantity: nb_petit_dejeuner_dimanche.value // La quantité sélectionnée dans la liste déroulante
        };

        var data32 = {
            idMemberMenu: idMemberMenu, // Remplacez par l'ID du membre connecté
            idTypeMeal: 2, // Pour la collation
            idDay: 7, // Pour le dimanche
            quantity: nb_collation_dimanche.value // La quantité sélectionnée dans la liste déroulante
        };

        var data33 = {
            idMemberMenu: idMemberMenu, // Remplacez par l'ID du membre connecté
            idTypeMeal: 3, // Pour le plat principal
            idDay: 7, // Pour le dimanche
            quantity: nb_repas_dimanche.value // La quantité sélectionnée dans la liste déroulante
        };

        var data34 = {
            idMemberMenu: idMemberMenu, // Remplacez par l'ID du membre connecté
            idTypeMeal: 4, // Pour l'entrée
            idDay: 7, // Pour le dimanche
            quantity: nb_entree_dimanche.value // La quantité sélectionnée dans la liste déroulante
        };

        var data35 = {
            idMemberMenu: idMemberMenu, // Remplacez par l'ID du membre connecté
            idTypeMeal: 5, // Pour le dessert
            idDay: 7, // Pour le dimanche
            quantity: nb_dessert_dimanche.value // La quantité sélectionnée dans la liste déroulante
        };

        // Envoi de la première ligne à la base de données si la valeur sélectionnée n'est pas 0
        if (nb_petit_dejeuner_dimanche.value != 0) {
            fetch(backUrl + '/create', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data31),
            })
            .then(data => console.log('Success:', data))
            .catch((error) => console.error('Error:', error));
        }

        // Envoi de la deuxième ligne à la base de données si la valeur sélectionnée n'est pas 0

        if (nb_collation_dimanche.value != 0) {
            fetch(backUrl + '/create', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data32),
            })
            .then(data => console.log('Success:', data))
            .catch((error) => console.error('Error:', error));
        }

        // Envoi de la troisième ligne à la base de données si la valeur sélectionnée n'est pas 0

        if (nb_repas_dimanche.value != 0) {
            fetch(backUrl + '/create', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data33),
            })
            .then(data => console.log('Success:', data))
            .catch((error) => console.error('Error:', error));
        }

        // Envoi de la quatrième ligne à la base de données si la valeur sélectionnée n'est pas 0

        if (nb_entree_dimanche.value != 0) {
            fetch(backUrl + '/create', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data34),
            })
            .then(data => console.log('Success:', data))
            .catch((error) => console.error('Error:', error));
        }

        // Envoi de la cinquième ligne à la base de données si la valeur sélectionnée n'est pas 0

        if (nb_dessert_dimanche.value != 0) {
            fetch(backUrl + '/create', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data35),
            })
            .then(data => console.log('Success:', data))
            .catch((error) => console.error('Error:', error));
        }

        window.location.href = 'paiement.html'; // Redirige vers la page de paiement

});