console.log("AddOrderRecipe.js chargé");
const backUrlAddOrderRecipe = window.location.origin + "/api/rest/order";
const backUrlGetcurrentWeekly = window.location.origin + "/api/rest/weeklyOfferCreate";
// Sélectionnez le bouton "Valider la commande"
let validateOrderButton = document.getElementById('createOrder');

// Ajoutez un gestionnaire d'événements 'click' au bouton
validateOrderButton.addEventListener('click', function() {
  // Récupérez les recettes du local storage
  let listeRecettesStr = localStorage.getItem('listeRecettes');
  let listeRecettes = listeRecettesStr && listeRecettesStr !== "" ? JSON.parse(listeRecettesStr) : [];

  // Assurez-vous que chaque idRecipe est un Long
  let idRecipes = listeRecettes.map(id => Number(id));

  // Récupérez l'objet membre du localStorage
  let memberStr = localStorage.getItem('member');

  // Convertissez la chaîne JSON en un objet JavaScript
  let member = memberStr && memberStr !== "" ? JSON.parse(memberStr) : {};

  // Récupérez l'ID du membre
  let memberId = member.idMember;



fetch(backUrlGetcurrentWeekly + "/current")
    .then(response => response.json())
    .then(currentWeeklyOffer => {
        console.log("currentWeeklyOffer", currentWeeklyOffer);
        // Perform a GET request to get the last order ID for this member
        fetch(backUrlAddOrderRecipe + '/lastorder/' + memberId)
            .then(response => response.json())
            .then(data => {
                let idOrder = data.idOrder; // Retrieve the order ID from the JSON response
                // For each idRecipe, send a request to the server
                idRecipes.forEach(idRecipe => {
                    // Create the JSON object
                    let contentOrderDto = {
                        idWeeklyOffer: currentWeeklyOffer, // replace with the id of the weekly offer
                        idOrder: idOrder + 1, // Replace with the retrieved order ID
                        idRecipe: idRecipe // idRecipe is now a Long
                    };

                    // Send the JSON object to the server
                    fetch(backUrlAddOrderRecipe + '/addRecipe', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify(contentOrderDto)
                    })
                    .then(response => response.json())
                    .then(data => console.log(data))
                    .catch((error) => {
                        console.error('Error:', error);
                    });
                });
            })
            .catch((error) => {
                console.error('Error:', error);
            });
    })
    .catch((error) => {
        console.error('Error:', error);
    });
});

