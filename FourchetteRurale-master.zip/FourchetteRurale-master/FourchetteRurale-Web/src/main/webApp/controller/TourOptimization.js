console.log('TourOptimization.js');
document.getElementById('saveButton').addEventListener('click', async function() {
    // Fetch the config.json file
    const configResponse = await fetch('../config.json');
    const config = await configResponse.json();

    let start = config.start.value;
    console.log('Start:', start); // Log the start address

    const apiKey = config.apiKey.value;
    const proxyUrl = 'https://cors-anywhere.herokuapp.com/';
    const backUrlSlot2 = window.location.origin + "/api/rest/slot";

    // Fetch all slots
    const slotsResponse = await fetch(backUrlSlot2 + "/all");
    const slots = await slotsResponse.json();

    const selectedDate = document.getElementById('deliveryDate').value;

    // Create a variable to store the Google Maps URL
    let googleMapsUrl = 'https://www.google.com/maps/dir/';

    for(let i = 0; i < slots.length; i++) {
        try {
            const addressesResponse = await fetch(`${window.location.origin}/api/rest/order/adress/${slots[i].idSlot}/${selectedDate}`);
            let addresses = await addressesResponse.json();
            const waypoints = addresses.map(address => encodeURIComponent(address.replace(/,/g, '')));

            // Get travel times for each waypoint from start
            const travelTimes = await Promise.all(waypoints.map(async waypoint => {
                const url = `https://maps.googleapis.com/maps/api/directions/json?origin=${encodeURIComponent(start)}&destination=${waypoint}&key=${apiKey}`;
                const response = await fetch(proxyUrl + url);
                const data = await response.json();
                return data.routes[0].legs[0].duration.value; // duration in seconds
            }));

            // Find the index of the longest travel time
            const longestTravelTimeIndex = travelTimes.indexOf(Math.max(...travelTimes));

            const url = `https://maps.googleapis.com/maps/api/directions/json?origin=${encodeURIComponent(start)}&destination=${waypoints[longestTravelTimeIndex]}&waypoints=optimize:true|${waypoints.join('|')}&key=${apiKey}`;

            const directionsResponse = await fetch(proxyUrl + url);
            if (!directionsResponse.ok) throw new Error('Network response was not ok');

            const data = await directionsResponse.json();

            // Get the optimized order of waypoints
            const optimizedOrder = data.routes[0].waypoint_order;

            // Create a new array of addresses in the optimized order
            const optimizedAddresses = optimizedOrder.map(index => addresses[index]);

            // Add the start and end addresses to the array
            optimizedAddresses.unshift(start);

            console.log('Adresses optimisées:', optimizedAddresses);

            // Add the optimized addresses to the Google Maps URL
            optimizedAddresses.forEach((address, index) => {
                if (index !== 0) { // Do not add the start address again
                    googleMapsUrl += encodeURIComponent(address) + '/';
                }
            });

            // Set the waypoint with the longest travel time as the destination
            const end = waypoints.splice(longestTravelTimeIndex, 1)[0];
            console.log('End:', decodeURIComponent(end)); // Log the end address

            // Set the end address of the current slot as the start address for the next slot
            start = decodeURIComponent(end);
            console.log('Next Start:', start); // Log the next start address
        } catch (error) {
            console.error('Error:', error);
        }
    }

    // Add the final destination to the Google Maps URL
    googleMapsUrl += encodeURIComponent(start);

    console.log('Google Maps URL:', googleMapsUrl);
    localStorage.setItem('tourItinerary', googleMapsUrl);
    alert('Création de la tournée optimisée réalisée avec succès.');
    location.reload();
});