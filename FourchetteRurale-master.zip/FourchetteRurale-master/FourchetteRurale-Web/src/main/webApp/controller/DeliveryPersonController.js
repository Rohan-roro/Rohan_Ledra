console.log("DeliveryPersonController.js");

const backUrl = window.location.origin + "/api/rest/deliveryPerson";

// Récupérer la liste déroulante
let select = document.getElementById("deliveryPerson");

// Faire une requête GET à l'API pour obtenir tous les livreurs
fetch( backUrl + '/display')
    .then(response => response.json())
    .then(deliveryPersons => {
        // Parcourir la liste des livreurs
        for(let i = 0; i < deliveryPersons.length; i++) {
            // Créer une nouvelle option
            let option = document.createElement("option");
            option.value = deliveryPersons[i].id_delivery_person; // Utiliser l'ID du livreur comme valeur
            option.text = deliveryPersons[i].firstname + ' ' + deliveryPersons[i].lastname; // Utiliser le nom du livreur comme texte

            // Ajouter l'option à la liste déroulante
            select.add(option);
        }
    })
    .catch(error => console.error('Erreur:', error));