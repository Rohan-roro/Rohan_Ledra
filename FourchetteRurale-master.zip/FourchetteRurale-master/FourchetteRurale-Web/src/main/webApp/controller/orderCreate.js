console.log("orderCreate.js chargé");


const backUrlOrderCreate = window.location.origin + "/api/rest/order";


document.getElementById('createOrder').addEventListener('click', function() {
    // Gather data from the form fields
    let idSlot = document.getElementById('hour-delivery').value;

    let memberData = JSON.parse(localStorage.getItem('member'));
    let idMember = memberData ? memberData.idMember : null;

    let idNote = 0; // Replace with the actual note id
    let idBug = 0; // Replace with the actual bug id
    let idTour = 0; // Replace with the actual tour id
    let shippingDate = document.getElementById('startDate').value;
    let comment = " "; // Replace with the actual comment
    let dateExecuteShipping = "0001-01-01";
    // Create a JSON object
   let orderData = {
       "idSlot": idSlot,
       "idMember": idMember,
       "idNote": idNote,
       "idBug": idBug,
       "idTour": idTour,
       "shippingDate": shippingDate,
       "comment": comment,
       "dateExecuteShipping": dateExecuteShipping
   };

    // Send a POST request to the server
 fetch(backUrlOrderCreate + '/create', {
     method: 'POST',
     headers: {
         'Content-Type': 'application/json'
     },
     body: JSON.stringify(orderData)
 })
 .then(response => {
     console.log('Response status:', response.status); // Log the status code
     console.log('Response:', response); // Log the response
     if (response.status !== 200 && response.status !== 201) {
         return response.text().then(errorText => {
             throw new Error(`HTTP error! status: ${response.status}, error: ${errorText}`);
         });
     }
     return response.text(); // Get the response body as text
 })
 .then(text => {
     let data;
     try {
         data = text ? JSON.parse(text) : {}; // Parse the text to JSON if it's not empty
     } catch (error) {
         console.error('Could not parse JSON:', error);
     }
     console.log(data);
     alert("La commande a bien été passée"); // Display success message
     localStorage.removeItem('listeTypeMeal');
     localStorage.removeItem('listeRecettes');
     window.location.href = "/MemberPages/landingPage.html";
 })
 .catch((error) => {
     console.error('Error:', error);
     alert("Une erreur s'est produite lors de la passation de la commande"); // Display error message
 });
});