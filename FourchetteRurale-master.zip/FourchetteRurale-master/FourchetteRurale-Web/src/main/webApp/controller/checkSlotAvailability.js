document.getElementById('startDate').addEventListener('change', async function() {
    const selectedDate = this.value;
    if (!selectedDate) return;


    // Fetch the config.json file
    const configResponse = await fetch('../config.json');
    const config = await configResponse.json();

    // Use the start and apiKey values from config.json
    const start = config.start.value;
    const apiKey = config.apiKey.value;

    const member = JSON.parse(localStorage.getItem('member'));
    const proxyUrl = 'https://cors-anywhere.herokuapp.com/';
    const backUrlSlot1 = window.location.origin + "/api/rest/slot";

    // Fetch all slots
    const slotsResponse = await fetch(backUrlSlot1 + "/all");
    const slots = await slotsResponse.json();

    // Get the select element
    const select = document.getElementById("hour-delivery");

    // Iterate over each slot
    for(let i = 0; i < slots.length; i++) {
        try {
            const addressesResponse = await fetch(`${window.location.origin}/api/rest/order/adress/${slots[i].idSlot}/${selectedDate}`);
            let addresses = await addressesResponse.json();

            addresses.push(member.shippingAddress);

            const waypoints = addresses.map(address => encodeURIComponent(address.replace(/,/g, '')));
            const end = waypoints.pop();
            const url = `https://maps.googleapis.com/maps/api/directions/json?origin=${encodeURIComponent(start)}&destination=${end}&waypoints=${waypoints.join('|')}&key=${apiKey}`;

            const directionsResponse = await fetch(proxyUrl + url);
            if (!directionsResponse.ok) throw new Error('Network response was not ok');

            const data = await directionsResponse.json();

            const totalDurationInSeconds = data.routes[0].legs.reduce((total, leg) => total + leg.duration.value, 0);
            const totalDurationInHours = Math.floor(totalDurationInSeconds / 3600);
            const totalDurationInMinutes = (totalDurationInSeconds % 3600) / 60;
            const totalDuration = totalDurationInHours * 60 + totalDurationInMinutes;

            // If the total duration is more than 3 hours (180 minutes), remove the slot from the dropdown and continue to the next slot
            if (totalDuration > 180) {
                console.log('Durée totale du trajet est supérieur à 3 heures. Il ne sera pas affiché.');

                // Find the option element that corresponds to the current slot and remove it
                for(let j = 0; j < select.options.length; j++) {
                    if(select.options[j].value == slots[i].idSlot) {
                        select.remove(j);
                        break;
                    }
                }

                continue;
            }

            console.log(`Durée totale du trajet : ${totalDurationInHours} heures ${totalDurationInMinutes} minutes`);

            const sortedAddresses = data.routes[0].legs.slice(1).map(leg => leg.start_address.replace(/,/g, '').replace(' France', ''));
            sortedAddresses.push(data.routes[0].legs[data.routes[0].legs.length - 1].end_address.replace(/,/g, '').replace(' France', ''));

            const sortedAddressesJson = JSON.stringify(sortedAddresses);

            // Store the sorted addresses in local storage instead of sending a POST request
            localStorage.setItem('sortedAddresses', sortedAddressesJson);

            console.log('Les adresses triées ont été stockées dans le local storage');
        } catch (error) {
            console.error('Erreur :', error);
        }
    }
});