const backUrl = window.location.origin + "/api/rest";

document.getElementById('registrationForm').addEventListener('submit', function(event) {
    event.preventDefault();

    let civility = document.getElementById('civility').value;
    let lastname = document.getElementById('lastname').value;
    let firstname = document.getElementById('firstname').value;
    let phone = document.getElementById('phone').value;
    let email = document.getElementById('email').value;
    let adress = document.getElementById('adress').value;
    let adress_cash = document.getElementById('adress_cash').value;
    let BirthDate = document.getElementById('BirthDate').value;
    let password = document.getElementById('password').value;

    let member = {
        city: 1, // Vous pouvez remplacer 1 par la valeur appropriée
        civility: parseInt(civility),
        firstname: firstname,
        lastname: lastname,
        birthdate: BirthDate,
        phoneNumber: phone,
        emailAdress: email,
        password: password,
        shippingAddress: adress,
        billingAddress: adress_cash,
        registrationDate: new Date().toISOString().split('T')[0], // Utilise la date actuelle
        unsubscriptionDate: null
    };

    console.log(member); // Ajoutez cette ligne pour voir l'objet member dans la console

    // Envoi des données au serveur pour créer un membre
    fetch(backUrl + "/registration/member", {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(member)
    }).then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return response.text();
    }).then(text => text.length ? JSON.parse(text) : {})
    .then(data => {
        console.log(data);
        // Récupérer l'ID du dernier membre inséré
        fetch(backUrl + "/member/getLastInsertedId")
        .then(response => response.json())
        .then(lastInsertedId => {
            // Créer une nouvelle structure de menu pour ce membre
            let memberMenu = {
                idMember: lastInsertedId,
                choiceDate: new Date().toISOString().split('T')[0] // Remplacez cette date par la date de choix appropriée
                // ... autres propriétés nécessaires pour créer un menu ...
            };

            fetch(backUrl + "/memberMenu/create", {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(memberMenu)
            }).then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                return response.text();
            }).then(text => text.length ? JSON.parse(text) : {})
            .then(data => {
                console.log(data);
                // Popup to ask the user if they want to navigate to the login page
                let userResponse = window.confirm("Votre compte a été créé avec succès. Voulez-vous vous connecter ?");
                if (userResponse) {
                    // If the user clicks "OK", redirect them to the login page
                    window.location.href = "connection.html";
                }
            })
            .catch((error) => {
                console.error('Error:', error);
            });
        });
    })
    .catch((error) => {
        console.error('Error:', error);
    });
});