window.onload = function() {
    const deliveryPerson = JSON.parse(localStorage.getItem("deliveryPerson"));
    if (deliveryPerson) {
        const deliveryNameElement = document.getElementById('delivery-name');
        deliveryNameElement.textContent = deliveryPerson.firstname + " " + deliveryPerson.lastname;

        const datePickerElement = document.getElementById('datePicker');
        datePickerElement.addEventListener('change', function() {
            const selectedDate = new Date(this.value);
            const backUrlTours = window.location.origin + "/api/rest/tour/deliveryMan/" + deliveryPerson.id_delivery_person;
            fetch(backUrlTours)
                .then(response => response.json())
                .then(tours => {
                    const toursBodyElement = document.getElementById('toursBody');
                    toursBodyElement.innerHTML = ''; // Effacez les tournées précédentes
                    tours.forEach((tour, index) => {
                        const tourDate = new Date(tour.dateExecutionTour);
                        if (tourDate.toDateString() === selectedDate.toDateString()) { // Comparez les dates sans l'heure
                            const tourId = tour.idTour; // Stockez l'ID de la tournée dans une variable
                            const tr = document.createElement('tr');
                            const th = document.createElement('th');
                            th.scope = 'row';
                            th.textContent = index + 1;
                            const tdDate = document.createElement('td');
                            tdDate.textContent = tour.dateExecutionTour;
                            const tdItinerary = document.createElement('td');
                            const aItinerary = document.createElement('a');
                            aItinerary.href = tour.itinerary; // Assurez-vous que tour.itinerary contient une URL valide
                            aItinerary.textContent = "lien de l'itinéraire";
                            tdItinerary.appendChild(aItinerary);
                            tr.appendChild(th);
                            tr.appendChild(tdDate);
                            tr.appendChild(tdItinerary);
                            toursBodyElement.appendChild(tr);

                            // Récupérez les adresses de livraison de l'API
                            const backUrlAddresses = window.location.origin + "/api/rest/order/delivery/shippingAdresses/" + tourId + "/" + selectedDate.toISOString().split('T')[0];
                            fetch(backUrlAddresses)
                                .then(response => response.json())
                                .then(addresses => {
                                    const deliveryAddressesElement = document.getElementById('deliveryAddresses');
                                    deliveryAddressesElement.innerHTML = ''; // Effacez les adresses de livraison précédentes
                                    addresses.forEach((address, index) => {
                                        const p = document.createElement('p');
                                        p.textContent = address;
                                        deliveryAddressesElement.appendChild(p); // Ajoutez chaque adresse à l'élément deliveryAddresses
                                    });
                                })
                                .catch(error => {
                                    console.error('Error:', error);
                                });
                        }
                    });
                })
                .catch(error => {
                    console.error('Error:', error);
                });
        });
    }
}