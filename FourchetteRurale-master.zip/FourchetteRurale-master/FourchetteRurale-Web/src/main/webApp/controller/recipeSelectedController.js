// URL of the API endpoint
console.log("recipeController.js chargé");
const backUrl = window.location.origin + "/api/rest/recipe";


// Function to fetch all recipes and display them
function displayAllRecipes() {
    // Get the container where the recipes will be added
    const container = document.querySelector('.conteneur-recettes');

    // Make a GET request to the API
    fetch(backUrl+ "/all")
        .then(response => response.json())
        .then(recipes => {
            // Clear the container
            console.log("check si listeRecettes en remplie :", listeRecettesStorage);
            // Create variable with all the recipes load in the local storage
            let filteredRecipes = recipes.filter(recipe => listeRecettesStorage.includes(recipe.id_recipe));
            console.log("liste de toutes les recettes :", recipes);
            console.log("liste fileteredRecipes :", filteredRecipes)
            // For each recipe, create an HTML element and add it to the container
            filteredRecipes.forEach(recipe => {
                console.log("id des recettes de la filteredRecipes :", recipe.id_recipe); // Log the recipe id to the console


                const recipeElement = document.createElement('div');
                recipeElement.classList.add('recette');

                const title = document.createElement('h3');
                title.textContent = recipe.name;
                recipeElement.appendChild(title);

                const image = document.createElement('img');
                image.alt = recipe.name;
                image.src = recipe.photo;
                image.addEventListener('click', function() {
                   ajouterRecette(this, recipe);
                });
                recipeElement.appendChild(image);

                const description = document.createElement('p');
                description.textContent = recipe.description;
                recipeElement.appendChild(description);

                container.appendChild(recipeElement);
            });
        })
        .catch(error => console.error('Error:', error));
}

// Call the function when the page loads
window.onload = displayAllRecipes;


//BOUTON SUPPRIMER SELECTION
document.addEventListener("DOMContentLoaded", function() {
    // Sélection du bouton deleteSelection
    var deleteBtn = document.getElementById("deleteSelection");

    // Ajout d'un écouteur d'événements sur le clic du bouton
    deleteBtn.addEventListener("click", function() {
        // Recharger la page
        location.reload();
    });
});




function displayAllBreakfast() {
    // Get the container where the recipes will be added
    const container = document.querySelector('.conteneur-recettes');

    // Make a GET request to the API
    fetch(backUrl+ "/all")
        .then(response => response.json())
        .then(recipes => {
            // Clear the container
            console.log("check si listeRecettes en remplie :", listeRecettesStorage);
            // Create variable with all the recipes load in the local storage
            let filteredRecipes = recipes.filter(recipe => listeRecettesStorage.includes(recipe.id_recipe));
            let filteredRecipesWithMealType1 = filteredRecipes.filter(recipe => recipe.id_type_meal === 1);
            console.log("liste de toutes les filteredRecipes :", filteredRecipes);
            console.log("liste filteredRecipesWithMealType1 :", filteredRecipesWithMealType1)
            // For each recipe, create an HTML element and add it to the container
            filteredRecipesWithMealType1.forEach(recipe => {
                console.log("id des recettes de la filteredRecipes :", recipe.id_recipe); // Log the recipe id to the console


                const recipeElement = document.createElement('div');
                recipeElement.classList.add('recette');

                const title = document.createElement('h3');
                title.textContent = recipe.name;
                recipeElement.appendChild(title);

                const image = document.createElement('img');
                image.alt = recipe.name;
                image.src = recipe.photo;
                image.addEventListener('click', function() {
                   ajouterRecette(this, recipe);
                });
                recipeElement.appendChild(image);

                const description = document.createElement('p');
                description.textContent = recipe.description;
                recipeElement.appendChild(description);

                container.appendChild(recipeElement);
            });
        })
        .catch(error => console.error('Error:', error));
}

let breakfastBtn = document.querySelector('select#choiceMeal [value="breakfast"]');
breakfastBtn.addEventListener("click", function(){
    displayAllBreakfast
})