// Fonction pour ajouter l'ID de la recette à une liste lorsque l'image est cliquée
console.log("recipesSelected.js chargé");

// Ajouter les élements sélectionnés à une liste + border vert au tour pour les identifier
function ajouterRecette(element, recipe) {
    // Récupérer la liste de recettes existante depuis le stockage local
    var listeRecettesJSON = localStorage.getItem('listeRecettes');
    var listeTypeMealJSON = localStorage.getItem('listeTypeMeal');
    var listeRecettes = [];
    var listeTypeMeal = [];

    if (listeRecettesJSON) {
        // Convertir la chaîne JSON en tableau JavaScript
        listeRecettes = JSON.parse(listeRecettesJSON);
    }

    if (listeTypeMealJSON) {
            // Convertir la chaîne JSON en tableau JavaScript
            listeTypeMeal = JSON.parse(listeTypeMealJSON);
        }

    // Récupérer l'ID de la recette à partir de l'élément cliqué
    var idRecette = recipe.id_recipe;
    var idTypeMeal = recipe.id_type_meal;
    console.log(recipe.name);
    // Vérifier si l'ID de la recette est déjà dans la liste
    var index = listeRecettes.indexOf(idRecette);
    while (index !== -1) {
    // Supprimer l'ID de la recette et le type de repas correspondant
    listeRecettes.splice(index, 1);
    listeTypeMeal.splice(index, 1); // Assurez-vous que cela est cohérent avec la structure de vos données

    // Rechercher la prochaine occurrence de l'ID de la recette
    index = listeRecettes.indexOf(idRecette);
}

// Appliquer une bordure pour indiquer l'action réalisée
if (index === -1) { // Si aucune occurrence n'est trouvée dès le début, cet if ne sera jamais vrai après la boucle
    element.style.border = '2px solid red';
    console.log("Toutes les occurrences de l'ID", idRecette, "ont été enlevées du tableau.");
}
    console.log("Liste des recettes sélectionnées :", listeRecettes);
    console.log("Liste des type de repas sélectionnées :", listeTypeMeal);

    // Convertir le tableau en chaîne JSON et l'enregistrer dans le stockage local
    var listeRecettesJSON = JSON.stringify(listeRecettes);
    var listeTypeMeal = JSON.stringify(listeTypeMeal);
    localStorage.setItem('listeRecettes', listeRecettesJSON);
    localStorage.setItem('listeTypeMeal', listeTypeMeal);
    console.log("listeRecettesJSON :", listeRecettesJSON);
    console.log("listeTypeMeal :", listeTypeMeal);
}
