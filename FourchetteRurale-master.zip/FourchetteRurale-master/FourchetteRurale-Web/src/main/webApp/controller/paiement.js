console.log('Paiement.js');

const backUrl = window.location.origin + "/api/rest/member";


document.getElementById('validate').addEventListener('click', function() {
    event.preventDefault();

    // Récupérer les données du membre du localStorage
    var memberDataString = localStorage.getItem('member');
    var selectPaymentElement = document.getElementById('selectPayment');
    var selectedPaymentMethodId = selectPaymentElement.value;

    if (!memberDataString) {
        console.error('No member data found in localStorage');
        return;
    }

    var memberData;
    try {
        memberData = JSON.parse(memberDataString);
    } catch (error) {
        console.error('Error parsing member data from localStorage:', error);
        return;
    }

   // Obtenir la date actuelle
   var now = new Date();
   var dateNow = now.toISOString().split('T')[0]; // Only get the date part

    var data = {
        "id_adherent": memberData.idMember, // Utiliser l'idMember du localStorage
        "id_moyen_paye": selectedPaymentMethodId,
        "date_adhesion": dateNow,
        "date_paiement": dateNow
    };

   fetch(backUrl + '/monthlymembership/create', {
       method: 'POST',
       headers: {
           'Content-Type': 'application/json',
       },
       body: JSON.stringify(data),
   })
   .then(response => {
       if (!response.ok) {
           throw new Error('Network response was not ok');
       }
       return response.text();
   })
   .then(text => {
       try {
           return JSON.parse(text);
       } catch (error) {
           console.error('Could not parse JSON:', error);
           return text;
       }
   })
   .then(data => {
       console.log('Success:', data);
       alert("Le paiement a bien été enregistré"); // Display success message
       window.location.href = "/MemberPages/placeOrder.html";

   })
   .catch((error) => {
       console.error('Error:', error);
       alert("Une erreur s'est produite lors de l'enregistrement du paiement"); // Display error message
   });
});