console.log("typeMealController.js chargé");

// URL of the API endpoint
const backUrl4 = window.location.origin + "/api/rest/recipe";

// PETITS-DEJEUNERS //
document.addEventListener('DOMContentLoaded', function() {
console.log("entrée DOMContentLoaded");
    // Ajouter un gestionnaire d'événements à l'élément <a> "Petits-déjeuners"
    document.getElementById('petitsDejeuners').addEventListener('click', function(event) {
console.log("entrée fonction addeventlistenerPetitdej");

    // MODIFIER TITRE DE LA PAGE
    const recipeTypeElement = document.getElementById('recipeType');
            // Changer le contenu de l'élément <p>
    recipeTypeElement.textContent = "Petits-déjeuners";
    console.log("titre modifié");
        // Function to fetch and display breakfast recipes
        function displayBreakfastRecipes() {
        console.log("entrée dans la fonction displayBreakfast")
            // Get the container where the recipes will be added
            const container = document.querySelector('.conteneur-recettes');

            // Make a GET request to fetch breakfast recipes from the API
            fetch(backUrl4 + "/breakfast") // Assuming the query parameter for breakfast recipes is "type_meal=1"
                .then(response => response.json())
                .then(recipes => {
                    // Clear the container
                    container.innerHTML = '';
                    console.log("clear container")

                    // For each breakfast recipe, create an HTML element and add it to the container
                    recipes.forEach(recipe => {
                        console.log('Processing recipe:', recipe); // Log the entire recipe object to the console

                        const recipeElement = document.createElement('div');
                        recipeElement.classList.add('recette');

                        const title = document.createElement('h3');
                        title.textContent = recipe.name;
                        recipeElement.appendChild(title);

                        const image = document.createElement('img');
                        image.alt = recipe.name;
                        image.src = recipe.photo;
                        recipeElement.appendChild(image);

                        const description = document.createElement('p');
                        description.textContent = recipe.description;
                        recipeElement.appendChild(description);

                    // Création du conteneur div
                                            const containerDiv = document.createElement('div');

                                            // Bouton de décrémentation
                                            const decrementButton = document.createElement('button');
                                            decrementButton.id = 'decrementButton';
                                            decrementButton.textContent = '-';
                                            containerDiv.appendChild(decrementButton);

                                            // Champ de texte pour la quantité
                                            const quantityInput = document.createElement('input');
                                            quantityInput.type = 'text';
                                            quantityInput.id = 'quantityInput';
                                            quantityInput.value = '1';
                                            containerDiv.appendChild(quantityInput);

                                            // Bouton d'incrémentation
                                            const incrementButton = document.createElement('button');
                                            incrementButton.id = 'incrementButton';
                                            incrementButton.textContent = '+';
                                            containerDiv.appendChild(incrementButton);

                                            // Ajouter le conteneur div à recipeElement
                                            recipeElement.appendChild(containerDiv);


                                           // Création et configuration du bouton "Ajouter"
                                           const addButton = document.createElement('button');
                                           addButton.textContent = 'Ajouter';
                                           addButton.addEventListener('click', function() {
                                               // Récupérer la valeur du champ de quantité
                                               const quantityValue = parseInt(quantityInput.value);
                                               if (quantityValue > 0) {
                                                   // Ajouter la recette avec la quantité sélectionnée
                                                   for (let j = 0; j < quantityValue; j++) {
                                                       ajouterRecette(this, recipe);
                                                   }
                                                   updateBreakfastCount();
                                                   updateSnackCount();
                                                   updateMainCourseCount();
                                                   updateStarterCount();
                                                   updateDessertCount();
                                               }
                                           });
                                           recipeElement.appendChild(addButton);


                                            // Log id_recipe and id_type_meal to the console
                                            console.log('ID de la recette: ' + recipe.id_recipe);
                                            console.log('ID du type de repas: ' + recipe.id_type_meal);

                                            container.appendChild(recipeElement);
                                        });
                                    })
                                    .catch(error => console.error('Error:', error));
                    }

        // Call the function to fetch and display breakfast recipes
        displayBreakfastRecipes();
    });
});



// ENTREES //
document.addEventListener('DOMContentLoaded', function() {
    // Ajouter un gestionnaire d'événements à l'élément <a> "Petits-déjeuners"
    document.getElementById('entrees').addEventListener('click', function(event) {

        // MODIFIER TITRE DE LA PAGE
        const recipeTypeElement = document.getElementById('recipeType');
                // Changer le contenu de l'élément <p>
        recipeTypeElement.textContent = "Entrées";

        // Function to fetch and display breakfast recipes
        function displayStarterRecipes() {
        console.log("entrée dans la fonction displayStarterRecipes")
            // Get the container where the recipes will be added
            const container = document.querySelector('.conteneur-recettes');

            // Make a GET request to fetch breakfast recipes from the API
            fetch(backUrl4 + "/starter")
                .then(response => response.json())
                .then(recipes => {
                    // Clear the container
                    container.innerHTML = '';
                    console.log("clear container")

                    // For each breakfast recipe, create an HTML element and add it to the container
                    recipes.forEach(recipe => {
                        console.log('Processing recipe:', recipe); // Log the entire recipe object to the console

                        const recipeElement = document.createElement('div');
                        recipeElement.classList.add('recette');

                        const title = document.createElement('h3');
                        title.textContent = recipe.name;
                        recipeElement.appendChild(title);

                        const image = document.createElement('img');
                        image.alt = recipe.name;
                        image.src = recipe.photo;
                        recipeElement.appendChild(image);

                        const description = document.createElement('p');
                        description.textContent = recipe.description;
                        recipeElement.appendChild(description);

                    // Création du conteneur div
                                                                const containerDiv = document.createElement('div');

                                                                // Bouton de décrémentation
                                                                const decrementButton = document.createElement('button');
                                                                decrementButton.id = 'decrementButton';
                                                                decrementButton.textContent = '-';
                                                                containerDiv.appendChild(decrementButton);

                                                                // Champ de texte pour la quantité
                                                                const quantityInput = document.createElement('input');
                                                                quantityInput.type = 'text';
                                                                quantityInput.id = 'quantityInput';
                                                                quantityInput.value = '1';
                                                                containerDiv.appendChild(quantityInput);

                                                                // Bouton d'incrémentation
                                                                const incrementButton = document.createElement('button');
                                                                incrementButton.id = 'incrementButton';
                                                                incrementButton.textContent = '+';
                                                                containerDiv.appendChild(incrementButton);

                                                                // Ajouter le conteneur div à recipeElement
                                                                recipeElement.appendChild(containerDiv);


                                                               // Création et configuration du bouton "Ajouter"
                                                               const addButton = document.createElement('button');
                                                               addButton.textContent = 'Ajouter';
                                                               addButton.addEventListener('click', function() {
                                                                   // Récupérer la valeur du champ de quantité
                                                                   const quantityValue = parseInt(quantityInput.value);
                                                                   if (quantityValue > 0) {
                                                                       // Ajouter la recette avec la quantité sélectionnée
                                                                       for (let j = 0; j < quantityValue; j++) {
                                                                           ajouterRecette(this, recipe);
                                                                       }
                                                    updateBreakfastCount();
                                                   updateSnackCount();
                                                   updateMainCourseCount();
                                                   updateStarterCount();
                                                   updateDessertCount();
                                                                   }
                                                               });
                                                               recipeElement.appendChild(addButton);


                                                                // Log id_recipe and id_type_meal to the console
                                                                console.log('ID de la recette: ' + recipe.id_recipe);
                                                                console.log('ID du type de repas: ' + recipe.id_type_meal);

                                                                container.appendChild(recipeElement);
                                                            });
                                                        })
                                                        .catch(error => console.error('Error:', error));
                                        }

        // Call the function to fetch and display breakfast recipes
        displayStarterRecipes();
    });
});

// PLATS PRINCIPAUX //
document.addEventListener('DOMContentLoaded', function() {
    // Ajouter un gestionnaire d'événements à l'élément <a> "Petits-déjeuners"
    document.getElementById('platsPrincipaux').addEventListener('click', function(event) {
        // MODIFIER TITRE DE LA PAGE
        const recipeTypeElement = document.getElementById('recipeType');
                // Changer le contenu de l'élément <p>
        recipeTypeElement.textContent = "Plats principaux";

        // Function to fetch and display breakfast recipes
        function displayMainRecipes() {
        console.log("entrée dans la fonction displayMainRecipes")
            // Get the container where the recipes will be added
            const container = document.querySelector('.conteneur-recettes');

            // Make a GET request to fetch breakfast recipes from the API
            fetch(backUrl4 + "/main")
                .then(response => response.json())
                .then(recipes => {
                    // Clear the container
                    container.innerHTML = '';
                    console.log("clear container")

                    // For each breakfast recipe, create an HTML element and add it to the container
                    recipes.forEach(recipe => {
                        console.log('Processing recipe:', recipe); // Log the entire recipe object to the console

                        const recipeElement = document.createElement('div');
                        recipeElement.classList.add('recette');

                        const title = document.createElement('h3');
                        title.textContent = recipe.name;
                        recipeElement.appendChild(title);

                        const image = document.createElement('img');
                        image.alt = recipe.name;
                        image.src = recipe.photo;
                        recipeElement.appendChild(image);

                        const description = document.createElement('p');
                        description.textContent = recipe.description;
                        recipeElement.appendChild(description);

// Création du conteneur div
                                            const containerDiv = document.createElement('div');

                                            // Bouton de décrémentation
                                            const decrementButton = document.createElement('button');
                                            decrementButton.id = 'decrementButton';
                                            decrementButton.textContent = '-';
                                            containerDiv.appendChild(decrementButton);

                                            // Champ de texte pour la quantité
                                            const quantityInput = document.createElement('input');
                                            quantityInput.type = 'text';
                                            quantityInput.id = 'quantityInput';
                                            quantityInput.value = '1';
                                            containerDiv.appendChild(quantityInput);

                                            // Bouton d'incrémentation
                                            const incrementButton = document.createElement('button');
                                            incrementButton.id = 'incrementButton';
                                            incrementButton.textContent = '+';
                                            containerDiv.appendChild(incrementButton);

                                            // Ajouter le conteneur div à recipeElement
                                            recipeElement.appendChild(containerDiv);


                                           // Création et configuration du bouton "Ajouter"
                                           const addButton = document.createElement('button');
                                           addButton.textContent = 'Ajouter';
                                           addButton.addEventListener('click', function() {
                                               // Récupérer la valeur du champ de quantité
                                               const quantityValue = parseInt(quantityInput.value);
                                               if (quantityValue > 0) {
                                                   // Ajouter la recette avec la quantité sélectionnée
                                                   for (let j = 0; j < quantityValue; j++) {
                                                       ajouterRecette(this, recipe);
                                                   }
                                                    updateBreakfastCount();
                                                   updateSnackCount();
                                                   updateMainCourseCount();
                                                   updateStarterCount();
                                                   updateDessertCount();
                                               }
                                           });
                                           recipeElement.appendChild(addButton);


                                            // Log id_recipe and id_type_meal to the console
                                            console.log('ID de la recette: ' + recipe.id_recipe);
                                            console.log('ID du type de repas: ' + recipe.id_type_meal);

                                            container.appendChild(recipeElement);
                                        });
                                    })
                                    .catch(error => console.error('Error:', error));
                    }
        // Call the function to fetch and display breakfast recipes
        displayMainRecipes();
    });
});


// DESSERTS //
document.addEventListener('DOMContentLoaded', function() {
    // Ajouter un gestionnaire d'événements à l'élément <a> "Petits-déjeuners"
    document.getElementById('desserts').addEventListener('click', function(event) {
        // MODIFIER TITRE DE LA PAGE
        const recipeTypeElement = document.getElementById('recipeType');
                // Changer le contenu de l'élément <p>
        recipeTypeElement.textContent = "Desserts";

        // Function to fetch and display breakfast recipes
        function displayDessertRecipes() {
        console.log("entrée dans la fonction displayDessertRecipes")
            // Get the container where the recipes will be added
            const container = document.querySelector('.conteneur-recettes');

            // Make a GET request to fetch breakfast recipes from the API
            fetch(backUrl4 + "/dessert")
                .then(response => response.json())
                .then(recipes => {
                    // Clear the container
                    container.innerHTML = '';
                    console.log("clear container")

                    // For each breakfast recipe, create an HTML element and add it to the container
                    recipes.forEach(recipe => {
                        console.log('Processing recipe:', recipe); // Log the entire recipe object to the console

                        const recipeElement = document.createElement('div');
                        recipeElement.classList.add('recette');

                        const title = document.createElement('h3');
                        title.textContent = recipe.name;
                        recipeElement.appendChild(title);

                        const image = document.createElement('img');
                        image.alt = recipe.name;
                        image.src = recipe.photo;
                        recipeElement.appendChild(image);

                        const description = document.createElement('p');
                        description.textContent = recipe.description;
                        recipeElement.appendChild(description);

// Création du conteneur div
                                            const containerDiv = document.createElement('div');

                                            // Bouton de décrémentation
                                            const decrementButton = document.createElement('button');
                                            decrementButton.id = 'decrementButton';
                                            decrementButton.textContent = '-';
                                            containerDiv.appendChild(decrementButton);

                                            // Champ de texte pour la quantité
                                            const quantityInput = document.createElement('input');
                                            quantityInput.type = 'text';
                                            quantityInput.id = 'quantityInput';
                                            quantityInput.value = '1';
                                            containerDiv.appendChild(quantityInput);

                                            // Bouton d'incrémentation
                                            const incrementButton = document.createElement('button');
                                            incrementButton.id = 'incrementButton';
                                            incrementButton.textContent = '+';
                                            containerDiv.appendChild(incrementButton);

                                            // Ajouter le conteneur div à recipeElement
                                            recipeElement.appendChild(containerDiv);


                                           // Création et configuration du bouton "Ajouter"
                                           const addButton = document.createElement('button');
                                           addButton.textContent = 'Ajouter';
                                           addButton.addEventListener('click', function() {
                                               // Récupérer la valeur du champ de quantité
                                               const quantityValue = parseInt(quantityInput.value);
                                               if (quantityValue > 0) {
                                                   // Ajouter la recette avec la quantité sélectionnée
                                                   for (let j = 0; j < quantityValue; j++) {
                                                       ajouterRecette(this, recipe);
                                                   }
                                                    updateBreakfastCount();
                                                   updateSnackCount();
                                                   updateMainCourseCount();
                                                   updateStarterCount();
                                                   updateDessertCount();
                                               }
                                           });
                                           recipeElement.appendChild(addButton);


                                            // Log id_recipe and id_type_meal to the console
                                            console.log('ID de la recette: ' + recipe.id_recipe);
                                            console.log('ID du type de repas: ' + recipe.id_type_meal);

                                            container.appendChild(recipeElement);
                                        });
                                    })
                                    .catch(error => console.error('Error:', error));
                    }                    // Création de la liste déroulante

        // Call the function to fetch and display breakfast recipes
        displayDessertRecipes();
    });
});


// COLLATIONS //
document.addEventListener('DOMContentLoaded', function() {
    // Ajouter un gestionnaire d'événements à l'élément <a> "Petits-déjeuners"
    document.getElementById('collations').addEventListener('click', function(event) {
        // MODIFIER TITRE DE LA PAGE
        const recipeTypeElement = document.getElementById('recipeType');
                // Changer le contenu de l'élément <p>
        recipeTypeElement.textContent = "Collations";

        // Function to fetch and display breakfast recipes
        function displayCollationRecipes() {
        console.log("entrée dans la fonction displayCollationRecipes")
            // Get the container where the recipes will be added
            const container = document.querySelector('.conteneur-recettes');

            // Make a GET request to fetch breakfast recipes from the API
            fetch(backUrl4 + "/collation")
                .then(response => response.json())
                .then(recipes => {
                    // Clear the container
                    container.innerHTML = '';
                    console.log("clear container")

                    // For each breakfast recipe, create an HTML element and add it to the container
                    recipes.forEach(recipe => {
                        console.log('Processing recipe:', recipe); // Log the entire recipe object to the console

                        const recipeElement = document.createElement('div');
                        recipeElement.classList.add('recette');

                        const title = document.createElement('h3');
                        title.textContent = recipe.name;
                        recipeElement.appendChild(title);

                        const image = document.createElement('img');
                        image.alt = recipe.name;
                        image.src = recipe.photo;
                        recipeElement.appendChild(image);

                        const description = document.createElement('p');
                        description.textContent = recipe.description;
                        recipeElement.appendChild(description);

// Création du conteneur div
                                            const containerDiv = document.createElement('div');

                                            // Bouton de décrémentation
                                            const decrementButton = document.createElement('button');
                                            decrementButton.id = 'decrementButton';
                                            decrementButton.textContent = '-';
                                            containerDiv.appendChild(decrementButton);

                                            // Champ de texte pour la quantité
                                            const quantityInput = document.createElement('input');
                                            quantityInput.type = 'text';
                                            quantityInput.id = 'quantityInput';
                                            quantityInput.value = '1';
                                            containerDiv.appendChild(quantityInput);

                                            // Bouton d'incrémentation
                                            const incrementButton = document.createElement('button');
                                            incrementButton.id = 'incrementButton';
                                            incrementButton.textContent = '+';
                                            containerDiv.appendChild(incrementButton);

                                            // Ajouter le conteneur div à recipeElement
                                            recipeElement.appendChild(containerDiv);


                                           // Création et configuration du bouton "Ajouter"
                                           const addButton = document.createElement('button');
                                           addButton.textContent = 'Ajouter';
                                           addButton.addEventListener('click', function() {
                                               // Récupérer la valeur du champ de quantité
                                               const quantityValue = parseInt(quantityInput.value);
                                               if (quantityValue > 0) {
                                                   // Ajouter la recette avec la quantité sélectionnée
                                                   for (let j = 0; j < quantityValue; j++) {
                                                       ajouterRecette(this, recipe);
                                                   }
                                                    updateBreakfastCount();
                                                   updateSnackCount();
                                                   updateMainCourseCount();
                                                   updateStarterCount();
                                                   updateDessertCount();
                                               }
                                           });
                                           recipeElement.appendChild(addButton);


                                            // Log id_recipe and id_type_meal to the console
                                            console.log('ID de la recette: ' + recipe.id_recipe);
                                            console.log('ID du type de repas: ' + recipe.id_type_meal);

                                            container.appendChild(recipeElement);
                                        });
                                    })
                                    .catch(error => console.error('Error:', error));
                    }
        // Call the function to fetch and display breakfast recipes
        displayCollationRecipes();
    });
});


// TOTAL //
document.addEventListener('DOMContentLoaded', function() {
    // Sélectionnez l'élément <a> avec l'ID "total"
    const totalLink = document.getElementById('total');

    // Ajoutez un gestionnaire d'événements au clic sur l'élément <a> "Petits-déjeuners"
    totalLink.addEventListener('click', function() {
        // Appelez la fonction displayAllRecipes() lorsque l'élément <a> est cliqué
        displayAllRecipes();

        // MODIFIER TITRE DE LA PAGE
        const recipeTypeElement = document.getElementById('recipeType');
        // Changer le contenu de l'élément <p>
        recipeTypeElement.textContent = "Toutes les recettes";
    });
});
