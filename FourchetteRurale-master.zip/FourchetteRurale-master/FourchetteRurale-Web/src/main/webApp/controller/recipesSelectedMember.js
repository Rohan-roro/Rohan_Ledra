// Fonction pour ajouter l'ID de la recette à une liste lorsque l'image est cliquée
console.log("recipesSelected.js chargé");

// Ajouter les élements sélectionnés à une liste + border vert au tour pour les identifier
function ajouterRecette(element, recipe) {
    // Récupérer la liste de recettes existante depuis le stockage local
    var listeRecettesJSON = localStorage.getItem('listeRecettes');
    var listeTypeMealJSON = localStorage.getItem('listeTypeMeal');
    var listeRecettes = [];
    var listeTypeMeal = [];

    if (listeRecettesJSON) {
        // Convertir la chaîne JSON en tableau JavaScript
        listeRecettes = JSON.parse(listeRecettesJSON);
    }

    if (listeTypeMealJSON) {
        // Convertir la chaîne JSON en tableau JavaScript
        listeTypeMeal = JSON.parse(listeTypeMealJSON);
    }

    // Récupérer l'ID de la recette à partir de l'élément cliqué
    var idRecette = recipe.id_recipe;
    var idTypeMeal = recipe.id_type_meal;
    console.log(recipe.name);
    // Vérifier si l'ID de la recette est déjà dans la liste
    var index = listeRecettes.indexOf(idRecette);

    if (index !== -1) {
        // Supprimer seulement l'élément actuel de la liste
        listeRecettes.splice(index, 1);
        listeTypeMeal.splice(index, 1); // Assurez-vous que cela est cohérent avec la structure de vos données
        console.log("L'ID", idRecette, "a été retiré de la liste des recettes sélectionnées.");
        // Appliquer une bordure pour indiquer l'action réalisée
        element.style.border = '2px solid red';
    } else {
        // Ajouter l'élément à la liste
        listeRecettes.push(idRecette);
        listeTypeMeal.push(idTypeMeal); // Assurez-vous que cela est cohérent avec la structure de vos données
        console.log("L'ID", idRecette, "a été ajouté à la liste des recettes sélectionnées.");

    }

    console.log("Liste des recettes sélectionnées :", listeRecettes);
    console.log("Liste des types de repas sélectionnées :", listeTypeMeal);

    // Convertir le tableau en chaîne JSON et l'enregistrer dans le stockage local
    var listeRecettesJSON = JSON.stringify(listeRecettes);
    var listeTypeMealJSON = JSON.stringify(listeTypeMeal);
    localStorage.setItem('listeRecettes', listeRecettesJSON);
    localStorage.setItem('listeTypeMeal', listeTypeMealJSON);
    console.log("listeRecettesJSON :", listeRecettesJSON);
    console.log("listeTypeMealJSON :", listeTypeMealJSON);
}
