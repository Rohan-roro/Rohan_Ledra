document.addEventListener('DOMContentLoaded', function() {
    console.log("fct updateUsername chargée");
    const member = JSON.parse(localStorage.getItem('member'));
    if (member) {
        const userNameElement = document.getElementById('user-name');
        userNameElement.textContent = `Bienvenue ${member.firstname} ${member.lastname}`;
    }
})