console.log("tourCreate.js");

const backUrl3 = window.location.origin + "/api/rest/tour";

document.querySelector('.saveNewDeliveryPerson').addEventListener('click', function(event) {
    event.preventDefault(); // Empêche le rechargement de la page

    setTimeout(function() {
        // Récupérer les informations du formulaire
        let idDeliveryMan = Number(document.querySelector('#deliveryPerson').value); // Convert to number
        let dateCreationTour = new Date().toISOString().split('T')[0];
        let dateExecutionTour = document.querySelector('#deliveryDate').value;
        let dateStartTour = "0001-01-01"; // À remplacer par la valeur réelle
        let dateEndTour = "0001-01-01"; // À remplacer par la valeur réelle
        let itinerary = localStorage.getItem('tourItinerary');

        // Créer l'objet tour
        let tour = {
            idDeliveryMan: idDeliveryMan,
            dateCreationTour: dateCreationTour,
            dateExecutionTour: dateExecutionTour,
            dateStartTour: dateStartTour,
            dateEndTour: dateEndTour,
            itinerary: itinerary
        };

        // Envoyer l'objet tour à l'API via une requête POST
        fetch(backUrl3 + '/create', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(tour)
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Erreur lors de la création de la tournée');
            }
            return response.json();
        })
        .then(data => {
            console.log('Tournée créée avec succès:', data);
        })
        .catch(error => {
            console.error('Erreur:', error);
        });
    }, 5000); // Delay of 5 seconds
});