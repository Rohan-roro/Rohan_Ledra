console.log("recipeController.js chargé");

// URL of the API endpoint
const backUrl = window.location.origin + "/api/rest/recipe";

// Function to fetch all recipes and display them
function displayAllRecipes() {
    // Get the container where the recipes will be added
    const container = document.querySelector('.conteneur-recettes');

    // Make a GET request to the API
    fetch(backUrl+ "/all")
        .then(response => response.json())
        .then(recipes => {


            // Clear the container
            container.innerHTML = '';

        // For each recipe, create an HTML element and add it to the container
recipes.forEach(recipe => {
    console.log('Processing recipe:', recipe); // Log the entire recipe object to the console

    const recipeElement = document.createElement('div');
    recipeElement.classList.add('recette');

    const title = document.createElement('h3');
    title.textContent = recipe.name;
    recipeElement.appendChild(title);

    const image = document.createElement('img');
    image.alt = recipe.name;
    image.src = recipe.photo;
    image.addEventListener('click', function() {
       ajouterRecette(this, recipe);
    });
    recipeElement.appendChild(image);

    const description = document.createElement('p');
    description.textContent = recipe.description;
    recipeElement.appendChild(description);

    // Log id_recipe and id_type_meal to the console
    console.log('ID de la recette: ' + recipe.id_recipe);
    console.log('ID du type de repas: ' + recipe.id_type_meal);

    container.appendChild(recipeElement);
});
        })
        .catch(error => console.error('Error:', error));
}

// Call the function when the page loads
window.onload = displayAllRecipes;
