document.getElementById('registrationForm').addEventListener('submit', function(event) {
    event.preventDefault();

    let civility = document.getElementById('civility').value;
    let lastname = document.getElementById('lastname').value;
    let firstname = document.getElementById('firstname').value;
    let phone = document.getElementById('phone').value;
    let email = document.getElementById('email').value;
    let address = document.getElementById('adress').value;
    let addressCash = document.getElementById('adress_cash').value;
    let birthDate = document.getElementById('BirthDate').value;
    let password = document.getElementById('password').value;
    let passwordConfirmation = document.getElementById('passwordConfirmation').value;

    // Validation de chaque champ
    if (civility === '') {
        alert('Veuillez sélectionner votre civilité.');
        return false;
    }

    if (lastname === '') {
        alert('Veuillez saisir votre nom.');
        return false;
    }

    if (firstname === '') {
        alert('Veuillez saisir votre prénom.');
        return false;
    }

    // Validation du numéro de téléphone
    if (!validatePhoneNumber(phone)) {
        alert('Veuillez saisir un numéro de téléphone valide (10 chiffres).');
        return false;
    }

    if (email === '' || !validateEmail(email)) {
        alert('Veuillez saisir une adresse email valide.');
        return false;
    }

    if (address === '') {
        alert('Veuillez saisir votre adresse de livraison.');
        return false;
    }

    if (addressCash === '') {
        alert('Veuillez saisir votre adresse de facturation.');
        return false;
    }

    // Validation de la date de naissance
    // Vous pouvez ajouter une validation spécifique pour la date de naissance si nécessaire


    if (password === '') {
        alert('Veuillez saisir votre mot de passe.');
        return false;
    }

    if (passwordConfirmation === '' || passwordConfirmation !== password) {
//        alert('Les mots de passe ne correspondent pas.');
        return false;
    }

    // Si toutes les validations réussissent, vous pouvez soumettre le formulaire
    // Sinon, le formulaire ne sera pas soumis

    // Envoi du formulaire si tout est valide
    this.submit();

});

// Fonction pour valider l'adresse email
function validateEmail(email) {
    const re = /\S+@\S+\.\S+/;
    return re.test(email);
}

// Fonction pour valider le numéro de téléphone
function validatePhoneNumber(phone) {
    // Vérifie si le numéro de téléphone est composé de 10 chiffres
    return /^\d{10}$/.test(phone);
}

    window.onload = function() {
        var testedAdress = document.getElementById('adress');
        var storedAdress = localStorage.getItem('testedAdress');
        if (storedAdress) {
            adress.value = storedAdress;
        }
    };
// Fonction pour gérer la case à cocher
function handleCheckbox() {
    const addressDeliveryInput = document.getElementById('adress');
    const addressBillingInput = document.getElementById('adress_cash');
    const sameAddressCheckbox = document.getElementById('same-address');

    console.log("handleCheckbox function called."); // Log when the function is called

    if (sameAddressCheckbox) {
        console.log("Checkbox found."); // Log when the checkbox is found
        sameAddressCheckbox.addEventListener('change', function() {
            console.log("Checkbox state changed."); // Log when the checkbox state changes
            if (sameAddressCheckbox.checked) {
                console.log("Checkbox is checked."); // Log when the checkbox is checked
                addressBillingInput.value = addressDeliveryInput.value;
                addressBillingInput.disabled = true;
            } else {
                console.log("Checkbox is not checked."); // Log when the checkbox is not checked
                addressBillingInput.value = '';
                addressBillingInput.disabled = false;
            }
        });
    } else {
        console.error("Element 'same-address' not found."); // Log when the checkbox is not found
    }
}

// Appeler la fonction pour gérer la case à cocher au chargement du document
document.addEventListener('DOMContentLoaded', handleCheckbox);