console.log("actualWeeklyOfferRecipe.js chargé");

const backUrl = window.location.origin + "/api/rest/recipe/weeklyOffer";
const currentOfferUrl = window.location.origin + "/api/rest/weeklyOfferCreate/current";

function displayAllRecipes() {
    // Obtenir une référence au conteneur de recettes
    const container = document.querySelector('.conteneur-recettes');

    // Effectuer une requête GET pour obtenir l'ID de l'offre hebdomadaire actuelle
    fetch(currentOfferUrl)
        .then(response => response.json())
        .then(currentOfferId => {
            // Utiliser l'ID de l'offre hebdomadaire actuelle dans la requête fetch pour obtenir les recettes
            const recipesUrl = backUrl + "/" + currentOfferId;
            fetch(recipesUrl)
                .then(response => response.json())
                .then(recipes => {
                    // Clear the container
                    container.innerHTML = '';
                    // Obtenir les 10 premières recettes
                    const firstTenRecipes = recipes.slice(0, 12);
                    // Utiliser les données pour remplir le conteneur de recettes
                    firstTenRecipes.forEach(recipe => {
                        console.log('Processing recipe:', recipe); // Log the entire recipe object to the console

                        const recipeElement = document.createElement('div');
                        recipeElement.classList.add('recette');

                        const title = document.createElement('h3');
                        title.textContent = recipe.name;
                        recipeElement.appendChild(title);

                        const image = document.createElement('img');
                        image.alt = recipe.name;
                        image.src = recipe.photo;
                        recipeElement.appendChild(image);

                        const description = document.createElement('p');
                        description.textContent = recipe.description;
                        recipeElement.appendChild(description);

                        // Log id_recipe and id_type_meal to the console
                        console.log('ID de la recette: ' + recipe.id_recipe);
                        console.log('ID du type de repas: ' + recipe.id_type_meal);

                        container.appendChild(recipeElement);
                    });
                })
                .catch(error => console.error('Error:', error));
        })
        .catch(error => console.error('Error:', error));
}

window.onload = displayAllRecipes;
