//document.getElementById('hour-delivery').addEventListener('change', async function() {
//    if (!this.value) return;
//
//    const start = '8 av Maréchal Lyautey, 61120, VIMOUTIERS';
//    const member = JSON.parse(localStorage.getItem('member'));
//    const apiKey = 'AIzaSyDpIi2mtdWDeDhElFAMb_elVDeEkyllZaM';
//    const proxyUrl = 'https://cors-anywhere.herokuapp.com/';
//
//    try {
//        const addressesResponse = await fetch(`http://127.0.0.1:8081/api/rest/order/adress/${this.value}/2024-06-23`);
//        let addresses = await addressesResponse.json();
//
//        // Ajouter l'adresse du membre aux adresses
//        addresses.push(member.shippingAddress);
//
//        const waypoints = addresses.map(address => encodeURIComponent(address.replace(/,/g, '')));
//        const end = waypoints.pop(); // Set the last waypoint as the destination
//        const url = `https://maps.googleapis.com/maps/api/directions/json?origin=${encodeURIComponent(start)}&destination=${end}&waypoints=${waypoints.join('|')}&key=${apiKey}`;
//
//        const uiUrl = `https://www.google.com/maps/dir/?api=1&origin=${encodeURIComponent(start)}&destination=${end}&waypoints=${waypoints.join('|')}`;
//        console.log('URL de l\'itinéraire dans l\'interface utilisateur de Google Maps:', uiUrl);
//
//        const directionsResponse = await fetch(proxyUrl + url);
//        if (!directionsResponse.ok) throw new Error('Network response was not ok');
//
//        const data = await directionsResponse.json();
//        console.log('Data:', data);
//
//        const totalDurationInSeconds = data.routes[0].legs.reduce((total, leg) => total + leg.duration.value, 0);
//        const totalDurationInHours = Math.floor(totalDurationInSeconds / 3600);
//        const totalDurationInMinutes = Math.floor((totalDurationInSeconds % 3600) / 60);
//        console.log(`Durée totale du trajet : ${totalDurationInHours} heures ${totalDurationInMinutes} minutes`);
//
//        const sortedAddresses = data.routes[0].legs.slice(1).map(leg => leg.start_address.replace(/,/g, '').replace(' France', ''));
//        sortedAddresses.push(data.routes[0].legs[data.routes[0].legs.length - 1].end_address.replace(/,/g, '').replace(' France', ''));
//
//        const sortedAddressesJson = JSON.stringify(sortedAddresses);
//        console.log('JSON sortant:', sortedAddressesJson); // Afficher le JSON sortant en console
//
//        const postResponse = await fetch('http://127.0.0.1:8081/api/rest/order/populateTemporyTable', {
//            method: 'POST',
//            headers: { 'Content-Type': 'application/json' },
//            body: sortedAddressesJson
//        });
//
//        if (postResponse.ok) {
//            console.log('La requête POST a réussi');
//        } else {
//            console.log('La requête POST a échoué avec le statut:', postResponse.status);
//        }
//
//        const text = await postResponse.text();
//        console.log(text);
//    } catch (error) {
//        console.error('Erreur :', error);
//    }
//});
//
//
//// utiliser le local storage localStorage.setItem('sortedAddresses', sortedAddressesJson);