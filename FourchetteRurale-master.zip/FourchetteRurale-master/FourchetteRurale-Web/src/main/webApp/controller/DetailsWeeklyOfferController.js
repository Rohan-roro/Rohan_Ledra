console.log('DetailsWeeklyOfferController.js chargé');

const backUrl2 = window.location.origin + "/api/rest";

function envoyerListeRecettes() {
    // Récupérer la liste de recettes existante depuis le stockage local
    var listeRecettesJSON = localStorage.getItem('listeRecettes');
    var listeRecettes = JSON.parse(listeRecettesJSON);
    var listeTypeMealJSON = localStorage.getItem('listeTypeMeal');
    var listeTypeMeal = JSON.parse(listeTypeMealJSON);

    // Récupérer le dernier ID
    fetch(backUrl2 + "/weeklyOfferCreate/last")
    .then(response => response.json())
    .then(lastId => {
        // Parcourir chaque idRecette dans listeRecettes
        for (var i = 0; i < listeRecettes.length; i++) {
            // Créer un objet JSON pour chaque idRecette
            var data = {
                "idTypeMeal": listeTypeMeal[i],
                "idWeeklyOffer": lastId + 1, // Utiliser le dernier ID récupéré + 1
                "idRecipe": listeRecettes[i]
            };

            // Envoyer l'objet JSON à DetailsWeeklyOfferController via une requête Fetch
            fetch(backUrl2 + '/detailsWeeklyOffer/create', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data),
            })
            .then(response => response.json())
            .then(data => {
                console.log('Données envoyées avec succès:', data);
            })
            .catch((error) => {
                console.error('Erreur lors de l\'envoi des données:', error);
            });
        }
    })
    .catch(error => {
        console.error('Erreur lors de la récupération du dernier ID:', error);
    });
}

// Lier le bouton "Créer l'offre" à la fonction envoyerListeRecettes
document.getElementById('createOffer').addEventListener('click', envoyerListeRecettes);