console.log("OrdreDisplayController.js");
const backUrl2 = window.location.origin + "/api/rest/order";

// Récupérer la liste des commandes
let ul = document.querySelector(".ordersList");

// Get the selected date
let deliveryDateInput = document.querySelector("#deliveryDate");

// Add event listener to the date input field
deliveryDateInput.addEventListener('change', function() {
    let deliveryDate = this.value;
    console.log(deliveryDate);

    // Faire une requête GET à l'API pour obtenir toutes les commandes
    fetch(backUrl2 + '/ordersByShippingDate/' + deliveryDate)
        .then(response => response.json())
        .then(orders => {
            // Clear the list before adding new items
            ul.innerHTML = '';

            // Parcourir la liste des commandes
            for(let i = 0; i < orders.length; i++) {
                // Créer un nouvel élément li
                let li = document.createElement("li");
                li.textContent = 'Commande ' + orders[i].idOrder; // Utiliser les détails de la commande comme texte

                // Ajouter l'élément li à la liste
                ul.appendChild(li);
            }
        })
        .catch(error => console.error('Erreur:', error));
});