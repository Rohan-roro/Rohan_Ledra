console.log("countTypeMeal.js");

const backUrlCount = window.location.origin + "/api/rest/memberMenu";

let memberMenu = JSON.parse(localStorage.getItem('memberMenu'));

let petitsDejeuners, collations, platsPrincipaux, entrees, desserts; // Define the variables in a higher scope

if (memberMenu !== null) {
    let idMemberMenu = memberMenu.idMemberMenu;

    Promise.all([
        fetch(backUrlCount + "/getNumberTypeMeal/"+ 1 + "/" + idMemberMenu)
            .then(response => response.json())
            .then(data1 => {
                console.log(backUrlCount + "/getNumberTypeMeal/" + idMemberMenu + "/" + 1);
                console.log(data1);
                petitsDejeuners = data1;
            }),
        fetch(backUrlCount + "/getNumberTypeMeal/"+ 2 + "/" + idMemberMenu)
            .then(response => response.json())
            .then(data2 => {
                console.log(backUrlCount + "/getNumberTypeMeal/" + idMemberMenu + "/" + 2);
                console.log(data2);
                collations = data2;
            }),
        fetch(backUrlCount + "/getNumberTypeMeal/"+ 3 + "/" + idMemberMenu)
            .then(response => response.json())
            .then(data3 => {
                console.log(backUrlCount + "/getNumberTypeMeal/" + idMemberMenu + "/" + 3);
                console.log(data3);
                platsPrincipaux = data3;
            }),
        fetch(backUrlCount + "/getNumberTypeMeal/"+ 4 + "/" + idMemberMenu)
            .then(response => response.json())
            .then(data4 => {
                console.log(backUrlCount + "/getNumberTypeMeal/" + idMemberMenu + "/" + 4);
                console.log(data4);
                entrees = data4;
            }),
        fetch(backUrlCount + "/getNumberTypeMeal/"+ 5 + "/" + idMemberMenu)
            .then(response => response.json())
            .then(data5 => {
                console.log(backUrlCount + "/getNumberTypeMeal/" + idMemberMenu + "/" + 5);
                console.log(data5);
                desserts = data5;
            })
    ]).then(() => {
        const backUrl = window.location.origin + "/api/rest/price";

        fetch(backUrl+ '/all')
            .then(response => response.json())
            .then(prices => {
                const priceMap = prices.reduce((map, price) => {
                    console.log('Price:', price); // Debugging line

                    map[price.idTypeMeal] = price.priceTypeMeal;
                    return map;
                }, {});

                let totalPrice = 0;

                totalPrice += petitsDejeuners * priceMap[1];
                totalPrice += collations * priceMap[2];
                totalPrice += platsPrincipaux * priceMap[3];
                totalPrice += entrees * priceMap[4];
                totalPrice += desserts * priceMap[5];

                console.log('Prix total:', totalPrice);
                // Après avoir calculé le prix total
                document.getElementById('total').innerText = totalPrice;
            });
    }).catch(error => console.error('Erreur:', error));
} else {
    console.error('Erreur: MemberMenu est null');
}