var listeRecettesStorage;

// Définition de la fonction pour récupérer le tableau du local storage
function recupererTableauLocalStorage() {
    // Récupérer la chaîne JSON du stockage local
    var listeRecettesJSON = localStorage.getItem('listeRecettes');

    // Vérifier si le tableau existe dans le stockage local
    if (listeRecettesJSON) {
        // Convertir la chaîne JSON en tableau JavaScript
        listeRecettesStorage = JSON.parse(listeRecettesJSON);

        // Utiliser le tableau récupéré comme nécessaire
        console.log("info trouvée dans le local storage : ", listeRecettesStorage);
    } else {
        // Le tableau n'existe pas dans le stockage local ou est vide
        console.log("Aucun tableau trouvé dans le stockage local.");
    }
}

// Appeler la fonction lorsque le DOM est chargé
document.addEventListener('DOMContentLoaded', function() {
    recupererTableauLocalStorage();
});
