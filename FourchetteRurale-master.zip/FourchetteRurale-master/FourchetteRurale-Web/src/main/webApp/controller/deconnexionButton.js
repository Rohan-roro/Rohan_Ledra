document.addEventListener('DOMContentLoaded', function() {
    // Sélectionnez l'élément correspondant au bouton ou à tout autre élément que vous souhaitez utiliser pour effacer le stockage local
    const clearStorageBtn = document.getElementById('deconnexionButton');

    // Ajoutez un gestionnaire d'événements pour écouter le clic sur le bouton
    clearStorageBtn.addEventListener('click', function() {

        // Effacez le contenu du stockage local
        localStorage.clear();
            console.log("local storage vidé");
    });
});