console.log('PriceController.js');

const backUrl = window.location.origin + "/api/rest/price";

// Créer un objet de correspondance
const idMap = {
    'petit': 1,
    'collation': 2,
    'repas': 3,
    'entree': 4,
    'dessert': 5
};

// Faire une requête GET à votre API pour récupérer tous les prix des types de repas.
fetch(backUrl+ '/all')
    .then(response => response.json())
    .then(prices => {
        const priceMap = prices.reduce((map, price) => {
            console.log('Price:', price); // Debugging line

            // Use the correct property of the price object as the key
            map[price.idTypeMeal] = price.priceTypeMeal;
            return map;
        }, {});

        // Ajouter des écouteurs d'événements sur les éléments de sélection de votre page HTML.
        const selectElements = document.querySelectorAll('select');
        selectElements.forEach(select => {
            select.addEventListener('change', () => {
                let totalPrice = 0;
                selectElements.forEach(select => {
                    let id = select.id.split('_')[1];

                    // Utiliser l'objet de correspondance pour obtenir l'identifiant numérique
                    let idNumber = idMap[id];
                    if (idNumber === undefined) {
                        console.error('Identifiant invalide:', id);
                    } else {
                        const quantity = select.value;
                        const price = priceMap[idNumber];
                        totalPrice += quantity * price;
                    }
                });
                document.querySelector('#summary li:last-child em').innerText = totalPrice;
            });
        });
    });