// Fetch the config.json file
fetch('../config.json')
    .then(response => response.json())
    .then(config => {
        // Replace the values of codesPostaux with the values from config.json
        codesPostaux = config.postalCodes.value;
        console.log(codesPostaux); // Log the new values of codesPostaux
    })
    .catch(error => console.error('Error:', error));


function showSuggestions(input, inputId) {
    var suggestionsDiv = document.getElementById(inputId + 'Suggestions');
    suggestionsDiv.innerHTML = '';
    if (input.length >= 3) {
        fetch('https://api-adresse.data.gouv.fr/search/?q='+input+'&limit=3')
            .then(response => response.json())
            .then(data => {
                var labels = new Set();
                data.features.forEach(function(feature) {
                    if (!labels.has(feature.properties.label)) {
                        labels.add(feature.properties.label);
                        var div = document.createElement('div');
                        div.innerHTML = feature.properties.label; 
                        div.dataset.postcode = feature.properties.postcode;
                        div.onclick = function() { 
                            var codePostal = this.dataset.postcode.substring(0, 2);
                            document.getElementById(inputId).value = feature.properties.label;
                            suggestionsDiv.innerHTML = '';
                            if (codesPostaux.includes(codePostal)) {
                            console.log('Code postal valide');
                            localStorage.setItem('testedAdress', feature.properties.label);
                             if (window.confirm("Félicitations, vous êtes éligible à notre service de livraison ! Souhaitez-vous créer un compte ?")) {
                              window.location.href = "/UserPages/createAccount.html";
                                                            }

                            } else {
                            console.log('Code postal non valide');
                            window.alert("Oups ! vous n'êtes pas éligible à notre service de livraison, n'hésitez pas à nous contacter pour plus d'informations.");
                            location.reload();
                            }
                        };
                        suggestionsDiv.appendChild(div);
                    }
                });
            });
    }
}