package fr.eql.ai115.fourchette.rurale.controller;

import fr.eql.ai115.fourchette.rurale.business.RegistrationBusiness;
import fr.eql.ai115.fourchette.rurale.entity.Member;
import fr.eql.ai115.fourchette.rurale.entity.dto.AdminDto;
import fr.eql.ai115.fourchette.rurale.entity.dto.DeliveryPersonDto;
import fr.eql.ai115.fourchette.rurale.entity.dto.MemberDto;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Stateless
@Path("/registration")
public class RegistrationController {

    @EJB
    RegistrationBusiness registrationBusiness;

    @POST
    @Path("/member")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response addMember(MemberDto memberDto) {
        registrationBusiness.registerMember(memberDto);
        return Response.ok().build();
    }

    @POST
    @Path("/deliveryPerson")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response addDeliveryPerson(DeliveryPersonDto DeliveryPersonDto) {
        registrationBusiness.registerDeliveryPerson(DeliveryPersonDto);
        return Response.ok().build();
    }

    @POST
    @Path("/admin")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response addAdmin(AdminDto adminDto) {
        registrationBusiness.registerAdmin(adminDto);
        return Response.ok().build();
    }
}