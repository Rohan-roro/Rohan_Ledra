package fr.eql.ai115.fourchette.rurale.controller;

import fr.eql.ai115.fourchette.rurale.business.MemberMenuBusiness;
import fr.eql.ai115.fourchette.rurale.entity.MemberMenu;
import fr.eql.ai115.fourchette.rurale.entity.dto.MemberMenuDto;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Stateless
@Path("/memberMenu")
public class MemberMenuController {

    @EJB
    MemberMenuBusiness memberMenuBusiness;

    @POST
    @Path("/create")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response insertMemberMenu(MemberMenuDto memberMenuDto) {
        memberMenuBusiness.createMemberMenu(memberMenuDto);
        return Response.ok().build();
    }

    @GET
    @Path("/get/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getMemberMenuById(@PathParam("id") Long id) {
        MemberMenu memberMenu = memberMenuBusiness.getMemberMenuById(id);
        return Response.ok(memberMenu).build();

    }

    @GET
    @Path("/getNumberTypeMeal/{idTypeMeal}/{idMemberMenu}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getNumberTypeMeal(@PathParam("idTypeMeal") Long idTypeMeal, @PathParam("idMemberMenu") Long idMemberMenu) {
        int numberTypeMeal = memberMenuBusiness.getNumberTypeMeal(idTypeMeal, idMemberMenu);
        return Response.ok(numberTypeMeal).build();
    }



}
