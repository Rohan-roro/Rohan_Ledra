package fr.eql.ai115.fourchette.rurale.controller;


import fr.eql.ai115.fourchette.rurale.business.SlotBusiness;
import fr.eql.ai115.fourchette.rurale.entity.Slot;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;

@Stateless
@Path("/slot")
public class SlotController {

    @EJB
    SlotBusiness slotBusiness;

    @GET
    @Path("/all")
    @Produces(MediaType.APPLICATION_JSON)
    public Response fetchAllSlots() {
        List<Slot> slots = slotBusiness.findAllSlots();
        return Response.ok(slots).build();
    }
}
