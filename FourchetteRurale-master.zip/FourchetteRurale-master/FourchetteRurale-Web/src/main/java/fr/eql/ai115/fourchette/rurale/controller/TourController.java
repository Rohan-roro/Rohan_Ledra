package fr.eql.ai115.fourchette.rurale.controller;

import fr.eql.ai115.fourchette.rurale.business.TourBusiness;
import fr.eql.ai115.fourchette.rurale.entity.dto.TourDto;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Stateless
@Path("/tour")
public class TourController {

    @EJB
    TourBusiness tourBusiness;

    @POST
    @Path("/create")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response insertTour(TourDto tourDto) {
        tourBusiness.createTour(tourDto);
        return Response.ok().build();
    }

    @GET
    @Path("/lastId")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getLastIdTour() {
        return Response.ok(tourBusiness.getLastIdTour()).build();
    }

    @GET
    @Path("/{idTour}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getTour(@PathParam("idTour") Long idTour) {
        return Response.ok(tourBusiness.getTour(idTour)).build();
    }
    @GET
    @Path("/deliveryMan/{idDeliveryMan}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getToursByDeliveryPerson(@PathParam("idDeliveryMan") Long idDeliveryMan) {
        return Response.ok(tourBusiness.getToursByDeliveryPerson(idDeliveryMan)).build();
    }
}
