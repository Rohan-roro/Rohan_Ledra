package fr.eql.ai115.fourchette.rurale.controller;


import fr.eql.ai115.fourchette.rurale.business.AdminBusiness;
import fr.eql.ai115.fourchette.rurale.entity.Admin;
import fr.eql.ai115.fourchette.rurale.entity.dto.AdminDto;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("/admin")
@Stateless
public class AdminController {

    @EJB
    AdminBusiness adminBusiness;

    @POST
    @Path("/authenticate")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response authenticateAdmin(AdminDto adminDto) {
        Admin authenticatedAdmin = adminBusiness.authenticate(adminDto.getLoginAdmin(), adminDto.getPasswordAdmin());
        return Response.ok(authenticatedAdmin).build();
    }

}
