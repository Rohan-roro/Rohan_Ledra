package fr.eql.ai115.fourchette.rurale.controller;


import fr.eql.ai115.fourchette.rurale.business.WeeklyOfferCreateBusiness;
import fr.eql.ai115.fourchette.rurale.entity.dto.WeeklyOfferCreateDto;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Stateless
@Path("/weeklyOfferCreate")
public class WeeklyOfferCreateController {

    @EJB
    WeeklyOfferCreateBusiness weeklyOfferCreateBusiness;

    @POST
    @Path("/create")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response insertWeeklyOfferCreate(WeeklyOfferCreateDto weeklyOfferCreateDto) {
        weeklyOfferCreateBusiness.createWeeklyOffer(weeklyOfferCreateDto);
        return Response.ok().build();
    }

    @GET
    @Path("/last")
    public Response findLastWeeklyOffer() {
        int lastWeeklyOffer = weeklyOfferCreateBusiness.findLastWeeklyOffer();
        return Response.ok(lastWeeklyOffer).build();
    }

    @GET
    @Path("/current")
    public Response findCurrentWeeklyOffer() {
        int currentWeeklyOffer = weeklyOfferCreateBusiness.findCurrentWeeklyOffer();
        return Response.ok(currentWeeklyOffer).build();
    }

}
