package fr.eql.ai115.fourchette.rurale.controller;


import fr.eql.ai115.fourchette.rurale.business.OrderBusiness;
import fr.eql.ai115.fourchette.rurale.business.RecipeBusiness;
import fr.eql.ai115.fourchette.rurale.entity.Order;
import fr.eql.ai115.fourchette.rurale.entity.dto.ContentOrderDto;
import fr.eql.ai115.fourchette.rurale.entity.dto.OrderDto;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;

@Stateless
@Path("/order")
public class OrderController {

    @EJB
   OrderBusiness orderBusiness;

    @POST
    @Path("/create")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response insertOrder(OrderDto orderDto) {
        orderBusiness.createOrder(orderDto);
        return Response.ok().build();
    }

    @POST
    @Path("/addRecipe")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response addRecipeInOrder(ContentOrderDto contentOrderDto) {
        orderBusiness.addRecipeInOrder(contentOrderDto);
        return Response.ok().build();
    }

    @GET
    @Path("/display")
    @Produces(MediaType.APPLICATION_JSON)
    public Response displayOrders() {
        List<Order> orders = orderBusiness.findAllOrders();
        return Response.ok(orders).build();
    }


    @GET
    @Path("/lastorder/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getLastOrderByMemberId(@PathParam("id") Long id) {
        Order order = orderBusiness.getLastOrderByMemberId(id);
        return Response.ok(order).build();
    }

    @GET
    @Path("/adress/{idTour}/{dateTour}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getOrderAdressByTourAndDate(@PathParam("idTour") Long idTour, @PathParam("dateTour") java.sql.Date dateTour) {
        List<String> adress = orderBusiness.getOrderAdressByTourAndDate(idTour, dateTour);
        return Response.ok(adress).build();
    }

    @POST
    @Path("/populateTemporyTable")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response populateTemporyTable(List<String> adherentsAddresses) {
        orderBusiness.populateTemporyTable(adherentsAddresses);
        return Response.ok().build();
    }

    @GET
    @Path("/shippingAdresses/{dateTour}/{idTour}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getShippingAdressesByTourAndDateTour(@PathParam("dateTour") java.sql.Date dateTour, @PathParam("idTour") Long idTour) {
        List<String> adress = orderBusiness.getShippingAdressesByTourAndDateTour(dateTour, idTour);
        return Response.ok(adress).build();
    }

    @GET
    @Path("/ordersByShippingDate/{dateTour}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getOrdersByShippingDate(@PathParam("dateTour") java.sql.Date dateTour) {
        List<Order> orders = orderBusiness.getOrdersByShippingDate(dateTour);
        return Response.ok(orders).build();
    }

    @GET
    @Path("/delivery/shippingAdresses/{idTour}/{dateTour}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getShippingAdresses(@PathParam("idTour") Long idTour, @PathParam("dateTour") java.sql.Date dateTour) {
        List<String> orders = orderBusiness.getShippingAdresses(idTour, dateTour);
        return Response.ok(orders).build();
    }

}
