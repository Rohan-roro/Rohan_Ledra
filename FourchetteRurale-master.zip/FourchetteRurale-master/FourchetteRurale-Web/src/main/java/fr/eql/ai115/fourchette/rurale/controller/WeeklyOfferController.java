package fr.eql.ai115.fourchette.rurale.controller;

import fr.eql.ai115.fourchette.rurale.business.WeeklyOfferBusiness;
import fr.eql.ai115.fourchette.rurale.entity.WeeklyOffer;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Stateless
@Path("/weeklyoffer")
public class WeeklyOfferController {

    @EJB
    WeeklyOfferBusiness weeklyOfferBusiness;

    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getWeeklyOffer(@PathParam("id") Long id) {
        WeeklyOffer weeklyOffer = weeklyOfferBusiness.findById(id);
        return Response.ok(weeklyOffer).build();
    }
}