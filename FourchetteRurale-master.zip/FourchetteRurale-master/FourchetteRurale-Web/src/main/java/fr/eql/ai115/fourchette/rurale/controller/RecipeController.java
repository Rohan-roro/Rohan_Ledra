package fr.eql.ai115.fourchette.rurale.controller;


import fr.eql.ai115.fourchette.rurale.business.RecipeBusiness;
import fr.eql.ai115.fourchette.rurale.entity.Recipe;
import fr.eql.ai115.fourchette.rurale.entity.dto.RecipeDto;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;

@Stateless
@Path("/recipe")
public class RecipeController {

    @EJB
    RecipeBusiness recipeBusiness;

    @POST
    @Path("/create")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response insertRecipe(RecipeDto recipeDto) {
        recipeBusiness.createRecipe(recipeDto);
        return Response.ok().build();
    }

    @GET
    @Path("/all")
    @Produces(MediaType.APPLICATION_JSON)
    public Response fetchAllRecipes() {
        List<Recipe> recipes = recipeBusiness.findAllRecipes();
        return Response.ok(recipes).build();
    }

    @GET
    @Path("/breakfast")
    @Produces(MediaType.APPLICATION_JSON)
    public Response fetchAllBreakfast() {
        List<Recipe> recipes = recipeBusiness.findAllBreakfast();
        return Response.ok(recipes).build();
    }

    @GET
    @Path("/starter")
    @Produces(MediaType.APPLICATION_JSON)
    public Response fetchAllStarter() {
        List<Recipe> recipes = recipeBusiness.findAllStarter();
        return Response.ok(recipes).build();
    }

    @GET
    @Path("/main")
    @Produces(MediaType.APPLICATION_JSON)
    public Response fetchAllMain() {
        List<Recipe> recipes = recipeBusiness.findAllMain();
        return Response.ok(recipes).build();
    }

    @GET
    @Path("/dessert")
    @Produces(MediaType.APPLICATION_JSON)
    public Response fetchAllDessert() {
        List<Recipe> recipes = recipeBusiness.findAllDessert();
        return Response.ok(recipes).build();
    }

    @GET
    @Path("/collation")
    @Produces(MediaType.APPLICATION_JSON)
    public Response fetchAllCollation() {
        List<Recipe> recipes = recipeBusiness.findAllCollation();
        return Response.ok(recipes).build();
    }

    @GET
    @Path("/weeklyOffer/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response fetchRecipesFromWeeklyOffer(@PathParam("id") Long idWeeklyOffer) {
        List<Recipe> recipes = recipeBusiness.findRecipesFromWeeklyOffer(idWeeklyOffer);
        return Response.ok(recipes).build();
    }
}