package fr.eql.ai115.fourchette.rurale.controller;

import fr.eql.ai115.fourchette.rurale.business.MonthlyMembershipBusiness;
import fr.eql.ai115.fourchette.rurale.entity.MonthlyMembership;
import fr.eql.ai115.fourchette.rurale.entity.dto.MonthlyMemberShipDto;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;


@Path("/member")
@Stateless
public class MonthlyMembershipController {

    @EJB
    MonthlyMembershipBusiness monthlyMembershipBusiness;

    @GET
    @Path("/monthlymembership/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getMonthlyMembershipById(@PathParam("id") Long id) {
        MonthlyMembership monthlyMembership = monthlyMembershipBusiness.getMonthlyMembershipById(id);
        return Response.ok(monthlyMembership).build();
    }

    @POST
    @Path("/monthlymembership/create")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response createMonthlyMembership(MonthlyMemberShipDto monthlyMembershipDto) {
        monthlyMembershipBusiness.createMonthlyMembership(monthlyMembershipDto);
        return Response.ok().build();
    }

}
