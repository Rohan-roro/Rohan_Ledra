package fr.eql.ai115.fourchette.rurale.controller;


import fr.eql.ai115.fourchette.rurale.business.DetailsWeeklyOfferBusiness;
import fr.eql.ai115.fourchette.rurale.entity.dto.DetailsWeeklyOfferDto;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Stateless
@Path("/detailsWeeklyOffer")
public class DetailsWeeklyOfferController {

    @EJB
    DetailsWeeklyOfferBusiness detailsWeeklyOfferBusiness;

    @POST
    @Path("/create")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response insertDetailsWeeklyOffer(DetailsWeeklyOfferDto detailsWeeklyOfferDto) {
        detailsWeeklyOfferBusiness.createWeeklyOfferDetails(detailsWeeklyOfferDto);
        return Response.ok().build();
    }
}
