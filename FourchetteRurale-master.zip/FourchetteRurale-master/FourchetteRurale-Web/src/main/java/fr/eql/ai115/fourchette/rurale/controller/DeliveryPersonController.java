package fr.eql.ai115.fourchette.rurale.controller;

import fr.eql.ai115.fourchette.rurale.business.DeliveryPersonBusiness;
import fr.eql.ai115.fourchette.rurale.entity.DeliveryPerson;
import fr.eql.ai115.fourchette.rurale.entity.dto.DeliveryPersonDto;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;

@Path("/deliveryPerson")
@Stateless
public class DeliveryPersonController {

    @EJB
    DeliveryPersonBusiness deliveryPersonBusiness;

    @POST
    @Path("/authenticate")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response authenticateDeliveryPerson(DeliveryPersonDto deliveryPersonDto) {
        DeliveryPerson authenticatedDeliveryPerson = deliveryPersonBusiness.authenticate(deliveryPersonDto.getEmail(), deliveryPersonDto.getPassword());
        return Response.ok(authenticatedDeliveryPerson).build();
    }

    @GET
    @Path("/display")
    @Produces(MediaType.APPLICATION_JSON)
    public Response displayDeliveryPerson() {
        List<DeliveryPerson> deliveryPersons = deliveryPersonBusiness.findAllDeliveryPersons();
        return Response.ok(deliveryPersons).build();
    }
}

