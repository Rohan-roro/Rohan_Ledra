package fr.eql.ai115.fourchette.rurale.controller;


import fr.eql.ai115.fourchette.rurale.business.CityBusiness;
import fr.eql.ai115.fourchette.rurale.entity.City;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;

@Stateless
@Path("/city")
public class CityController {

    @EJB
    CityBusiness cityBusiness;

    @GET
    @Path("/normandie")
    @Produces(MediaType.APPLICATION_JSON)
    public Response fetchAllCityFromNormandie() {
        List<City> cities = cityBusiness.findAllCityFromNormandie();
        return Response.ok(cities).build();
    }
}
