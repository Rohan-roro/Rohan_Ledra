package fr.eql.ai115.fourchette.rurale.controller;

import fr.eql.ai115.fourchette.rurale.business.ChoiceMemberMenuBusiness;
import fr.eql.ai115.fourchette.rurale.entity.dto.ChoiceMemberMenuDto;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Stateless
@Path("/choiceMemberMenu")
public class ChoiceMemberMenuController {

    @EJB
    ChoiceMemberMenuBusiness choiceMemberMenuBusiness;

    @POST
    @Path("/create")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response insertChoiceMemberMenu(ChoiceMemberMenuDto choiceMemberMenuDto) {
        choiceMemberMenuBusiness.createChoiceMemberMenu(choiceMemberMenuDto);
        return Response.ok().build();
    }
}
