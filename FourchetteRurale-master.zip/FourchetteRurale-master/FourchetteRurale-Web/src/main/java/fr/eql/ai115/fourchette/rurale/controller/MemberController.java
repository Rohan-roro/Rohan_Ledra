package fr.eql.ai115.fourchette.rurale.controller;

import fr.eql.ai115.fourchette.rurale.business.MemberBusiness;
import fr.eql.ai115.fourchette.rurale.entity.Member;
import fr.eql.ai115.fourchette.rurale.entity.dto.MemberDto;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
@Path("/member")
@Stateless
public class MemberController {

    @EJB
    MemberBusiness memberBusiness;

    @POST
    @Path("/authenticate")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response authenticateMember(MemberDto memberDto) {
        Member authenticatedMember = memberBusiness.authenticate(memberDto.getEmailAdress(), memberDto.getPassword());
        return Response.ok(authenticatedMember).build();
    }

    @GET
    @Path("/getLastInsertedId")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getLastInsertedId() {
        Long lastInsertedId = memberBusiness.getLastInsertedId();
        return Response.ok(lastInsertedId).build();
    }
}