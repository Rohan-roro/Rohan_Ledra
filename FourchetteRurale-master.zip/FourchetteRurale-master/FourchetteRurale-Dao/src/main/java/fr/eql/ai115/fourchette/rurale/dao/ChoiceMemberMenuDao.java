package fr.eql.ai115.fourchette.rurale.dao;

import fr.eql.ai115.fourchette.rurale.entity.ChoiceMemberMenu;

public interface ChoiceMemberMenuDao {
    void createChoiceMemberMenu(ChoiceMemberMenu choiceMemberMenu);
}
