package fr.eql.ai115.fourchette.rurale.dao;

import fr.eql.ai115.fourchette.rurale.entity.Admin;

public interface AdminDao {

    Admin authenticate(String login, String password);
    void insertAdmin(Admin admin);


}
