package fr.eql.ai115.fourchette.rurale.dao;


import fr.eql.ai115.fourchette.rurale.entity.WeeklyOfferCreate;

public interface WeeklyOfferCreateDao {
    void createWeeklyOffer(WeeklyOfferCreate weeklyOfferCreate);
    int findLastWeeklyOffer();
    int findCurrentWeeklyOffer();


}
