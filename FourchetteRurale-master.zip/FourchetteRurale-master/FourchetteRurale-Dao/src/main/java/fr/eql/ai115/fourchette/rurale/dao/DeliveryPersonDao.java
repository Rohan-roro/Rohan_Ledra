package fr.eql.ai115.fourchette.rurale.dao;

import fr.eql.ai115.fourchette.rurale.entity.DeliveryPerson;

import java.util.List;

public interface DeliveryPersonDao {

    DeliveryPerson authenticate(String login, String password);
    void insertDeliveryPerson(DeliveryPerson deliveryPerson);
    List<DeliveryPerson> displayAllDeliveryPersons();





}
