package fr.eql.ai115.fourchette.rurale.dao;

import fr.eql.ai115.fourchette.rurale.entity.MonthlyMembership;

public interface MonthlyMembershipDao {

    MonthlyMembership getMonthlyMembershipById(Long memberId);
    void createMonthlyMembership(MonthlyMembership monthlyMembership);
}
