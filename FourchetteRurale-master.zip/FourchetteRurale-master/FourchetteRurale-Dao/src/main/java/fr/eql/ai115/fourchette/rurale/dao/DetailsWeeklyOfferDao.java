package fr.eql.ai115.fourchette.rurale.dao;

import fr.eql.ai115.fourchette.rurale.entity.DetailsWeeklyOffer;

public interface DetailsWeeklyOfferDao {

    void createWeeklyOfferDetails(DetailsWeeklyOffer detailsWeeklyOffer);


}
