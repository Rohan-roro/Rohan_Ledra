package fr.eql.ai115.fourchette.rurale.dao;

import fr.eql.ai115.fourchette.rurale.entity.Member;


public interface MemberDao {

    Member authenticate(String login, String password);
    void insertMember(Member member);
    Long getLastInsertedId();
}

