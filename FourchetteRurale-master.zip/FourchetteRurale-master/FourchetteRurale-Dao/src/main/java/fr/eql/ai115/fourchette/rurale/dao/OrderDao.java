package fr.eql.ai115.fourchette.rurale.dao;

import fr.eql.ai115.fourchette.rurale.entity.ContentOrder;
import fr.eql.ai115.fourchette.rurale.entity.Order;

import java.sql.Date;
import java.util.List;

public interface OrderDao {
    void createOrder(Order order);
    void addRecipeInOrder(ContentOrder contentOrder);
    List<Order> findAllOrders();
    Order getLastOrderByMemberId(Long id);
    List<String> getOrderAdressByTourAndDate(Long idTour, java.sql.Date dateTour);
    void populateTemporyTable(List<String> adherentsAddresses);
    List<String> getShippingAdressesByTourAndDateTour(java.sql.Date dateTour, Long idTour);
    List<Order> getOrdersByShippingDate(java.sql.Date dateTour);
    List<String> getShippingAdresses(Long idTour, Date dateTour);
}
