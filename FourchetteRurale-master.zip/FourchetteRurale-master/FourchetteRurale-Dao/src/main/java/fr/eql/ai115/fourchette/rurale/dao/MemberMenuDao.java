package fr.eql.ai115.fourchette.rurale.dao;

import fr.eql.ai115.fourchette.rurale.entity.MemberMenu;

public interface MemberMenuDao {
    void createMemberMenu(MemberMenu memberMenu);
    MemberMenu getMemberMenuById(Long memberId);
    int getNumberTypeMeal(Long idTypeMeal, Long idMemberMenu);
}
