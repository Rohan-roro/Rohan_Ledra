package fr.eql.ai115.fourchette.rurale.dao;

import fr.eql.ai115.fourchette.rurale.entity.WeeklyOffer;

public interface WeeklyOfferDao {

 WeeklyOffer findById(Long id);




}

