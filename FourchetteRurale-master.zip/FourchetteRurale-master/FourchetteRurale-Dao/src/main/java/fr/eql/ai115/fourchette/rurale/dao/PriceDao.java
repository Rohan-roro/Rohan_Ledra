package fr.eql.ai115.fourchette.rurale.dao;

import fr.eql.ai115.fourchette.rurale.entity.Price;

import java.util.List;

public interface PriceDao {
    List<Price> findAllPrices();
}
