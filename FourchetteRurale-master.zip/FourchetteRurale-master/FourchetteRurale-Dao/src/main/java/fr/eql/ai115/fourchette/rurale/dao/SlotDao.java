package fr.eql.ai115.fourchette.rurale.dao;

import fr.eql.ai115.fourchette.rurale.entity.Slot;

import java.util.List;

public interface SlotDao {
    List<Slot> findAllSlots();
}
