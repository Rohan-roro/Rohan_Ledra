package fr.eql.ai115.fourchette.rurale.dao;

import fr.eql.ai115.fourchette.rurale.entity.Recipe;

import java.util.List;

public interface RecipeDao {
    List<Recipe> findAllRecipes();
    void createRecipe(Recipe recipe);
    List<Recipe> findAllBreakfast();
    List<Recipe> findAllStarter();
    List<Recipe> findAllMain();
    List<Recipe> findAllDessert();
    List<Recipe> findAllCollation();
    List<Recipe> findRecipesFromWeeklyOffer(Long idWeeklyOffer);
}

