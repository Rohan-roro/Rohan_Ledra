package fr.eql.ai115.fourchette.rurale.dao;

import fr.eql.ai115.fourchette.rurale.entity.Tour;

import java.util.List;

public interface TourDao {
    void createTour(Tour tour);
    Long getLastIdTour();
    Tour getTour(Long idTour);
    List<Tour> getToursByDeliveryPerson(Long idDeliveryMan);
}
