package fr.eql.ai115.fourchette.rurale.dao;

import fr.eql.ai115.fourchette.rurale.entity.City;

import java.util.List;

public interface CityDao {
    List<City> findAllCityFromNormandie();
}
