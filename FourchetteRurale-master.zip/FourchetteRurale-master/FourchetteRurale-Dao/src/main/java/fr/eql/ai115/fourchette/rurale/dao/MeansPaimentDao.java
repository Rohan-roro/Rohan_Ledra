package fr.eql.ai115.fourchette.rurale.dao;

import fr.eql.ai115.fourchette.rurale.entity.MeansPaiment;

import java.util.List;


public interface MeansPaimentDao {
    List<MeansPaiment> findAllMeansPaiment();
}
