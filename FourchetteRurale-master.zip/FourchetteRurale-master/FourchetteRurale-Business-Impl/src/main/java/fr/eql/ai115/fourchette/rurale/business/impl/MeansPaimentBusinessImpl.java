package fr.eql.ai115.fourchette.rurale.business.impl;

import fr.eql.ai115.fourchette.rurale.business.MeansPaimentBusiness;
import fr.eql.ai115.fourchette.rurale.dao.MeansPaimentDao;
import fr.eql.ai115.fourchette.rurale.entity.MeansPaiment;

import javax.ejb.EJB;
import javax.ejb.Remote;
import javax.ejb.Stateless;
import java.util.List;

@Remote (MeansPaimentBusiness.class)
@Stateless
public class MeansPaimentBusinessImpl implements MeansPaimentBusiness {

    @EJB
    MeansPaimentDao meansPaimentDao;

    @Override
    public List<MeansPaiment> findAllMeansPaiment() {
        return meansPaimentDao.findAllMeansPaiment();
    }
}
