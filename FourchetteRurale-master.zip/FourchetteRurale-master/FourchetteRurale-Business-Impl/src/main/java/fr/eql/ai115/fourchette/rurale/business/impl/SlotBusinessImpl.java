package fr.eql.ai115.fourchette.rurale.business.impl;


import fr.eql.ai115.fourchette.rurale.business.SlotBusiness;
import fr.eql.ai115.fourchette.rurale.dao.SlotDao;
import fr.eql.ai115.fourchette.rurale.entity.Slot;

import javax.ejb.EJB;
import javax.ejb.Remote;
import javax.ejb.Stateless;
import java.util.List;

@Remote (SlotBusiness.class)
@Stateless
public class SlotBusinessImpl implements SlotBusiness{

        @EJB
        SlotDao slotDao;

        @Override
        public List<Slot> findAllSlots() {
            return slotDao.findAllSlots();
        }


}
