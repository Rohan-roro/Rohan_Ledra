package fr.eql.ai115.fourchette.rurale.business.impl;

import fr.eql.ai115.fourchette.rurale.business.DeliveryPersonBusiness;
import fr.eql.ai115.fourchette.rurale.dao.DeliveryPersonDao;
import fr.eql.ai115.fourchette.rurale.entity.DeliveryPerson;

import javax.ejb.EJB;
import javax.ejb.Remote;
import javax.ejb.Stateless;
import java.util.List;

@Remote(DeliveryPersonBusiness.class)
@Stateless
public class DeliveryPersonBusinessImpl implements DeliveryPersonBusiness {

    @EJB
    DeliveryPersonDao deliveryPersonDao;

    @Override
    public DeliveryPerson authenticate(String login, String password) {
        return deliveryPersonDao.authenticate(login, password);
    }

    @Override
    public List<DeliveryPerson> findAllDeliveryPersons() {
        return deliveryPersonDao.displayAllDeliveryPersons();
    }


}

