package fr.eql.ai115.fourchette.rurale.business.impl;

import fr.eql.ai115.fourchette.rurale.business.OrderBusiness;
import fr.eql.ai115.fourchette.rurale.business.TourBusiness;
import fr.eql.ai115.fourchette.rurale.dao.TourDao;
import fr.eql.ai115.fourchette.rurale.entity.Tour;
import fr.eql.ai115.fourchette.rurale.entity.dto.TourDto;

import javax.ejb.EJB;
import javax.ejb.Remote;
import javax.ejb.Stateless;
import java.util.List;

@Remote (TourBusiness.class)
@Stateless
public class TourBusinessImpl implements TourBusiness {

    @EJB
    TourDao tourDao;

    @Override
    public void createTour(TourDto tourDto) {
        Tour tour = new Tour(tourDto.getIdTour(), tourDto.getIdDeliveryMan(), tourDto.getDateCreationTour(),
                tourDto.getDateExecutionTour(), tourDto.getDateStartTour(), tourDto.getDateEndTour(),
                tourDto.getItinerary());
        tourDao.createTour(tour);

    }

    @Override
    public Long getLastIdTour() {
        return tourDao.getLastIdTour();
    }

    @Override
    public Tour getTour(Long idTour) {
        Tour tour = tourDao.getTour(idTour);
        return new Tour(tour.getIdTour(), tour.getIdDeliveryMan(), tour.getDateCreationTour(),
                tour.getDateExecutionTour(), tour.getDateStartTour(), tour.getDateEndTour(),
                tour.getItinerary());

}
    @Override
    public List<Tour> getToursByDeliveryPerson(Long idDeliveryMan) {
        return tourDao.getToursByDeliveryPerson(idDeliveryMan);
    }

}
