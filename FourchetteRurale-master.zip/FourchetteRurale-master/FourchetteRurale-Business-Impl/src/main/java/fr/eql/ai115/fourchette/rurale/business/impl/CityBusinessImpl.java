package fr.eql.ai115.fourchette.rurale.business.impl;

import fr.eql.ai115.fourchette.rurale.business.CityBusiness;
import fr.eql.ai115.fourchette.rurale.dao.CityDao;
import fr.eql.ai115.fourchette.rurale.entity.City;

import javax.ejb.EJB;
import javax.ejb.Remote;
import javax.ejb.Stateless;
import java.util.List;

@Remote (CityBusiness.class)
@Stateless
public class CityBusinessImpl implements CityBusiness{

    @EJB
    CityDao cityDao;

    @Override
    public List<City> findAllCityFromNormandie() {
        return cityDao.findAllCityFromNormandie();
    }
}
