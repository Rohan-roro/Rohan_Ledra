package fr.eql.ai115.fourchette.rurale.business.impl;


import fr.eql.ai115.fourchette.rurale.business.ChoiceMemberMenuBusiness;
import fr.eql.ai115.fourchette.rurale.dao.ChoiceMemberMenuDao;
import fr.eql.ai115.fourchette.rurale.entity.ChoiceMemberMenu;
import fr.eql.ai115.fourchette.rurale.entity.dto.ChoiceMemberMenuDto;

import javax.ejb.EJB;
import javax.ejb.Remote;
import javax.ejb.Stateless;

@Remote (ChoiceMemberMenuBusiness.class)
@Stateless
public class ChoiceMemberMenuBusinessImpl implements ChoiceMemberMenuBusiness {

    @EJB
    ChoiceMemberMenuDao choiceMemberMenuDao;

    @Override
    public void createChoiceMemberMenu(ChoiceMemberMenuDto choiceMemberMenuDto) {
        ChoiceMemberMenu choiceMemberMenu = new ChoiceMemberMenu(choiceMemberMenuDto.getIdMenuChoice(), choiceMemberMenuDto.getIdMemberMenu(),
                choiceMemberMenuDto.getIdTypeMeal(), choiceMemberMenuDto.getIdDay(), choiceMemberMenuDto.getQuantity());
        choiceMemberMenuDao.createChoiceMemberMenu(choiceMemberMenu);
    }

}
