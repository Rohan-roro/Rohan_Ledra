package fr.eql.ai115.fourchette.rurale.business.impl;


import fr.eql.ai115.fourchette.rurale.business.DetailsWeeklyOfferBusiness;
import fr.eql.ai115.fourchette.rurale.dao.DetailsWeeklyOfferDao;
import fr.eql.ai115.fourchette.rurale.entity.DetailsWeeklyOffer;
import fr.eql.ai115.fourchette.rurale.entity.dto.DetailsWeeklyOfferDto;

import javax.ejb.EJB;
import javax.ejb.Remote;
import javax.ejb.Stateless;

@Remote (DetailsWeeklyOfferBusiness.class)
@Stateless
public class DetailsWeeklyOfferBusinessImpl implements DetailsWeeklyOfferBusiness {

    @EJB
    DetailsWeeklyOfferDao detailsWeeklyOfferDao;

    @Override
    public void createWeeklyOfferDetails(DetailsWeeklyOfferDto detailsWeeklyOfferDto) {
        DetailsWeeklyOffer detailsWeeklyOffer = new DetailsWeeklyOffer(detailsWeeklyOfferDto.getIdDetailsWeeklyOffer(), detailsWeeklyOfferDto.getIdWeeklyOffer(), detailsWeeklyOfferDto.getIdTypeMeal(), detailsWeeklyOfferDto.getIdRecipe());
        detailsWeeklyOfferDao.createWeeklyOfferDetails(detailsWeeklyOffer);
    }
}
