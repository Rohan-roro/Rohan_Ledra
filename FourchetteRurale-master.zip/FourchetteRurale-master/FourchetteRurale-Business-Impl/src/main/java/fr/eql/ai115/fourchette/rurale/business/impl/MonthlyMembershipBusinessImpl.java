package fr.eql.ai115.fourchette.rurale.business.impl;


import fr.eql.ai115.fourchette.rurale.business.MonthlyMembershipBusiness;
import fr.eql.ai115.fourchette.rurale.dao.MonthlyMembershipDao;
import fr.eql.ai115.fourchette.rurale.entity.MonthlyMembership;
import fr.eql.ai115.fourchette.rurale.entity.dto.MonthlyMemberShipDto;

import javax.ejb.EJB;
import javax.ejb.Remote;
import javax.ejb.Stateless;

@Remote(MonthlyMembershipBusiness.class)
@Stateless
public class MonthlyMembershipBusinessImpl implements MonthlyMembershipBusiness{

    @EJB
    MonthlyMembershipDao monthlyMembershipDao;

    @Override
    public MonthlyMembership getMonthlyMembershipById(Long id) {
        return monthlyMembershipDao.getMonthlyMembershipById(id);
    }

    @Override
    public void createMonthlyMembership(MonthlyMemberShipDto monthlyMembershipDto) {
        MonthlyMembership monthlyMembership = new MonthlyMembership(monthlyMembershipDto.getId_paiement(), monthlyMembershipDto.getId_adherent(), monthlyMembershipDto.getId_moyen_paye(), monthlyMembershipDto.getDate_adhesion(), monthlyMembershipDto.getDate_paiement());
        monthlyMembershipDao.createMonthlyMembership(monthlyMembership);
    }

}
