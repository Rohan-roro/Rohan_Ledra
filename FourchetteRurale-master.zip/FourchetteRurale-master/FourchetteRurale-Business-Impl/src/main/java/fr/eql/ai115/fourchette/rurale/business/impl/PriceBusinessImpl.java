package fr.eql.ai115.fourchette.rurale.business.impl;


import fr.eql.ai115.fourchette.rurale.business.PriceBusiness;
import fr.eql.ai115.fourchette.rurale.dao.PriceDao;
import fr.eql.ai115.fourchette.rurale.entity.Price;

import javax.ejb.EJB;
import javax.ejb.Remote;
import javax.ejb.Stateless;
import java.util.List;

@Remote (PriceBusiness.class)
@Stateless
public class PriceBusinessImpl implements PriceBusiness{

    @EJB
    PriceDao priceDao;

    @Override
    public List<Price> findAllPrices() {
        return priceDao.findAllPrices();
    }
}
