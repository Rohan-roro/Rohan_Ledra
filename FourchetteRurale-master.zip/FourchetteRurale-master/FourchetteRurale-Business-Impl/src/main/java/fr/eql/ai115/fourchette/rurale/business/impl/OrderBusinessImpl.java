package fr.eql.ai115.fourchette.rurale.business.impl;


import fr.eql.ai115.fourchette.rurale.business.OrderBusiness;
import fr.eql.ai115.fourchette.rurale.dao.OrderDao;
import fr.eql.ai115.fourchette.rurale.entity.ContentOrder;
import fr.eql.ai115.fourchette.rurale.entity.Order;
import fr.eql.ai115.fourchette.rurale.entity.dto.ContentOrderDto;
import fr.eql.ai115.fourchette.rurale.entity.dto.OrderDto;

import javax.ejb.EJB;
import javax.ejb.Remote;
import javax.ejb.Stateless;
import java.util.List;

@Remote (OrderBusiness.class)
@Stateless
public class OrderBusinessImpl implements OrderBusiness {

    @EJB
    OrderDao orderDao;


    @Override
    public void createOrder(OrderDto orderDto) {
        Order order = new Order(orderDto.getIdOrder(), orderDto.getIdSlot(), orderDto.getIdMember(),
                orderDto.getIdNote(), orderDto.getIdBug(), orderDto.getIdTour(), orderDto.getShippingDate(),
                orderDto.getComment(), orderDto.getDateExecuteShipping(), orderDto.getDeliveryOrder());
        orderDao.createOrder(order);
    }

    @Override
    public void addRecipeInOrder(ContentOrderDto contentOrderDto) {
        ContentOrder contentOrder = new ContentOrder(contentOrderDto.getIdWeeklyOffer(), contentOrderDto.getIdOrder(), contentOrderDto.getIdRecipe());
        orderDao.addRecipeInOrder(contentOrder);
    }

    @Override
    public Order getLastOrderByMemberId(Long id) {
        return orderDao.getLastOrderByMemberId(id);
    }

    @Override
    public List<Order> findAllOrders() {
        return orderDao.findAllOrders();
    }

    @Override
    public List<String> getOrderAdressByTourAndDate(Long idTour, java.sql.Date dateTour) {
        return orderDao.getOrderAdressByTourAndDate(idTour, dateTour);
    }

    @Override
    public void populateTemporyTable(List<String> adherentsAddresses) {
        orderDao.populateTemporyTable(adherentsAddresses);
    }

    @Override
    public List<String> getShippingAdressesByTourAndDateTour(java.sql.Date dateTour, Long idTour) {
        return orderDao.getShippingAdressesByTourAndDateTour(dateTour, idTour);
    }

    @Override
    public List<Order> getOrdersByShippingDate(java.sql.Date dateTour) {
        return orderDao.getOrdersByShippingDate(dateTour);
    }

    @Override
    public List<String> getShippingAdresses(Long idTour, java.sql.Date dateTour) {
        return orderDao.getShippingAdresses(idTour, dateTour);
    }
}
