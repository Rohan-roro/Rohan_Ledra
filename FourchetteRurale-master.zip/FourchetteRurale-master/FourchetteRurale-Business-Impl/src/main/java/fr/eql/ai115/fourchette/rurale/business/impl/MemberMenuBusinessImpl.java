package fr.eql.ai115.fourchette.rurale.business.impl;

import fr.eql.ai115.fourchette.rurale.business.MemberMenuBusiness;
import fr.eql.ai115.fourchette.rurale.dao.MemberMenuDao;
import fr.eql.ai115.fourchette.rurale.entity.MemberMenu;
import fr.eql.ai115.fourchette.rurale.entity.dto.MemberMenuDto;

import javax.ejb.EJB;
import javax.ejb.Remote;
import javax.ejb.Stateless;

@Remote (MemberMenuBusiness.class)
@Stateless
public class MemberMenuBusinessImpl implements MemberMenuBusiness {

    @EJB
    MemberMenuDao memberMenuDao;

    @Override
    public void createMemberMenu(MemberMenuDto memberMenuDto) {
        MemberMenu memberMenu = new MemberMenu(memberMenuDto.getIdMemberMenu(), memberMenuDto.getIdMember(),
                memberMenuDto.getDayToDeliver(), memberMenuDto.getChoiceDate());
        memberMenuDao.createMemberMenu(memberMenu);
    }

    @Override
    public MemberMenu getMemberMenuById(Long memberId) {
        return memberMenuDao.getMemberMenuById(memberId);
    }

    @Override
    public int getNumberTypeMeal(Long idTypeMeal, Long idMemberMenu) {
        return memberMenuDao.getNumberTypeMeal(idTypeMeal, idMemberMenu);
    }


}
