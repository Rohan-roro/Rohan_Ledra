package fr.eql.ai115.fourchette.rurale.business.impl;

import fr.eql.ai115.fourchette.rurale.business.WeeklyOfferBusiness;
import fr.eql.ai115.fourchette.rurale.dao.WeeklyOfferDao;
import fr.eql.ai115.fourchette.rurale.entity.WeeklyOffer;

import javax.ejb.EJB;
import javax.ejb.Remote;
import javax.ejb.Stateless;

@Remote(WeeklyOfferBusiness.class)
@Stateless
public class WeeklyOfferBusinessImpl implements WeeklyOfferBusiness {

    @EJB
    WeeklyOfferDao weeklyOfferDao;

    @Override
    public WeeklyOffer findById(Long id) {
        return weeklyOfferDao.findById(id);
    }
}