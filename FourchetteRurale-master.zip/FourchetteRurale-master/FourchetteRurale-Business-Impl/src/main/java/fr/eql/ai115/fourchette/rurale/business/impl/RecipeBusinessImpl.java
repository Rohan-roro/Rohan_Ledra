package fr.eql.ai115.fourchette.rurale.business.impl;


import fr.eql.ai115.fourchette.rurale.business.RecipeBusiness;
import fr.eql.ai115.fourchette.rurale.dao.RecipeDao;
import fr.eql.ai115.fourchette.rurale.entity.Recipe;
import fr.eql.ai115.fourchette.rurale.entity.dto.RecipeDto;

import javax.ejb.EJB;
import javax.ejb.Remote;
import javax.ejb.Stateless;
import java.util.List;

@Remote (RecipeBusiness.class)
@Stateless
public class RecipeBusinessImpl implements RecipeBusiness {

    @EJB
    RecipeDao recipeDao;

    @Override
    public void createRecipe(RecipeDto recipeDto) {
        Recipe recipe = new Recipe(recipeDto.getId_recipe(), recipeDto.getId_type_meal(), recipeDto.getName(),
                recipeDto.getIngredients(), recipeDto.getPhoto(), recipeDto.getDescription(),
                recipeDto.getCreation_date(), recipeDto.getDeletion_date()
        );
        recipeDao.createRecipe(recipe);
    }

    @Override
    public List<Recipe> findAllRecipes() {
        return recipeDao.findAllRecipes();
    }

    @Override
    public List<Recipe> findAllBreakfast() {
        return recipeDao.findAllBreakfast();
    }

    @Override
    public List<Recipe> findAllStarter() {
        return recipeDao.findAllStarter();
    }

    @Override
    public List<Recipe> findAllMain() {
        return recipeDao.findAllMain();
    }

    @Override
    public List<Recipe> findAllDessert() {
        return recipeDao.findAllDessert();
    }

    @Override
    public List<Recipe> findAllCollation() {
        return recipeDao.findAllCollation();
    }

    @Override
    public List<Recipe> findRecipesFromWeeklyOffer(Long idWeeklyOffer) {
        return recipeDao.findRecipesFromWeeklyOffer(idWeeklyOffer);
    }
}
