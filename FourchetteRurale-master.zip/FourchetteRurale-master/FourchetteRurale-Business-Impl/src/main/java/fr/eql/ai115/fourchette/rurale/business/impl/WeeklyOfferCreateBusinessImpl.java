package fr.eql.ai115.fourchette.rurale.business.impl;


import fr.eql.ai115.fourchette.rurale.business.WeeklyOfferCreateBusiness;
import fr.eql.ai115.fourchette.rurale.dao.WeeklyOfferCreateDao;
import fr.eql.ai115.fourchette.rurale.entity.WeeklyOfferCreate;
import fr.eql.ai115.fourchette.rurale.entity.dto.WeeklyOfferCreateDto;

import javax.ejb.EJB;
import javax.ejb.Remote;
import javax.ejb.Stateless;

@Remote(WeeklyOfferCreateBusiness.class)
@Stateless
public class WeeklyOfferCreateBusinessImpl implements WeeklyOfferCreateBusiness {

    @EJB
    WeeklyOfferCreateDao weeklyOfferCreateDao;

    @Override
public void createWeeklyOffer(WeeklyOfferCreateDto weeklyOfferCreateDto) {
        WeeklyOfferCreate weeklyOfferCreate = new WeeklyOfferCreate(weeklyOfferCreateDto.getId_weekly_offer(), weeklyOfferCreateDto.getCreation_date(), weeklyOfferCreateDto.getStart_date(), weeklyOfferCreateDto.getEnd_date());
        weeklyOfferCreateDao.createWeeklyOffer(weeklyOfferCreate);
    }

    @Override
    public int findLastWeeklyOffer() {
        return weeklyOfferCreateDao.findLastWeeklyOffer();
    }

    @Override
    public int findCurrentWeeklyOffer() {
        return weeklyOfferCreateDao.findCurrentWeeklyOffer();
    }


}
