package fr.eql.ai115.fourchette.rurale.business.impl;

import fr.eql.ai115.fourchette.rurale.business.MemberBusiness;
import fr.eql.ai115.fourchette.rurale.dao.MemberDao;
import fr.eql.ai115.fourchette.rurale.entity.Member;

import javax.ejb.EJB;
import javax.ejb.Remote;
import javax.ejb.Stateless;

@Remote(MemberBusiness.class)
@Stateless
public class MemberBusinessImpl implements MemberBusiness {

    @EJB
    MemberDao memberDao;

    @Override
    public Member authenticate(String login, String password) {
        return memberDao.authenticate(login, password);
    }

    @Override
    public Long getLastInsertedId() {
        return memberDao.getLastInsertedId();
    }
}