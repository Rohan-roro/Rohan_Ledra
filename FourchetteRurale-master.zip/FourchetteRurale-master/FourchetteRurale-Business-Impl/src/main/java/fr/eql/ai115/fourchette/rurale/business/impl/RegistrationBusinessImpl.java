package fr.eql.ai115.fourchette.rurale.business.impl;

import fr.eql.ai115.fourchette.rurale.business.RegistrationBusiness;
import fr.eql.ai115.fourchette.rurale.dao.AdminDao;
import fr.eql.ai115.fourchette.rurale.dao.DeliveryPersonDao;
import fr.eql.ai115.fourchette.rurale.dao.MemberDao;
import fr.eql.ai115.fourchette.rurale.entity.Admin;
import fr.eql.ai115.fourchette.rurale.entity.DeliveryPerson;
import fr.eql.ai115.fourchette.rurale.entity.Member;
import fr.eql.ai115.fourchette.rurale.entity.dto.AdminDto;
import fr.eql.ai115.fourchette.rurale.entity.dto.DeliveryPersonDto;
import fr.eql.ai115.fourchette.rurale.entity.dto.MemberDto;

import javax.ejb.EJB;
import javax.ejb.Remote;
import javax.ejb.Stateless;

@Remote(RegistrationBusiness.class)
@Stateless
public class RegistrationBusinessImpl implements RegistrationBusiness {

    @EJB
    MemberDao memberDao;
    @EJB
    DeliveryPersonDao DeliveryPersonDao;
    @EJB
    AdminDao adminDao;

    @Override
    public void registerMember(MemberDto memberDto) {
        Member member = new Member(memberDto.getIdMember(), memberDto.getCity(), memberDto.getCivility(),
                memberDto.getFirstname(), memberDto.getLastname(), memberDto.getBirthdate(), memberDto.getPhoneNumber(),
                memberDto.getEmailAdress(), memberDto.getPassword(), memberDto.getShippingAddress(),
                memberDto.getBillingAddress(), memberDto.getRegistrationDate(), memberDto.getUnsubscriptionDate()
        );
        memberDao.insertMember(member);
    }

    @Override
    public void registerDeliveryPerson(DeliveryPersonDto deliveryPersonDto) {
        DeliveryPerson deliveryPerson = new DeliveryPerson(deliveryPersonDto.getId_delivery_person(), deliveryPersonDto.getId_civility(),
                deliveryPersonDto.getFirstname(), deliveryPersonDto.getLastname(), deliveryPersonDto.getPhone(),
                deliveryPersonDto.getEmail(), deliveryPersonDto.getPassword()
        );
        DeliveryPersonDao.insertDeliveryPerson(deliveryPerson);
    }

    @Override
    public void registerAdmin(AdminDto adminDto) {
        Admin admin = new Admin(adminDto.getIdAdmin(), adminDto.getLoginAdmin(), adminDto.getPasswordAdmin());
        adminDao.insertAdmin(admin);

    }
}