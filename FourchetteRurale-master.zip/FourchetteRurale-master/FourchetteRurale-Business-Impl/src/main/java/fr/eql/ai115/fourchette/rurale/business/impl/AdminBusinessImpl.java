package fr.eql.ai115.fourchette.rurale.business.impl;


import fr.eql.ai115.fourchette.rurale.business.AdminBusiness;
import fr.eql.ai115.fourchette.rurale.dao.AdminDao;
import fr.eql.ai115.fourchette.rurale.entity.Admin;

import javax.ejb.EJB;
import javax.ejb.Remote;
import javax.ejb.Stateless;

@Remote (AdminBusiness.class)
@Stateless
public class AdminBusinessImpl implements AdminBusiness {

    @EJB
    AdminDao adminDao;

    @Override
    public Admin authenticate(String login, String password) {
        return adminDao.authenticate(login, password);
    }
}
