package fr.eql.ai115.fourchette.rurale.dao.impl;

import fr.eql.ai115.fourchette.rurale.dao.TourDao;
import fr.eql.ai115.fourchette.rurale.dao.impl.connection.FourchetteRuraleDataSource;
import fr.eql.ai115.fourchette.rurale.entity.Tour;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.sql.DataSource;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

@Remote(TourDao.class)
@Stateless
public class TourDaoImpl implements TourDao {

    private static final Logger logger = LogManager.getLogger();

    private static final String REQ_CREATE_TOUR = "INSERT INTO tournee (id_livreur, date_creation, date_execution, date_depart, date_retour, itineraire_tournee) VALUES (?,?,?,?,?,?)";
    private static final String REQ_GET_LAST_ID_TOUR = "SELECT MAX(id_tournee) FROM tournee";
    private static final String REQ_GET_TOUR = "SELECT * FROM tournee WHERE id_tournee = ?";
    private static final String REQ_GET_TOURS_BY_DELIVERY_PERSON = "SELECT * FROM tournee WHERE id_livreur = ?";


    private final DataSource dataSource = new FourchetteRuraleDataSource();

    @Override
    public void createTour(Tour tour) {
        try (Connection connection = dataSource.getConnection()) {
            connection.setAutoCommit(false);
            long id = tourStatementExecution(connection, tour);
            if (id > 0) {
                tour.setIdTour(id);
                logger.info("Tournée créée avec succès");
            } else {
                connection.rollback();
            }
            connection.commit();
        } catch (SQLException e) {
            logger.error("Erreur lors de la création de la tournée", e);
        }
    }

    private long tourStatementExecution(Connection connection, Tour tour) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement(REQ_CREATE_TOUR, Statement.RETURN_GENERATED_KEYS)) {
            statement.setLong(1, tour.getIdDeliveryMan());
            statement.setDate(2, java.sql.Date.valueOf(tour.getDateCreationTour()));
            statement.setDate(3, java.sql.Date.valueOf(tour.getDateExecutionTour()));
            statement.setDate(4, java.sql.Date.valueOf(tour.getDateStartTour()));
            statement.setDate(5, java.sql.Date.valueOf(tour.getDateEndTour()));
            statement.setString(6, tour.getItinerary());
            int affectedRows = statement.executeUpdate();
            if (affectedRows > 0) {
                try (ResultSet resultSet = statement.getGeneratedKeys()) {
                    if (resultSet.next()) {
                        return resultSet.getLong(1);
                    }
                } catch (SQLException e) {
                    connection.rollback();
                    logger.error("Erreur lors de la création de la tournée", e);
                }
            }
            return -1;
        }

    }

    @Override
    public Long getLastIdTour() {
        try (Connection connection = dataSource.getConnection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(REQ_GET_LAST_ID_TOUR)) {
            if (resultSet.next()) {
                return resultSet.getLong(1);
            }
        } catch (SQLException e) {
            logger.error("Erreur lors de la récupération de l'id de la tournée", e);
        }
        return null;
    }

    @Override
    public Tour getTour(Long idTour) {
        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(REQ_GET_TOUR)) {
            statement.setLong(1, idTour);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return new Tour(
                            resultSet.getLong("id_tournee"),
                            resultSet.getLong("id_livreur"),
                            resultSet.getDate("date_creation").toLocalDate(),
                            resultSet.getDate("date_execution").toLocalDate(),
                            resultSet.getDate("date_depart").toLocalDate(),
                            resultSet.getDate("date_retour").toLocalDate(),
                            resultSet.getString("itineraire_tournee")
                    );
                }
            }
        } catch (SQLException e) {
            logger.error("Erreur lors de la récupération de la tournée", e);
        }
        return null;
    }

    @Override
    public List<Tour> getToursByDeliveryPerson(Long idDeliveryMan) {
        List<Tour> tours = new ArrayList<>();
        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(REQ_GET_TOURS_BY_DELIVERY_PERSON)) {
            statement.setLong(1, idDeliveryMan);
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    tours.add(new Tour(
                            resultSet.getLong("id_tournee"),
                            resultSet.getLong("id_livreur"),
                            resultSet.getDate("date_creation").toLocalDate(),
                            resultSet.getDate("date_execution").toLocalDate(),
                            resultSet.getDate("date_depart").toLocalDate(),
                            resultSet.getDate("date_retour").toLocalDate(),
                            resultSet.getString("itineraire_tournee")
                    ));
                }
            }
        } catch (SQLException e) {
            logger.error("Erreur lors de la récupération des tournées", e);
        }
        return tours;
    }
}
