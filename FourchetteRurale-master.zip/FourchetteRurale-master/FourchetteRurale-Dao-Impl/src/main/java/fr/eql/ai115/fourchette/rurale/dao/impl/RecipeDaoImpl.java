package fr.eql.ai115.fourchette.rurale.dao.impl;


import fr.eql.ai115.fourchette.rurale.dao.RecipeDao;
import fr.eql.ai115.fourchette.rurale.dao.impl.connection.FourchetteRuraleDataSource;
import fr.eql.ai115.fourchette.rurale.entity.Recipe;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.sql.DataSource;
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Remote(RecipeDao.class)
@Stateless
public class RecipeDaoImpl implements RecipeDao {

    private static final Logger Logger = LogManager.getLogger();

    private static final String SELECT_ALL_RECIPE = "SELECT * FROM recette  ";

    private static final String SELECT_BREAKFAST = "SELECT * FROM recette WHERE id_type_de_repas=1";

    private static final String SELECT_STARTER = "SELECT * FROM recette WHERE id_type_de_repas=4";

    private static final String SELECT_MAIN = "SELECT * FROM recette WHERE id_type_de_repas=3";

    private static final String SELECT_DESSERT = "SELECT * FROM recette WHERE id_type_de_repas=5";

    private static final String SELECT_COLLATION = "SELECT * FROM recette WHERE id_type_de_repas=2";

    private static final String REQ_CREATE_RECIPE = "INSERT INTO recette (id_type_de_repas, nom_recette, ingredient, photo, description, date_creation, date_retrait) VALUES (?,?,?,?,?,?,?)";

    private static final String REQ_RECIPE_FROM_WEEKLY_OFFER = "SELECT r.*\n" +
            "FROM recette AS r\n" +
            "JOIN detail_de_l_offre_hebdomadaire AS doh ON r.id_recette = doh.id_recette\n" +
            "JOIN offrehebdomadaire AS oh ON doh.id_offre_hebdo = oh.id_offre_hebdo\n" +
            "WHERE oh.id_offre_hebdo = ?;";

    private final DataSource dataSource = new FourchetteRuraleDataSource();

    @Override
    public List<Recipe> findAllRecipes() {
        List<Recipe> recipes = new ArrayList<>();
        try (Connection connection = dataSource.getConnection()) {
            PreparedStatement statement = connection.prepareStatement(SELECT_ALL_RECIPE);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                java.sql.Date dateRetraitSql = resultSet.getDate("date_retrait");
                LocalDate dateRetrait = dateRetraitSql != null ? dateRetraitSql.toLocalDate() : null;

                Recipe recipe = new Recipe(
                        resultSet.getLong("id_recette"),
                        resultSet.getLong("id_type_de_repas"),
                        resultSet.getString("nom_recette"),
                        resultSet.getString("ingredient"),
                        resultSet.getString("photo"),
                        resultSet.getString("description"),
                        resultSet.getDate("date_creation").toLocalDate(),
                        dateRetrait
                );
                recipes.add(recipe);
            }
        } catch (SQLException e) {
            Logger.error("Une erreur s'est produite lors de la consultation des recettes en base de données", e);
        }
        return recipes;
    }


    @Override
    public List<Recipe> findAllBreakfast() {
        List<Recipe> recipes = new ArrayList<>();
        try (Connection connection = dataSource.getConnection()) {
            PreparedStatement statement = connection.prepareStatement(SELECT_BREAKFAST);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                java.sql.Date dateRetraitSql = resultSet.getDate("date_retrait");
                LocalDate dateRetrait = dateRetraitSql != null ? dateRetraitSql.toLocalDate() : null;

                Recipe recipe = new Recipe(
                        resultSet.getLong("id_recette"),
                        resultSet.getLong("id_type_de_repas"),
                        resultSet.getString("nom_recette"),
                        resultSet.getString("ingredient"),
                        resultSet.getString("photo"),
                        resultSet.getString("description"),
                        resultSet.getDate("date_creation").toLocalDate(),
                        dateRetrait
                );
                recipes.add(recipe);
            }
        } catch (SQLException e) {
            Logger.error("Une erreur s'est produite lors de la consultation des recettes en base de données", e);
        }
        return recipes;
    }


    @Override
    public List<Recipe> findAllStarter() {
        List<Recipe> recipes = new ArrayList<>();
        try (Connection connection = dataSource.getConnection()) {
            PreparedStatement statement = connection.prepareStatement(SELECT_STARTER);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                java.sql.Date dateRetraitSql = resultSet.getDate("date_retrait");
                LocalDate dateRetrait = dateRetraitSql != null ? dateRetraitSql.toLocalDate() : null;

                Recipe recipe = new Recipe(
                        resultSet.getLong("id_recette"),
                        resultSet.getLong("id_type_de_repas"),
                        resultSet.getString("nom_recette"),
                        resultSet.getString("ingredient"),
                        resultSet.getString("photo"),
                        resultSet.getString("description"),
                        resultSet.getDate("date_creation").toLocalDate(),
                        dateRetrait
                );
                recipes.add(recipe);
            }
        } catch (SQLException e) {
            Logger.error("Une erreur s'est produite lors de la consultation des recettes en base de données", e);
        }
        return recipes;
    }


    @Override
    public List<Recipe> findAllMain() {
        List<Recipe> recipes = new ArrayList<>();
        try (Connection connection = dataSource.getConnection()) {
            PreparedStatement statement = connection.prepareStatement(SELECT_MAIN);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                java.sql.Date dateRetraitSql = resultSet.getDate("date_retrait");
                LocalDate dateRetrait = dateRetraitSql != null ? dateRetraitSql.toLocalDate() : null;

                Recipe recipe = new Recipe(
                        resultSet.getLong("id_recette"),
                        resultSet.getLong("id_type_de_repas"),
                        resultSet.getString("nom_recette"),
                        resultSet.getString("ingredient"),
                        resultSet.getString("photo"),
                        resultSet.getString("description"),
                        resultSet.getDate("date_creation").toLocalDate(),
                        dateRetrait
                );
                recipes.add(recipe);
            }
        } catch (SQLException e) {
            Logger.error("Une erreur s'est produite lors de la consultation des recettes en base de données", e);
        }
        return recipes;
    }


    @Override
    public List<Recipe> findAllDessert() {
        List<Recipe> recipes = new ArrayList<>();
        try (Connection connection = dataSource.getConnection()) {
            PreparedStatement statement = connection.prepareStatement(SELECT_DESSERT);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                java.sql.Date dateRetraitSql = resultSet.getDate("date_retrait");
                LocalDate dateRetrait = dateRetraitSql != null ? dateRetraitSql.toLocalDate() : null;

                Recipe recipe = new Recipe(
                        resultSet.getLong("id_recette"),
                        resultSet.getLong("id_type_de_repas"),
                        resultSet.getString("nom_recette"),
                        resultSet.getString("ingredient"),
                        resultSet.getString("photo"),
                        resultSet.getString("description"),
                        resultSet.getDate("date_creation").toLocalDate(),
                        dateRetrait
                );
                recipes.add(recipe);
            }
        } catch (SQLException e) {
            Logger.error("Une erreur s'est produite lors de la consultation des recettes en base de données", e);
        }
        return recipes;
    }


    @Override
    public List<Recipe> findAllCollation() {
        List<Recipe> recipes = new ArrayList<>();
        try (Connection connection = dataSource.getConnection()) {
            PreparedStatement statement = connection.prepareStatement(SELECT_COLLATION);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                java.sql.Date dateRetraitSql = resultSet.getDate("date_retrait");
                LocalDate dateRetrait = dateRetraitSql != null ? dateRetraitSql.toLocalDate() : null;

                Recipe recipe = new Recipe(
                        resultSet.getLong("id_recette"),
                        resultSet.getLong("id_type_de_repas"),
                        resultSet.getString("nom_recette"),
                        resultSet.getString("ingredient"),
                        resultSet.getString("photo"),
                        resultSet.getString("description"),
                        resultSet.getDate("date_creation").toLocalDate(),
                        dateRetrait
                );
                recipes.add(recipe);
            }
        } catch (SQLException e) {
            Logger.error("Une erreur s'est produite lors de la consultation des recettes en base de données", e);
        }
        return recipes;
    }

    @Override
    public List<Recipe> findRecipesFromWeeklyOffer(Long idWeeklyOffer) {
        List<Recipe> recipes = new ArrayList<>();
        try (Connection connection = dataSource.getConnection()) {
            PreparedStatement statement = connection.prepareStatement(REQ_RECIPE_FROM_WEEKLY_OFFER);
            statement.setLong(1, idWeeklyOffer);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                java.sql.Date dateRetraitSql = resultSet.getDate("date_retrait");
                LocalDate dateRetrait = dateRetraitSql != null ? dateRetraitSql.toLocalDate() : null;

                Recipe recipe = new Recipe(
                        resultSet.getLong("id_recette"),
                        resultSet.getLong("id_type_de_repas"),
                        resultSet.getString("nom_recette"),
                        resultSet.getString("ingredient"),
                        resultSet.getString("photo"),
                        resultSet.getString("description"),
                        resultSet.getDate("date_creation").toLocalDate(),
                        dateRetrait
                );
                recipes.add(recipe);
            }
        } catch (SQLException e) {
            Logger.error("Une erreur s'est produite lors de la consultation des recettes en base de données", e);
        }
        return recipes;
    }

    @Override
    public void createRecipe(Recipe recipe) {
        try (Connection connection = dataSource.getConnection()) {
            connection.setAutoCommit(false);
            long id = recipeStatementExecution(recipe, connection);
            if (id > 0) {
                recipe.setId_recipe(id);
                Logger.info("Recipe " + recipe.getName() + " inserted into database with id " + id);
            } else {
                connection.rollback();
            }
            connection.commit();
        } catch (SQLException e) {
            Logger.error("Une erreur s'est produite lors de l'insertion de la recette en base de données", e);
        }
    }

    private long recipeStatementExecution(Recipe recipe, Connection connection) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement(REQ_CREATE_RECIPE, Statement.RETURN_GENERATED_KEYS)) {
            statement.setLong(1, recipe.getId_type_meal());
            statement.setString(2, recipe.getName());
            statement.setString(3, recipe.getIngredients());
            statement.setString(4, recipe.getPhoto());
            statement.setString(5, recipe.getDescription());
            statement.setDate(6, java.sql.Date.valueOf(recipe.getCreation_date()));
            statement.setDate(7, recipe.getDeletion_date() != null ? java.sql.Date.valueOf(recipe.getDeletion_date()) : null);
            int affectedRows = statement.executeUpdate();
            if (affectedRows > 0) {
                try (ResultSet resultSet = statement.getGeneratedKeys()) {
                    if (resultSet.next()) {
                        return resultSet.getLong(1);
                    }
                }   catch (SQLException e) {
                    connection.rollback();
                    Logger.error("An error occurred while retrieving the id of the inserted member.", e);
                }
            }
            return -1;
        }
    }
}
