package fr.eql.ai115.fourchette.rurale.dao.impl;

import fr.eql.ai115.fourchette.rurale.dao.MonthlyMembershipDao;
import fr.eql.ai115.fourchette.rurale.dao.impl.connection.FourchetteRuraleDataSource;
import fr.eql.ai115.fourchette.rurale.entity.MonthlyMembership;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


@Remote(MonthlyMembershipDao.class)
@Stateless
public class MonthlyMembershipDaoImpl implements MonthlyMembershipDao {

    private static final Logger logger = LogManager.getLogger();

    private static final String REQ_GET_MONTHLY_MEMBERSHIP_BY_ID = "SELECT * FROM adhesionmensuel WHERE id_adherent = ?";

    private static final String REQ_CREATE_MONTHLY_MEMBERSHIP = "INSERT INTO adhesionmensuel (id_adherent, id_moyen_paye, date_adhesion, date_paiement) VALUES (?, ?, ?, ?)";

    private final DataSource dataSource = new FourchetteRuraleDataSource();

    @Override
    public MonthlyMembership getMonthlyMembershipById(Long id) {
        MonthlyMembership monthlyMembership = null;
        try (Connection connection = dataSource.getConnection()) {
            PreparedStatement statement = connection.prepareStatement(REQ_GET_MONTHLY_MEMBERSHIP_BY_ID);
            statement.setLong(1, id);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                monthlyMembership = new MonthlyMembership(
                        resultSet.getLong("id_paiement"),
                        resultSet.getLong("id_adherent"),
                        resultSet.getLong("id_moyen_paye"),
                        resultSet.getDate("date_adhesion").toLocalDate(),
                        resultSet.getDate("date_paiement").toLocalDate()
                );
            }
        } catch (SQLException e) {
            logger.error("Une erreur s'est produite lors de la récupération de l'adhésion mensuelle", e);
        }
        return monthlyMembership;
    }

    @Override
    public void createMonthlyMembership(MonthlyMembership monthlyMembership) {
        try (Connection connection = dataSource.getConnection()) {
            connection.setAutoCommit(false);
            long id = memberShipStatementExecution(monthlyMembership, connection);
            if (id > 0) {
                monthlyMembership.setId_paiement(id);
                logger.info("Adhésion mensuelle créée avec succès");
            } else {
                connection.rollback();
                logger.error("Une erreur s'est produite lors de la création de l'adhésion mensuelle");
            }
            connection.commit();
        } catch (SQLException e) {
            logger.error("Une erreur s'est produite lors de la création de l'adhésion mensuelle", e);

        }

}

    private long memberShipStatementExecution(MonthlyMembership monthlyMembership, Connection connection) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement(REQ_CREATE_MONTHLY_MEMBERSHIP, PreparedStatement.RETURN_GENERATED_KEYS)) {
            statement.setLong(1, monthlyMembership.getId_adherent());
            statement.setLong(2, monthlyMembership.getId_moyen_paye());
            statement.setDate(3, java.sql.Date.valueOf(monthlyMembership.getDate_adhesion()));
            statement.setDate(4, java.sql.Date.valueOf(monthlyMembership.getDate_paiement()));
            int affectedRows = statement.executeUpdate();
            if (affectedRows > 0) {
                try (ResultSet resultSet = statement.getGeneratedKeys()) {
                    if (resultSet.next()) {
                        return resultSet.getLong(1);
                    }
                } catch (SQLException e) {
                    connection.rollback();
                    logger.error("Une erreur s'est produite lors de la récupération de l'identifiant de l'adhésion mensuelle", e);
                }

            }
            return -1;
        }
    }
}