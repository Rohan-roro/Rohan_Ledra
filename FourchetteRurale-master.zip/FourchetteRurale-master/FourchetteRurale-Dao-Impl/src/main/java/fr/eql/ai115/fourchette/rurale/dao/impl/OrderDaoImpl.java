package fr.eql.ai115.fourchette.rurale.dao.impl;


import fr.eql.ai115.fourchette.rurale.dao.OrderDao;
import fr.eql.ai115.fourchette.rurale.dao.impl.connection.FourchetteRuraleDataSource;
import fr.eql.ai115.fourchette.rurale.entity.ContentOrder;
import fr.eql.ai115.fourchette.rurale.entity.Order;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.sql.DataSource;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

@Remote(OrderDao.class)
@Stateless
public class OrderDaoImpl implements OrderDao {

    private static final Logger logger = LogManager.getLogger();

    private static final String REQ_CREATE_ORDER = "INSERT INTO commande (id_creneau, id_adherent, id_note, id_motif_anomalie, id_tournee, date_livraison, evaluation, date_realisation_livraison, ordre_livraison) VALUES (?,?,?,?,?,?,?,?,?)";

    private static final String REQ_ADD_RECIPE_IN_ORDER = "INSERT INTO offrehebdo_commande (id_offre_hebdo, id_commande, id_recette) VALUES (?,?,?)";

    private static final String REQ_GET_ALL_ORDERS = "SELECT * FROM commande";

    private static final String REQ_GET_LAST_ORDER_BY_ID = "SELECT * FROM commande WHERE id_adherent = ? ORDER BY id_commande DESC LIMIT 1";

    private static final String REQ_GET_ORDER_ADRESS_BY_ID_TOUR_AND_DATE_TOUR = "SELECT a.adresse_livraison FROM commande AS c JOIN adherent AS a ON c.id_adherent = a.id_adherent WHERE c.id_creneau = ? AND c.date_livraison = ?";

    private static final String REQ_INSERT_ID_MEMBER_IN_TEMPORY_TABLE = "INSERT INTO liste_adherents_triee (id_adherent) SELECT id_adherent FROM adherent WHERE adresse_livraison = ?";

    private static final String REQ_CLEAR_TEMPORY_TABLE = "DELETE FROM liste_adherents_triee";

    private static final String REQ_GET_SHIPPING_ADRESSES_BY_ID_TOUR_AND_DATE_TOUR = "SELECT c.date_livraison, c.id_creneau, a.adresse_livraison FROM commande c JOIN adherent a ON c.id_adherent = a.id_adherent WHERE c.date_livraison = ? AND c.id_creneau = ?";

    private static final String REQ_GET_ORDERS_BY_SHIPPING_DATE = "SELECT * FROM commande WHERE date_livraison = ?";

    private static final String REQ_GET_SHIPPING_ADRESSES_ = "SELECT a.adresse_livraison\n" +
            "FROM commande c\n" +
            "JOIN adherent a ON c.id_adherent = a.id_adherent\n" +
            "WHERE c.id_tournee = ? AND c.date_livraison = ?";

    DataSource dataSource = new FourchetteRuraleDataSource();

    @Override
    public void createOrder(Order order) {
        try (Connection connection = dataSource.getConnection()) {
            connection.setAutoCommit(false);
            long id = orderStatementExecution(connection, order);
            if (id > 0) {
                order.setIdOrder(id);
                logger.info("Commande créée avec succès");
            } else {
                logger.error("Erreur lors de la création de la commande");
            }
            connection.commit();
        } catch (SQLException e) {
            logger.error("Erreur lors de la création de la commande", e);
        }
    }

    @Override
    public void addRecipeInOrder(ContentOrder contentOrder) {
        try (Connection connection = dataSource.getConnection()) {
            connection.setAutoCommit(false);
            boolean success = contentOrderStatementExecution(connection, contentOrder);
            if (success) {
                logger.info("Recette ajoutée à la commande avec succès");
            } else {
                logger.error("Erreur1 lors de l'ajout de la recette à la commande");
            }
            connection.commit();
        } catch (SQLException e) {
            logger.error("Erreur2 lors de l'ajout de la recette à la commande", e);
        }
    }

    private boolean contentOrderStatementExecution(Connection connection, ContentOrder contentOrder) {
        if (connection == null) {
            logger.error("Connection is null");
            return false;
        }
        if (contentOrder == null) {
            logger.error("ContentOrder is null");
            return false;
        }
        if (contentOrder.getIdWeeklyOffer() == null || contentOrder.getIdOrder() == null || contentOrder.getIdRecipe() == null) {
            logger.error("One or more ContentOrder properties are null");
            return false;
        }
        try (PreparedStatement statement = connection.prepareStatement(REQ_ADD_RECIPE_IN_ORDER)) {
            statement.setLong(1, contentOrder.getIdWeeklyOffer());
            statement.setLong(2, contentOrder.getIdOrder());
            statement.setLong(3, contentOrder.getIdRecipe());
            int affectedRows = statement.executeUpdate();
            if (affectedRows > 0) {
                return true;
            }
            return false;
        } catch (SQLException e) {
            logger.error("Erreur lors de l'ajout de la recette à la commande", e);
            return false;
        }
    }

    @Override
    public List<Order> findAllOrders() {
        List<Order> orders = new ArrayList<>();
        try (Connection connection = dataSource.getConnection()) {
            PreparedStatement statement = connection.prepareStatement(REQ_GET_ALL_ORDERS);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                Order order = new Order(
                        resultSet.getLong("id_commande"),
                        resultSet.getLong("id_creneau"),
                        resultSet.getLong("id_adherent"),
                        resultSet.getLong("id_note"),
                        resultSet.getLong("id_motif_anomalie"),
                        resultSet.getLong("id_tournee"),
                        resultSet.getDate("date_livraison").toLocalDate(),
                        resultSet.getString("evaluation"),
                        resultSet.getDate("date_realisation_livraison").toLocalDate(),
                        resultSet.getInt("ordre_livraison")
                );
                orders.add(order);
            }
        } catch (SQLException e) {
            logger.error("Erreur lors de la consultation des commandes en base de données", e);

        }
        return orders;
    }



    private long orderStatementExecution(Connection connection, Order order) throws SQLException{
        try (PreparedStatement statement = connection.prepareStatement(REQ_CREATE_ORDER, Statement.RETURN_GENERATED_KEYS)) {
            statement.setLong(1, order.getIdSlot());
            statement.setLong(2, order.getIdMember());
            statement.setLong(3, order.getIdNote());
            statement.setLong(4, order.getIdBug());
            statement.setLong(5, order.getIdTour());
            statement.setDate(6, java.sql.Date.valueOf(order.getShippingDate()));
            statement.setString(7, order.getComment());
            statement.setDate(8, java.sql.Date.valueOf(order.getDateExecuteShipping()));
            statement.setInt(9, order.getDeliveryOrder());
            int affectedRows = statement.executeUpdate();
            if (affectedRows > 0) {
                try (ResultSet resultSet = statement.getGeneratedKeys()) {
                    if (resultSet.next()) {
                        return resultSet.getLong(1);
                    }
                } catch (SQLException e) {
                    connection.rollback();
                    logger.error("Erreur lors de la création de la commande", e);
                }
            }
            return -1;
        }
    }

    @Override
    public Order getLastOrderByMemberId(Long idMember) {
        Order order = null;
        try (Connection connection = dataSource.getConnection()) {
            PreparedStatement statement = connection.prepareStatement(REQ_GET_LAST_ORDER_BY_ID);
            statement.setLong(1, idMember);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                order = new Order(
                        resultSet.getLong("id_commande"),
                        resultSet.getLong("id_creneau"),
                        resultSet.getLong("id_adherent"),
                        resultSet.getLong("id_note"),
                        resultSet.getLong("id_motif_anomalie"),
                        resultSet.getLong("id_tournee"),
                        resultSet.getDate("date_livraison").toLocalDate(),
                        resultSet.getString("evaluation"),
                        resultSet.getDate("date_realisation_livraison").toLocalDate(),
                        resultSet.getInt("ordre_livraison")
                );
            }
        } catch (SQLException e) {
            logger.error("Une erreur s'est produite lors de la récupération de la dernière commande", e);
        }
        return order;
    }

    @Override
    public List<String> getOrderAdressByTourAndDate(Long idTour, java.sql.Date dateTour) {
        List<String> addresses = new ArrayList<>();
        try (Connection connection = dataSource.getConnection()) {
            PreparedStatement statement = connection.prepareStatement(REQ_GET_ORDER_ADRESS_BY_ID_TOUR_AND_DATE_TOUR);
            statement.setLong(1, idTour);
            statement.setDate(2, dateTour);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                addresses.add(resultSet.getString("adresse_livraison"));
            }
        } catch (SQLException e) {
            logger.error("Une erreur s'est produite lors de la récupération des adresses de la commande", e);
        }
        return addresses;
    }
    @Override
    public void populateTemporyTable(List<String> adherentsAddresses) {
        try (Connection connection = dataSource.getConnection()) {
            PreparedStatement clearStatement = connection.prepareStatement(REQ_CLEAR_TEMPORY_TABLE);
            clearStatement.executeUpdate();
            PreparedStatement statement = connection.prepareStatement(REQ_INSERT_ID_MEMBER_IN_TEMPORY_TABLE);
            for (String address : adherentsAddresses) {
                statement.setString(1, address);
                statement.executeUpdate();
            }

            CallableStatement stmt = connection.prepareCall("{call UpdateOrdreLivraison()}");
            stmt.execute();
        } catch (SQLException e) {
            logger.error("Erreur lors de l'insertion des ID d'adhérents dans la table temporaire ou lors de l'appel de la procédure stockée", e);
        }
    }

    @Override
    public List<String> getShippingAdressesByTourAndDateTour(java.sql.Date dateTour, Long idTour) {
        List<String> addresses = new ArrayList<>();
        try (Connection connection = dataSource.getConnection()) {
            PreparedStatement statement = connection.prepareStatement(REQ_GET_SHIPPING_ADRESSES_BY_ID_TOUR_AND_DATE_TOUR);
            statement.setDate(1, dateTour);
            statement.setLong(2, idTour);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                addresses.add(resultSet.getString("adresse_livraison"));
            }
        } catch (SQLException e) {
            logger.error("Une erreur s'est produite lors de la récupération des adresses de la commande", e);
        }
        return addresses;
    }

    @Override
    public List<Order> getOrdersByShippingDate(java.sql.Date dateTour) {
        List<Order> orders = new ArrayList<>();
        try (Connection connection = dataSource.getConnection()) {
            PreparedStatement statement = connection.prepareStatement(REQ_GET_ORDERS_BY_SHIPPING_DATE);
            statement.setDate(1, dateTour);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                Order order = new Order(
                        resultSet.getLong("id_commande"),
                        resultSet.getLong("id_creneau"),
                        resultSet.getLong("id_adherent"),
                        resultSet.getLong("id_note"),
                        resultSet.getLong("id_motif_anomalie"),
                        resultSet.getLong("id_tournee"),
                        resultSet.getDate("date_livraison").toLocalDate(),
                        resultSet.getString("evaluation"),
                        resultSet.getDate("date_realisation_livraison").toLocalDate(),
                        resultSet.getInt("ordre_livraison")
                );
                orders.add(order);
            }
        } catch (SQLException e) {
            logger.error("Erreur lors de la consultation des commandes en base de données", e);
        }
        return orders;
    }

    @Override
    public List<String> getShippingAdresses(Long idTour, java.sql.Date dateTour) {
        List<String> addresses = new ArrayList<>();
        try (Connection connection = dataSource.getConnection()) {
            PreparedStatement statement = connection.prepareStatement(REQ_GET_SHIPPING_ADRESSES_);
            statement.setLong(1, idTour);
            statement.setDate(2, dateTour);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                addresses.add(resultSet.getString("adresse_livraison"));
            }
        } catch (SQLException e) {
            logger.error("Une erreur s'est produite lors de la récupération des adresses de la commande", e);
        }
        return addresses;
    }
}



