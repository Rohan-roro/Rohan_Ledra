package fr.eql.ai115.fourchette.rurale.dao.impl;


import fr.eql.ai115.fourchette.rurale.dao.ChoiceMemberMenuDao;
import fr.eql.ai115.fourchette.rurale.dao.impl.connection.FourchetteRuraleDataSource;
import fr.eql.ai115.fourchette.rurale.entity.ChoiceMemberMenu;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.sql.DataSource;
import java.sql.*;

@Remote
@Stateless
public class ChoiceMemberMenuDaoImpl implements ChoiceMemberMenuDao {

    private static final Logger logger = LogManager.getLogger();

    private static final String REQ_CREATE_CHOICE_MEMBER_MENU = "INSERT INTO detail_de_structure_de_menu (id_structure_menu, id_type_de_repas, id_jour, nb_repas_type) VALUES (?,?,?,?)";

    private final DataSource dataSource = new FourchetteRuraleDataSource();

    @Override
    public void createChoiceMemberMenu(ChoiceMemberMenu choiceMemberMenu) {
        try (Connection connection = dataSource.getConnection()) {
            connection.setAutoCommit(false);
            long id = choiceMemberMenuStatementExecution(choiceMemberMenu, connection);
            if (id > 0) {
                choiceMemberMenu.setIdMenuChoice(id);
                logger.info("Le choix de menu a bien été enregistré en base de données");
            } else {
                connection.rollback();
                logger.error("Une erreur s'est produite lors de l'enregistrement du choix de menu en base de données");
            }
            connection.commit();
        } catch (SQLException e) {
            logger.error("Une erreur s'est produite lors de l'enregistrement du choix de menu en base de données", e);
        }

    }

    private long choiceMemberMenuStatementExecution(ChoiceMemberMenu choiceMemberMenu, Connection connection) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement(REQ_CREATE_CHOICE_MEMBER_MENU, Statement.RETURN_GENERATED_KEYS)) {
            statement.setLong(1, choiceMemberMenu.getIdMemberMenu());
            statement.setLong(2, choiceMemberMenu.getIdTypeMeal());
            statement.setLong(3, choiceMemberMenu.getIdDay());
            statement.setLong(4, choiceMemberMenu.getQuantity());
            int affectedRows = statement.executeUpdate();
            if (affectedRows > 0) {
                try (ResultSet resultSet = statement.getGeneratedKeys()) {
                    if (resultSet.next()) {
                        return resultSet.getLong(1);
                    }
                } catch (SQLException e) {
                    connection.rollback();
                    logger.error("Une erreur s'est produite lors de la récupération de l'identifiant du choix de menu", e);
                }
            }
           return -1;
        }

//        @Override
//        public choiceMemberMenu getChoiceMemberMenuById {
//            return null;
//        }

    }

}
