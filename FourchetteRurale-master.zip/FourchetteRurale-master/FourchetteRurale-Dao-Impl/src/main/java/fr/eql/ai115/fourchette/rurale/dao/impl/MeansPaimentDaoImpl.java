package fr.eql.ai115.fourchette.rurale.dao.impl;


import fr.eql.ai115.fourchette.rurale.dao.MeansPaimentDao;
import fr.eql.ai115.fourchette.rurale.dao.impl.connection.FourchetteRuraleDataSource;
import fr.eql.ai115.fourchette.rurale.entity.MeansPaiment;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@Remote (MeansPaimentDao.class)
@Stateless
public class MeansPaimentDaoImpl implements MeansPaimentDao {

       private static final Logger logger = LogManager.getLogger();

        private static final String SELECT_ALL_MEANS_PAIMENT = "SELECT * FROM moyendepaiement";

        private final DataSource dataSource = new FourchetteRuraleDataSource();

        @Override
        public List<MeansPaiment> findAllMeansPaiment() {
            List<MeansPaiment> meansPaiments = new ArrayList<>();
            try (Connection connection = dataSource.getConnection()) {
                PreparedStatement statement = connection.prepareStatement(SELECT_ALL_MEANS_PAIMENT);
                ResultSet resultSet = statement.executeQuery();
                while (resultSet.next()) {
                    MeansPaiment meansPaiment = new MeansPaiment(
                            resultSet.getLong("id_moyen_paye"),
                            resultSet.getString("libelle_moyen_paye")
                    );
                    meansPaiments.add(meansPaiment);
                }
            } catch (SQLException e) {
                logger.error("Une erreur s'est produite lors de la consultation des moyens de paiement en base de données", e);
            }
            return meansPaiments;
        }
}
