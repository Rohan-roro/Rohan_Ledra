package fr.eql.ai115.fourchette.rurale.dao.impl;


import fr.eql.ai115.fourchette.rurale.dao.WeeklyOfferCreateDao;
import fr.eql.ai115.fourchette.rurale.dao.impl.connection.FourchetteRuraleDataSource;
import fr.eql.ai115.fourchette.rurale.entity.WeeklyOffer;
import fr.eql.ai115.fourchette.rurale.entity.WeeklyOfferCreate;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@Remote(WeeklyOfferCreateDao.class)
@Stateless
public class WeeklyOfferCreateDaoImpl implements WeeklyOfferCreateDao {

    private static final Logger logger = LogManager.getLogger();

    private static final String REQ_CREATE_WEEKLY_OFFER = "INSERT INTO offrehebdomadaire (date_creation, date_debut, date_fin) VALUES (NOW(),?,?)";

    private static final String SELECT_LAST_WEEKLY_OFFER = "SELECT id_offre_hebdo FROM offrehebdomadaire ORDER BY id_offre_hebdo DESC LIMIT 1";

    private static final String SELECT_CURRENT_WEEKLY_OFFER = "SELECT id_offre_hebdo, date_creation, date_debut, date_fin FROM offrehebdomadaire WHERE date_debut <= CURDATE() AND date_fin >= NOW()";
     private final DataSource dataSource = new FourchetteRuraleDataSource();

     @Override
     public int findLastWeeklyOffer() {
        int id = 0;
        try (Connection connection = dataSource.getConnection()) {
            PreparedStatement statement = connection.prepareStatement(SELECT_LAST_WEEKLY_OFFER);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                id = resultSet.getInt("id_offre_hebdo");
            }
        } catch (SQLException e) {
            logger.error("Une erreur s'est produite lors de la récupération de l'offre hebdomadaire", e);
        }
        return id;

     }

     @Override
     public int findCurrentWeeklyOffer() {
        int id = 0;
        try (Connection connection = dataSource.getConnection()) {
            PreparedStatement statement = connection.prepareStatement(SELECT_CURRENT_WEEKLY_OFFER);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                id = resultSet.getInt("id_offre_hebdo");
            }
        } catch (SQLException e) {
            logger.error("Une erreur s'est produite lors de la récupération de l'offre hebdomadaire", e);
        }
        return id;
     }



    @Override
    public void createWeeklyOffer(WeeklyOfferCreate weeklyOfferCreate) {
        try (Connection connection = dataSource.getConnection()) {
            connection.setAutoCommit(false);
            long id = weeklyOfferCreateStatementExecution(weeklyOfferCreate, connection);
            if (id > 0) {
                weeklyOfferCreate.setId_weekly_offer(id);
                logger.info("Offre hebdomadaire créée avec succès");
            } else {
                connection.rollback();
            }
            connection.commit();
        } catch (SQLException e) {
            logger.error("Une erreur s'est produite lors de la création de l'offre hebdomadaire", e);
        }
    }

    private long weeklyOfferCreateStatementExecution(WeeklyOfferCreate weeklyOfferCreate, Connection connection) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement(REQ_CREATE_WEEKLY_OFFER, PreparedStatement.RETURN_GENERATED_KEYS)) {
            statement.setDate(1, java.sql.Date.valueOf(weeklyOfferCreate.getStart_date()));
            statement.setDate(2, java.sql.Date.valueOf(weeklyOfferCreate.getEnd_date()));
            int affectedRows = statement.executeUpdate();
            if (affectedRows > 0) {
                try (ResultSet resultSet = statement.getGeneratedKeys()) {
                    if (resultSet.next()) {
                        return resultSet.getLong(1);
                    }
                } catch (SQLException e) {
                    logger.error("Une erreur s'est produite lors de la récupération de l'id de l'offre hebdomadaire", e);
                }
            }
            return -1;
        }

    }

}
