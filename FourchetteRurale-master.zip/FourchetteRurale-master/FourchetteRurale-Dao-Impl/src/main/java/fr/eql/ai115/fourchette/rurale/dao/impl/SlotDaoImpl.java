package fr.eql.ai115.fourchette.rurale.dao.impl;


import fr.eql.ai115.fourchette.rurale.dao.SlotDao;
import fr.eql.ai115.fourchette.rurale.dao.impl.connection.FourchetteRuraleDataSource;
import fr.eql.ai115.fourchette.rurale.entity.Slot;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

@Remote(SlotDao.class)
@Stateless
public class SlotDaoImpl implements SlotDao {

    private static final Logger logger = LogManager.getLogger();

    private static final String REQ_GET_ALL_SLOTS = "SELECT * FROM creneau";


    DataSource dataSource = new FourchetteRuraleDataSource();

    @Override
    public List<Slot> findAllSlots() {
        List<Slot> slots = new ArrayList<>();
        try (Connection connection = dataSource.getConnection()) {
            PreparedStatement statement = connection.prepareStatement(REQ_GET_ALL_SLOTS);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                Slot slot = new Slot(
                        resultSet.getLong("id_creneau"),
                        resultSet.getTime("heure_deb_creneau").toLocalTime(),
                        resultSet.getTime("heure_fin_creneau").toLocalTime()
                );
                slots.add(slot);
            }
        } catch (Exception e) {
            logger.error("Erreur lors de la récupération des créneaux", e);
        }
        return slots;
    }
}
