package fr.eql.ai115.fourchette.rurale.dao.impl;

import fr.eql.ai115.fourchette.rurale.dao.DeliveryPersonDao;
import fr.eql.ai115.fourchette.rurale.dao.impl.connection.FourchetteRuraleDataSource;
import fr.eql.ai115.fourchette.rurale.entity.DeliveryPerson;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


@Remote(DeliveryPersonDao.class)
@Stateless
public class DeliveryPersonDaoImpl implements DeliveryPersonDao{

    private static final Logger logger = LogManager.getLogger();

    private static final String REQ_AUTHENTICATE_DELIVERYPERSON = "SELECT * FROM livreur WHERE email_liv = ? AND password = ?";
    private static final String REQ_INSERT_DELIVERYPERSON = "INSERT INTO livreur (id_type_civilite, nom_liv, prenom_liv, telephone_liv, email_liv, password) VALUES (?,?,?,?,?,?)";
    private static final String REQ_DISPLAY_DELIVERYPERSON = "SELECT * FROM livreur";


    private final DataSource dataSource = new FourchetteRuraleDataSource();


    @Override
    public DeliveryPerson authenticate(String login, String password) {
        DeliveryPerson deliveryPerson = null;
        try (Connection connection = dataSource.getConnection()) {
            PreparedStatement statement = connection.prepareStatement(REQ_AUTHENTICATE_DELIVERYPERSON);
            statement.setString(1, login);
            statement.setString(2, password);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                deliveryPerson = new DeliveryPerson(
                        resultSet.getLong("id_livreur"),
                        resultSet.getLong("id_type_civilite"),
                        resultSet.getString("nom_liv"),
                        resultSet.getString("prenom_liv"),
                        resultSet.getString("telephone_liv"),
                        resultSet.getString("email_liv"),
                        resultSet.getString("password")
                );
            }
        } catch (SQLException e) {
            logger.error("Une erreur s'est produite " +
                    "lors de la consultation de l'adhérent en base de données", e);
        }
        return deliveryPerson;
    }

    @Override
    public void insertDeliveryPerson(DeliveryPerson deliveryPerson) {
        try (Connection connection = dataSource.getConnection()) {
            connection.setAutoCommit(false);
            long id = deliveryPersonStatementExecution(deliveryPerson, connection);
            if (id > 0) {
                deliveryPerson.setId_delivery_person(id);
                logger.info("Le livreur a bien été ajouté en base de données");
            } else {
                connection.rollback();
            }
            connection.commit();
        } catch (SQLException e) {
            logger.error("Une erreur s'est produite lors de l'insertion du livreur en base de données", e);
        }
    }

    @Override
    public List<DeliveryPerson> displayAllDeliveryPersons() {
        List<DeliveryPerson> deliveryPersons = new ArrayList<>();
        try (Connection connection = dataSource.getConnection()) {
            PreparedStatement statement = connection.prepareStatement(REQ_DISPLAY_DELIVERYPERSON);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                DeliveryPerson deliveryPerson = new DeliveryPerson(
                        resultSet.getLong("id_livreur"),
                        resultSet.getLong("id_type_civilite"),
                        resultSet.getString("nom_liv"),
                        resultSet.getString("prenom_liv"),
                        resultSet.getString("telephone_liv"),
                        resultSet.getString("email_liv"),
                        resultSet.getString("password")
                );
                deliveryPersons.add(deliveryPerson);
            }
        } catch (SQLException e) {
            logger.error("Une erreur s'est produite lors de la consultation des livreurs en base de données", e);
        }
        return deliveryPersons;
    }


    private long deliveryPersonStatementExecution(DeliveryPerson deliveryPerson, Connection connection) throws SQLException {
        PreparedStatement statement = connection.prepareStatement(REQ_INSERT_DELIVERYPERSON, PreparedStatement.RETURN_GENERATED_KEYS);
        {
            statement.setLong(1, deliveryPerson.getId_civility());
            statement.setString(2, deliveryPerson.getFirstname());
            statement.setString(3, deliveryPerson.getLastname());
            statement.setString(4, deliveryPerson.getPhone());
            statement.setString(5, deliveryPerson.getEmail());
            statement.setString(6, deliveryPerson.getPassword());
            int affectedRows = statement.executeUpdate();
            if (affectedRows > 0) {
                try (ResultSet resultSet = statement.getGeneratedKeys()) {
                    if (resultSet.next()) {
                        return resultSet.getLong(1);
                    }
                } catch (SQLException e) {
                    connection.rollback();
                    logger.error("An error occurred while retrieving the id of the inserted member.", e);
                }
            }
        }
        return -1;

    }
}



