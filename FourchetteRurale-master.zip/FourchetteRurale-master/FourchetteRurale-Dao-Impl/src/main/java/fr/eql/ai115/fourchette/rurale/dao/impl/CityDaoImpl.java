package fr.eql.ai115.fourchette.rurale.dao.impl;


import fr.eql.ai115.fourchette.rurale.dao.CityDao;
import fr.eql.ai115.fourchette.rurale.dao.impl.connection.FourchetteRuraleDataSource;
import fr.eql.ai115.fourchette.rurale.entity.City;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@Remote (CityDao.class)
@Stateless
public class CityDaoImpl implements CityDao {

    private static final Logger logger = LogManager.getLogger();

    private static final String SELECT_ALL_CITY_FROM_NORMANDIE = "SELECT id_ville, code_postal, ville\n" +
            "FROM ville\n" +
            "WHERE code_postal LIKE '14%' OR \n" +
            "      code_postal LIKE '27%' OR \n" +
            "      code_postal LIKE '50%' OR \n" +
            "      code_postal LIKE '61%' OR \n" +
            "      code_postal LIKE '76%';\n";

    private final DataSource dataSource = new FourchetteRuraleDataSource();

    @Override
    public List<City> findAllCityFromNormandie() {
        List<City> cities = new ArrayList<>();
        try (Connection connection = dataSource.getConnection()) {
            PreparedStatement statement = connection.prepareStatement(SELECT_ALL_CITY_FROM_NORMANDIE);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                City city = new City(
                        resultSet.getLong("id_ville"),
                        resultSet.getString("ville"),
                        resultSet.getLong("code_postal")
                );
                cities.add(city);
            }
        } catch (SQLException e) {
            logger.error("Une erreur s'est produite lors de la consultation des villes en base de données", e);
        }
        return cities;
    }

}
