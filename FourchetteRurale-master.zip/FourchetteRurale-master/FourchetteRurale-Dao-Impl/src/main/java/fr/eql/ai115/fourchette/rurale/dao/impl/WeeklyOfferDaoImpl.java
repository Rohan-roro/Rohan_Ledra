package fr.eql.ai115.fourchette.rurale.dao.impl;

import fr.eql.ai115.fourchette.rurale.dao.WeeklyOfferDao;
import fr.eql.ai115.fourchette.rurale.dao.impl.connection.FourchetteRuraleDataSource;
import fr.eql.ai115.fourchette.rurale.entity.DetailsWeeklyOffer;
import fr.eql.ai115.fourchette.rurale.entity.WeeklyOffer;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.sql.DataSource;
import javax.swing.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import static com.mysql.cj.conf.PropertyKey.logger;


@Remote(WeeklyOfferDao.class)
@Stateless
public class WeeklyOfferDaoImpl implements WeeklyOfferDao {

    private static final Logger logger = LogManager.getLogger();

    private static final String SELECT_WEEKLY_OFFER_BY_ID = "SELECT offrehebdomadaire.id_offre_hebdo, \n" +
            "       offrehebdomadaire.date_creation, \n" +
            "       offrehebdomadaire.date_debut, \n" +
            "       offrehebdomadaire.date_fin, \n" +
            "       detail_de_l_offre_hebdomadaire.id_detail_offre_hebdo, \n" +
            "       detail_de_l_offre_hebdomadaire.id_type_de_repas, \n" +
            "       recette.nom_recette, \n" +
            "       detail_de_l_offre_hebdomadaire.id_recette\n" +
            "FROM offrehebdomadaire\n" +
            "JOIN detail_de_l_offre_hebdomadaire \n" +
            "    ON detail_de_l_offre_hebdomadaire.id_offre_hebdo = offrehebdomadaire.id_offre_hebdo\n" +
            "JOIN recette \n" +
            "    ON detail_de_l_offre_hebdomadaire.id_recette = recette.id_recette\n" +
            "WHERE offrehebdomadaire.id_offre_hebdo = ?;\n";




    private DataSource dataSource = new FourchetteRuraleDataSource();


    @Override
    public WeeklyOffer findById(Long id) {
        WeeklyOffer weeklyOffer = null;
        try (Connection connection = dataSource.getConnection()) {
            PreparedStatement statement = connection.prepareStatement(SELECT_WEEKLY_OFFER_BY_ID);
            statement.setLong(1, id);
            ResultSet resultSet = statement.executeQuery();
            List<Long> idTypeMealList = new ArrayList<>();
            List<String> nameRecipeList = new ArrayList<>();
            List<Long> idRecipeList = new ArrayList<>();
            while (resultSet.next()) {
                if (weeklyOffer == null) {
                    weeklyOffer = new WeeklyOffer(
                            resultSet.getLong("id_offre_hebdo"),
                            resultSet.getDate("date_creation").toLocalDate(),
                            resultSet.getDate("date_debut").toLocalDate(),
                            resultSet.getDate("date_fin").toLocalDate(),
                            idTypeMealList,
                            nameRecipeList,
                            idRecipeList
                    );
                }

                idTypeMealList.add(resultSet.getLong("id_type_de_repas"));
                nameRecipeList.add(resultSet.getString("nom_recette"));
                idRecipeList.add(resultSet.getLong("id_recette"));
            }
            System.out.println("Liste des recettes : " + nameRecipeList);
            System.out.println("Liste des id des recettes : " + idRecipeList);
        } catch (SQLException e) {
            logger.error("Une erreur s'est produite lors de la consultation de l'offre hebdomadaire en base de données", e);
        }
        return weeklyOffer;


    }


}


