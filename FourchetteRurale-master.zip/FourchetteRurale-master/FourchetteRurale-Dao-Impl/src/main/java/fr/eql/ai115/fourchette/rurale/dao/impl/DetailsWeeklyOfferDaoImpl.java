package fr.eql.ai115.fourchette.rurale.dao.impl;


import fr.eql.ai115.fourchette.rurale.dao.DetailsWeeklyOfferDao;
import fr.eql.ai115.fourchette.rurale.dao.impl.connection.FourchetteRuraleDataSource;
import fr.eql.ai115.fourchette.rurale.entity.DetailsWeeklyOffer;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@Remote (DetailsWeeklyOfferDao.class)
@Stateless
public class DetailsWeeklyOfferDaoImpl implements DetailsWeeklyOfferDao {

    private static final Logger logger = LogManager.getLogger();

    private static final String REQ_CREATE_DETAILS_WEEKLY_OFFER = "INSERT INTO detail_de_l_offre_hebdomadaire (id_type_de_repas, id_offre_hebdo, id_recette) VALUES (?, ?, ?);";

    private DataSource dataSource = new FourchetteRuraleDataSource();

    @Override
    public void createWeeklyOfferDetails (DetailsWeeklyOffer detailsWeeklyOffer) {
        try (Connection connection = dataSource.getConnection()) {
            connection.setAutoCommit(false);
            long id = detailsWeeklyOfferStatementExecution(detailsWeeklyOffer, connection);
            if (id > 0) {
                detailsWeeklyOffer.setIdDetailsWeeklyOffer(id);
                logger.info("Détails de l'offre hebdomadaire créés avec succès");
            } else {
                logger.error("Erreur lors de la création des détails de l'offre hebdomadaire");
            }
            connection.commit();
        } catch (SQLException e) {
            logger.error("Erreur lors de la création des détails de l'offre hebdomadaire", e);
        }
    }

    private long detailsWeeklyOfferStatementExecution(DetailsWeeklyOffer detailsWeeklyOffer, Connection connection) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement(REQ_CREATE_DETAILS_WEEKLY_OFFER, PreparedStatement.RETURN_GENERATED_KEYS)) {
            statement.setLong(1, detailsWeeklyOffer.getIdTypeMeal());
            statement.setLong(2, detailsWeeklyOffer.getIdWeeklyOffer());
            statement.setLong(3, detailsWeeklyOffer.getIdRecipe());
            int affectedRows = statement.executeUpdate();
            if (affectedRows > 0) {
                try (ResultSet resultSet = statement.getGeneratedKeys()) {
                    if (resultSet.next()) {
                        return resultSet.getLong(1);
                    }
                } catch (SQLException e) {
                    connection.rollback();
                    logger.error("Erreur lors de la création des détails de l'offre hebdomadaire", e);
                }
            }
            return -1;
        }

    }


}
