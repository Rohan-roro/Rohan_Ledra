package fr.eql.ai115.fourchette.rurale.dao.impl;


import fr.eql.ai115.fourchette.rurale.dao.AdminDao;
import fr.eql.ai115.fourchette.rurale.dao.impl.connection.FourchetteRuraleDataSource;
import fr.eql.ai115.fourchette.rurale.entity.Admin;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@Remote (AdminDao.class)
@Stateless
public class AdminDaoImpl implements AdminDao {

    private static final Logger logger = LogManager.getLogger();


    private static final String REQ_AUTHENTICATE_ADMIN = "SELECT * FROM admin WHERE login = ? AND password = ?";
    private static final String REQ_INSERT_ADMIN = "INSERT INTO admin (login, password) VALUES (?,?)";

    private final DataSource dataSource = new FourchetteRuraleDataSource();

    @Override
    public Admin authenticate(String login, String password) {
        Admin admin = null;
        try (Connection connection = dataSource.getConnection()) {
            PreparedStatement statement = connection.prepareStatement(REQ_AUTHENTICATE_ADMIN);
            statement.setString(1, login);
            statement.setString(2, password);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                admin = new Admin(
                        resultSet.getLong("id_admin"),
                        resultSet.getString("login"),
                        resultSet.getString("password")
                );
            }
        } catch (SQLException e) {
            logger.error("Une erreur s'est produite " +
                    "lors de la consultation de l'admin en base de données", e);
        }
        return admin;
    }

    @Override
    public void insertAdmin(Admin admin) {
        try (Connection connection = dataSource.getConnection()) {
            connection.setAutoCommit(false);
            long id = AdminStatementExecuteUpdate(connection, admin);
            if (id > 0) {
                admin.setIdAdmin(id);
                logger.info("L'admin a bien été inséré en base de données");
            } else {
                connection.rollback();
            }
            connection.commit();
        } catch (SQLException e) {
            logger.error("Une erreur s'est produite lors de l'insertion de l'admin en base de données", e);
        }

    }

    private long AdminStatementExecuteUpdate(Connection connection, Admin admin) throws SQLException {
        PreparedStatement statement = connection.prepareStatement(REQ_INSERT_ADMIN, PreparedStatement.RETURN_GENERATED_KEYS);
        statement.setString(1, admin.getLoginAdmin());
        statement.setString(2, admin.getPasswordAdmin());
       int affectedRows = statement.executeUpdate();
        if (affectedRows > 0) {
            try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    return generatedKeys.getLong(1);
                }
            } catch (SQLException e) {
                connection.rollback();
                logger.error("Une erreur s'est produite lors de la récupération de l'id de l'admin inséré", e);
            }
        }
      return -1;

    }

}
