package fr.eql.ai115.fourchette.rurale.dao.impl;

import fr.eql.ai115.fourchette.rurale.dao.MemberDao;
import fr.eql.ai115.fourchette.rurale.dao.impl.connection.FourchetteRuraleDataSource;
import fr.eql.ai115.fourchette.rurale.entity.Member;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.sql.DataSource;
import java.sql.*;

@Remote(MemberDao.class)
@Stateless
public class MemberDaoImpl implements MemberDao {

    private static final Logger logger = LogManager.getLogger();

    private static final String REQ_AUTHENTICATE_MEMBER = "SELECT * FROM adherent WHERE email = ? AND password = ?";
    private static final String REQ_INSERT_MEMBER = "INSERT INTO adherent (id_ville, id_type_civilite, nom, prenom, date_naissance, telephone, email, password, adresse_livraison, adresse_facturation, date_inscription, date_desadhesion) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";
    private static final String REQ_GET_LAST_INSERTED_ID = "SELECT MAX(id_adherent) AS dernier_id_adherent FROM adherent;";


    private final DataSource dataSource = new FourchetteRuraleDataSource();



    @Override
    public Member authenticate(String login, String password) {
        Member member = null;
        try (Connection connection = dataSource.getConnection()) {
            PreparedStatement statement = connection.prepareStatement(REQ_AUTHENTICATE_MEMBER);
            statement.setString(1, login);
            statement.setString(2, password);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                Date dateDesadhesion = resultSet.getDate("date_desadhesion");
                member = new Member(
                        resultSet.getLong("id_adherent"),
                        resultSet.getLong("id_ville"),
                        resultSet.getLong("id_type_civilite"),
                        resultSet.getString("nom"),
                        resultSet.getString("prenom"),
                        resultSet.getDate("date_naissance").toLocalDate(),
                        resultSet.getString("telephone"),
                        resultSet.getString("email"),
                        resultSet.getString("password"),
                        resultSet.getString("adresse_livraison"),
                        resultSet.getString("adresse_facturation"),
                        resultSet.getDate("date_inscription").toLocalDate(),
                        dateDesadhesion != null ? dateDesadhesion.toLocalDate() : null
                );
            }
        } catch (SQLException e) {
            logger.error("Une erreur s'est produite " +
                    "lors de la consultation de l'adhérent en base de données", e);
        }
        return member;
    }

    @Override
    public void insertMember(Member member) {
        try (Connection connection = dataSource.getConnection()) {
            connection.setAutoCommit(false);
            long id = memberStatementExecution(member, connection);
            if (id > 0) {
                member.setIdMember(id);
                logger.info("Member " + member.getFirstname() + " " + member.getLastname() + " inserted into database with id " + id);
            } else {
                connection.rollback();
            }
            connection.commit();
        } catch (SQLException e) {
            logger.error("An error occurred while inserting " + member.getFirstname() + " " + member.getLastname(), e);
        }
    }

    private long memberStatementExecution(Member member, Connection connection) throws SQLException {
        PreparedStatement statement = connection.prepareStatement(REQ_INSERT_MEMBER, Statement.RETURN_GENERATED_KEYS);
        statement.setLong(1, member.getCity());
        statement.setLong(2, member.getCivility());
        statement.setString(3, member.getFirstname());
        statement.setString(4, member.getLastname());
        statement.setDate(5, Date.valueOf(member.getBirthdate()));
        statement.setString(6, member.getPhoneNumber());
        statement.setString(7, member.getEmailAdress());
        statement.setString(8, member.getPassword());
        statement.setString(9, member.getShippingAddress());
        statement.setString(10, member.getBillingAddress());
        statement.setDate(11, Date.valueOf(member.getRegistrationDate()));
        statement.setDate(12, member.getUnsubscriptionDate() != null ? Date.valueOf(member.getUnsubscriptionDate()) : null);
        int affectedRows = statement.executeUpdate();
        if (affectedRows > 0) {
            try (ResultSet resultSet = statement.getGeneratedKeys()) {
                if (resultSet.next()) {
                    return resultSet.getLong(1);
                }
            } catch (SQLException e) {
                connection.rollback();
                logger.error("An error occurred while retrieving the id of the inserted member.", e);
            }
        }
        return -1;
    }

    @Override
    public Long getLastInsertedId() {
        Long id = null;
        try (Connection connection = dataSource.getConnection()) {
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(REQ_GET_LAST_INSERTED_ID);
            if (resultSet.next()) {
                id = resultSet.getLong("dernier_id_adherent");
            }
        } catch (SQLException e) {
            logger.error("An error occurred while retrieving the last inserted id.", e);
        }
        return id;
    }



}



