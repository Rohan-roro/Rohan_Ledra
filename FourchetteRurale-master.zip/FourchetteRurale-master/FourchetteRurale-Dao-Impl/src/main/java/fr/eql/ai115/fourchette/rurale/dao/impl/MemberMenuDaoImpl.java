package fr.eql.ai115.fourchette.rurale.dao.impl;

import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.sql.DataSource;

import fr.eql.ai115.fourchette.rurale.dao.MemberMenuDao;
import fr.eql.ai115.fourchette.rurale.dao.impl.connection.FourchetteRuraleDataSource;
import fr.eql.ai115.fourchette.rurale.entity.MemberMenu;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.sql.*;

@Remote(MemberMenuDao.class)
@Stateless
public class MemberMenuDaoImpl implements MemberMenuDao {

    private static final Logger logger = LogManager.getLogger();

    private static final String REQ_CREATE_MEMBER_MENU = "INSERT INTO structuredemenu (id_adherent, date_de_choix_structure) VALUES (?,?)";
    private static final String REQ_GET_MEMBER_MENU_BY_ID = "SELECT * FROM structuredemenu WHERE id_adherent = ?";
    private static final String REQ_GET_NUMBER_TYPE_MEAL = "SELECT SUM(nb_repas_type) AS total_repas_type\n" +
            "FROM detail_de_structure_de_menu\n" +
            "WHERE id_type_de_repas = ? AND id_structure_menu = ?;\n";


    private final DataSource dataSource = new FourchetteRuraleDataSource();

    @Override
    public void createMemberMenu(MemberMenu memberMenu) {
        try (Connection connection = dataSource.getConnection()) {
            connection.setAutoCommit(false);
            long id = memberMenuStatementExecution(memberMenu, connection);
            if (id > 0) {
                memberMenu.setIdMemberMenu(id);
                logger.info("Le menu de l'adhérent a bien été créé en base de données");
            } else {
                logger.error("Une erreur s'est produite lors de la création du menu de l'adhérent en base de données");
                connection.rollback();
            }
            connection.commit();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    private long memberMenuStatementExecution(MemberMenu memberMenu, Connection connection) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement(REQ_CREATE_MEMBER_MENU, Statement.RETURN_GENERATED_KEYS)) {
            statement.setLong(1, memberMenu.getIdMember());
            statement.setDate(2, java.sql.Date.valueOf(memberMenu.getChoiceDate()));
            int affectedRows = statement.executeUpdate();
            if (affectedRows > 0) {
                try (ResultSet resultSet = statement.getGeneratedKeys()) {
                    if (resultSet.next()) {
                        return resultSet.getLong(1);
                    }
                } catch (SQLException e) {
                    logger.error("Une erreur s'est produite lors de la récupération de l'identifiant du menu de l'adhérent", e);
                }
            }
            return -1;
        }
    }

    @Override
    public MemberMenu getMemberMenuById(Long id) {
        MemberMenu memberMenu = null;
        try (Connection connection = dataSource.getConnection()) {
            PreparedStatement statement = connection.prepareStatement(REQ_GET_MEMBER_MENU_BY_ID);
            statement.setLong(1, id);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                memberMenu = new MemberMenu(
                        resultSet.getLong("id_structure_menu"),
                        resultSet.getLong("id_adherent"),
                        resultSet.getLong("nombre_de_jour_a_livrer"),
                        resultSet.getDate("date_de_choix_structure").toLocalDate()
                );
            }
        } catch (SQLException e) {
            logger.error("Une erreur s'est produite lors de la récupération du menu de l'adhérent", e);
        }
        return memberMenu;
    }

    @Override
    public int getNumberTypeMeal(Long idTypeMeal, Long idMemberMenu) {
        int numberTypeMeal = 0;
        try (Connection connection = dataSource.getConnection()) {
            PreparedStatement statement = connection.prepareStatement(REQ_GET_NUMBER_TYPE_MEAL);
            statement.setLong(1, idTypeMeal);
            statement.setLong(2, idMemberMenu);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                numberTypeMeal = resultSet.getInt("total_repas_type");
            }
        } catch (SQLException e) {
            logger.error("Une erreur s'est produite lors de la récupération du nombre de repas de type " + idTypeMeal + " pour le menu de l'adhérent " + idMemberMenu, e);
        }
        return numberTypeMeal;
    }


}




