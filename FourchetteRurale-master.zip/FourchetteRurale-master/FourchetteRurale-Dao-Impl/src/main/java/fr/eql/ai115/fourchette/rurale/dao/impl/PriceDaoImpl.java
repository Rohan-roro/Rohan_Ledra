package fr.eql.ai115.fourchette.rurale.dao.impl;


import fr.eql.ai115.fourchette.rurale.dao.PriceDao;
import fr.eql.ai115.fourchette.rurale.dao.impl.connection.FourchetteRuraleDataSource;
import fr.eql.ai115.fourchette.rurale.entity.Price;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@Remote (PriceDao.class)
@Stateless
public class PriceDaoImpl  implements PriceDao {

    private static final Logger logger = LogManager.getLogger();

    private static final String SELECT_ALL_PRICE = "SELECT * FROM typederepas";

    private final DataSource dataSource = new FourchetteRuraleDataSource();

    @Override
    public List<Price> findAllPrices() {
        List<Price> prices = new ArrayList<>();
        try (Connection connection = dataSource.getConnection()) {
            PreparedStatement statement = connection.prepareStatement(SELECT_ALL_PRICE);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                Price price = new Price(
                        resultSet.getLong("id_type_de_repas"),
                        resultSet.getLong("prix_type_de_repas")
                );
                prices.add(price);
            }
        } catch (SQLException e) {
            logger.error("Une erreur s'est produite lors de la consultation des prix en base de données", e);
        }
        return prices;
    }

}
