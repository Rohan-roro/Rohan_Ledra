import fr.eql.ai115.fourchette.rurale.dao.DeliveryPersonDao;
import fr.eql.ai115.fourchette.rurale.dao.impl.DeliveryPersonDaoImpl;
import fr.eql.ai115.fourchette.rurale.dao.impl.MemberDaoImpl;
import fr.eql.ai115.fourchette.rurale.dao.impl.RecipeDaoImpl;
import fr.eql.ai115.fourchette.rurale.entity.DeliveryPerson;
import fr.eql.ai115.fourchette.rurale.entity.Member;
import fr.eql.ai115.fourchette.rurale.entity.Recipe;

import java.time.LocalDate;

public class main {

    public static void main(String[] args) {
        MemberDaoImpl memberDao = new MemberDaoImpl();
        Member member = memberDao.authenticate("jean.dupont@email.com", "a"); // Remplacez "login" et "password" par des valeurs valides

        if (member != null) {
            System.out.println("ID: " + member.getIdMember());
            System.out.println("City ID: " + member.getCity());
            System.out.println("Civility ID: " + member.getCivility());
            System.out.println("First Name: " + member.getFirstname());
            System.out.println("Last Name: " + member.getLastname());
            System.out.println("Birthdate: " + member.getBirthdate());
            System.out.println("Phone Number: " + member.getPhoneNumber());
            System.out.println("Email: " + member.getEmailAdress());
            System.out.println("Password: " + member.getPassword());
            System.out.println("Shipping Address: " + member.getShippingAddress());
            System.out.println("Billing Address: " + member.getBillingAddress());
            System.out.println("Registration Date: " + member.getRegistrationDate());
            System.out.println("Unsubscription Date: " + member.getUnsubscriptionDate());
        } else {
            System.out.println("No member found with the provided login and password.");
        }
    }
}