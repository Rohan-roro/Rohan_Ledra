package fr.eql.ai115.fourchette.rurale.business;

import fr.eql.ai115.fourchette.rurale.entity.Recipe;
import fr.eql.ai115.fourchette.rurale.entity.dto.RecipeDto;

import java.util.List;

public interface RecipeBusiness {
    List<Recipe> findAllRecipes();
    void createRecipe(RecipeDto recipeDto);
    List<Recipe> findAllBreakfast();
    List<Recipe> findAllStarter();
    List<Recipe> findAllMain();
    List<Recipe> findAllDessert();
    List<Recipe> findAllCollation();
    List<Recipe> findRecipesFromWeeklyOffer(Long idWeeklyOffer);
}