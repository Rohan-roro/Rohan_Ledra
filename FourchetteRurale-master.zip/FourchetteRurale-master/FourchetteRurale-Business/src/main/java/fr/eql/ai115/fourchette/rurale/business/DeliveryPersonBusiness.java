package fr.eql.ai115.fourchette.rurale.business;

import fr.eql.ai115.fourchette.rurale.entity.DeliveryPerson;

import java.util.List;

public interface DeliveryPersonBusiness {

    DeliveryPerson authenticate(String login, String password);
    List<DeliveryPerson> findAllDeliveryPersons();


}
