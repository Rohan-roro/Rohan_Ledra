package fr.eql.ai115.fourchette.rurale.business;

import fr.eql.ai115.fourchette.rurale.entity.Order;
import fr.eql.ai115.fourchette.rurale.entity.dto.ContentOrderDto;
import fr.eql.ai115.fourchette.rurale.entity.dto.OrderDto;

import java.util.List;

public interface OrderBusiness {
    void createOrder(OrderDto orderDto);
    void addRecipeInOrder(ContentOrderDto contentOrderDto);
    List<Order> findAllOrders();
    Order getLastOrderByMemberId(Long id);
    List<String> getOrderAdressByTourAndDate(Long idTour, java.sql.Date dateTour);
    void populateTemporyTable(List<String> adherentsAddresses);
    List<String> getShippingAdressesByTourAndDateTour(java.sql.Date dateTour, Long idTour);
    List<Order> getOrdersByShippingDate(java.sql.Date dateTour);
    List<String> getShippingAdresses(Long idTour, java.sql.Date dateTour);
}
