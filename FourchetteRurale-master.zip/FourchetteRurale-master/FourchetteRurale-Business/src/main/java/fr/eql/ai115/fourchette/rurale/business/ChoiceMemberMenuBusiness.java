package fr.eql.ai115.fourchette.rurale.business;

import fr.eql.ai115.fourchette.rurale.entity.dto.ChoiceMemberMenuDto;

public interface ChoiceMemberMenuBusiness {
    void createChoiceMemberMenu(ChoiceMemberMenuDto choiceMemberMenuDto);
}
