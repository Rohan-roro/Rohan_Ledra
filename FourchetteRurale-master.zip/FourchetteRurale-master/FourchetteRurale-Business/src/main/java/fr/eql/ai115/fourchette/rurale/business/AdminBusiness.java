package fr.eql.ai115.fourchette.rurale.business;

import fr.eql.ai115.fourchette.rurale.entity.Admin;

public interface AdminBusiness {
    Admin authenticate(String login, String password);
}
