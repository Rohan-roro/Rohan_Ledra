package fr.eql.ai115.fourchette.rurale.business;

import fr.eql.ai115.fourchette.rurale.entity.DeliveryPerson;
import fr.eql.ai115.fourchette.rurale.entity.Member;
import fr.eql.ai115.fourchette.rurale.entity.dto.AdminDto;
import fr.eql.ai115.fourchette.rurale.entity.dto.DeliveryPersonDto;
import fr.eql.ai115.fourchette.rurale.entity.dto.MemberDto;

public interface RegistrationBusiness {
    void registerMember(MemberDto memberDto);
    void registerDeliveryPerson(DeliveryPersonDto deliveryPersonDto);
    void registerAdmin(AdminDto adminDto);
}
