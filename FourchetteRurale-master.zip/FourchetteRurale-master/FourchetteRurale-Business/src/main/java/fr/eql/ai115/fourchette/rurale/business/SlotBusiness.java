package fr.eql.ai115.fourchette.rurale.business;

import fr.eql.ai115.fourchette.rurale.entity.Slot;

import java.util.List;

public interface SlotBusiness {
    List<Slot> findAllSlots();
}
