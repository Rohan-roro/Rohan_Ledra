package fr.eql.ai115.fourchette.rurale.business;

import fr.eql.ai115.fourchette.rurale.entity.MemberMenu;
import fr.eql.ai115.fourchette.rurale.entity.dto.MemberMenuDto;

public interface MemberMenuBusiness {
    void createMemberMenu(MemberMenuDto memberMenuDto);
    MemberMenu getMemberMenuById(Long memberId);
    int getNumberTypeMeal(Long idTypeMeal, Long idMemberMenu);

}
