package fr.eql.ai115.fourchette.rurale.business;

import fr.eql.ai115.fourchette.rurale.entity.WeeklyOffer;

public interface WeeklyOfferBusiness {
    WeeklyOffer findById(Long id);
}