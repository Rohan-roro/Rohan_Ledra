package fr.eql.ai115.fourchette.rurale.business;

import fr.eql.ai115.fourchette.rurale.entity.dto.DetailsWeeklyOfferDto;

public interface DetailsWeeklyOfferBusiness {
    void createWeeklyOfferDetails(DetailsWeeklyOfferDto detailsWeeklyOfferDto);
}
