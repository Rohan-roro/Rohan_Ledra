package fr.eql.ai115.fourchette.rurale.business;

import fr.eql.ai115.fourchette.rurale.entity.MeansPaiment;

import java.util.List;

public interface MeansPaimentBusiness {
    List<MeansPaiment>findAllMeansPaiment();
}
