package fr.eql.ai115.fourchette.rurale.business;

import fr.eql.ai115.fourchette.rurale.entity.City;

import java.util.List;

public interface CityBusiness {
    List<City> findAllCityFromNormandie();
}
