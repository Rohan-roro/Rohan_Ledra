package fr.eql.ai115.fourchette.rurale.business;

import fr.eql.ai115.fourchette.rurale.entity.Member;

public interface MemberBusiness {
    Member authenticate(String login, String password);
    Long getLastInsertedId();

}