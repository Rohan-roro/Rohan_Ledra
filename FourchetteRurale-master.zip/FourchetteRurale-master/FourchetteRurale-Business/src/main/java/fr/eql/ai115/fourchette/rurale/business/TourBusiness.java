package fr.eql.ai115.fourchette.rurale.business;

import fr.eql.ai115.fourchette.rurale.entity.Tour;
import fr.eql.ai115.fourchette.rurale.entity.dto.TourDto;

import java.util.List;

public interface TourBusiness {
    void createTour(TourDto tourDto);
    Long getLastIdTour();
    Tour getTour(Long idTour);
    List<Tour> getToursByDeliveryPerson(Long idDeliveryMan);
}
