package fr.eql.ai115.fourchette.rurale.business;

import fr.eql.ai115.fourchette.rurale.entity.dto.WeeklyOfferCreateDto;

public interface WeeklyOfferCreateBusiness {
    void createWeeklyOffer(WeeklyOfferCreateDto weeklyOfferCreateDto);
    int findLastWeeklyOffer();
    int findCurrentWeeklyOffer();
}
