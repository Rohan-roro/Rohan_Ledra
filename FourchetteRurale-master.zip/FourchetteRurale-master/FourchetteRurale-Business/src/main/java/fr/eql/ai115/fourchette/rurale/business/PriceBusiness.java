package fr.eql.ai115.fourchette.rurale.business;

import fr.eql.ai115.fourchette.rurale.entity.Price;

import java.util.List;

public interface PriceBusiness {
    List<Price> findAllPrices();
}
